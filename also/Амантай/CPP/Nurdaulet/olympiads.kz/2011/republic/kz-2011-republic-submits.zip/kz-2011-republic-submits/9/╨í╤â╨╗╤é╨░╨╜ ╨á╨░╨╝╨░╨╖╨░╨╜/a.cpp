#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <string>
#include <vector>
#include <cstdio>
#include <set>
#include <map>

#define inf 1000000
using namespace std;
   
int a[100],n,k,m,b[100];
 
int sila[100], maxi, sum;
struct zakli{
	int x,y;
};

bool have[100];
zakli zak[100];

void qs(int l, int r){
	if ( l > r )	return;
	 
	int  i = l, j = r , middle = sila[( l + r + 1 ) / 2];

	do {

	while ( sila[i] < middle ) i++;
	while ( sila[j] > middle ) j--;
	
	
	if ( i <= j ) {
	  	swap(zak[i].x,zak[j].x);
                swap(zak[i].y,zak[j].y);
		swap(sila[i],sila[j]);
	i++;
	j--;
}
	} while ( i < j );
		
	qs(l,j);
	qs(i,r);
}
	

int main(){
        freopen("A.in","r",stdin);
	freopen("A.out","w",stdout);
	 
	scanf("%d%d%d",&n,&m,&k);
	
	for (int i=1; i<=n; i++)
		scanf("%d",&a[i]);
	
	for (int i=1; i<=m; i++)
		scanf("%d",&sila[i]);
	
	for (int i=1; i<=m; i++)
		scanf("%d%d",&zak[i].x, &zak[i].y);
	qs(1,n);
	 maxi = n;

	while ( maxi >= 1 ) {
			if ( a[zak[maxi].x] + a[zak[maxi].y] > k ) { maxi--; } else break;

			 }

       int pred = 0, l = 0;

       int i = maxi; 


             	 while ( pred <= k )  { 

	if ( i == 0 )	break;
	

         	if ( i == 0 )	break;

	if ( !have[zak[i].x] && !have[zak[i].y] ){

        		if ( pred + a[zak[i].x] + a[zak[i].y] <= k  ) { have[zak[i].x] = true;   b[l] = zak[i].x;   b[l+1] =  zak[i].y; l += 2; pred +=  (a[zak[i].x] + a[zak[i].y]);  sum += sila[i]; i--; } else { i--; }
 
       } else i--;
}

			

	int p = 0;

       for (int i=0; i<l; i++)
	for (int j=0; j<l; j++)	
	 if ( i != j  && b[i] == b[j] ) { b[i] = inf; p++;  } 
              

                 sort(b,b+l);
         
        l -= p;

      
        for (int i=0; i<l; i++){   	
	printf("%d ",b[i]);  	
                                
}
	
		fclose(stdout);
return 0;
}