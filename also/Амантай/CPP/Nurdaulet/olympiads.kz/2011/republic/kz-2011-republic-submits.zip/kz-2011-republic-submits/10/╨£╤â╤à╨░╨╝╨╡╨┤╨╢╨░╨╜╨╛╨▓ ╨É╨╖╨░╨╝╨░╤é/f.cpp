//Mukhamejanov Azamat 2011y
#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <ctime>
#include <map>
#include <set>
using namespace std;
#define fname1 "F."
#define fname2 ""
#define inf 1<<30
#define eps 1e-5

int n,m,k,v1[100010],v2[100010],val[100010];
int main (){
	freopen (fname1"in"fname2,"r",stdin);
	freopen (fname1"out"fname2,"w",stdout);

	scanf ("%d %d",&n,&m);
	for (int i=1;i<=m;++i){
		scanf ("%d %d",&v1[i],&v2[i]);
		val[i]=1;
	}
	scanf ("%d",&k);
	for (int j=1;j<=k;++j){
		int x,y;char s[3];
		scanf ("%s %d %d",s,&x,&y);

		if (s[0]=='+')val[y]=x;
			else{
				int sum=0,q;scanf ("%d\n",&q);
				for (int i=1;i<=m;++i)
					if (((v1[i]>=x&&v1[i]<=y)||(v2[i]>=x&&v2[i]<=y))&&val[i]==q)sum++;
				printf ("%d\n",sum);
			}

	}

	return 0;                                                   
}
