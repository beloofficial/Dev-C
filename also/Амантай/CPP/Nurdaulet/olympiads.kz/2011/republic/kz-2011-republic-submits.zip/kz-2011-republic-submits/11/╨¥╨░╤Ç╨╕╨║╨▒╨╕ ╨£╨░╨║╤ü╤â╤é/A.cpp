#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <vector>
#include <set>
#include <queue>
#include <deque>

#define pb			push_back
#define mp			make_pair
#define sqr(x)  	((x)*(x))
#define rep(i, x)   for(int i = 0; i < x; ++ i)
#define sz			size()
#define fi			first
#define se			second
#define name		"A"

using namespace std;
typedef long long LL;
typedef pair <int, int> Pair;

int n, m, k;
int p[10001], f[10001];

int main() {
	freopen(name".in", "r", stdin);
	freopen(name".out", "w", stdout);
	
	cin >> n >> m >> k;

	for(int i = 0; i < n; ++i) {
	 	cin >> p[i];
	}

	int mx = -1, mxi;
	for(int i = 0; i < m; ++ i) {
		cin >> f[i];
		if (mx < f[i]) {
			mx = f[i];
			mxi = i;
		}
	}

	
	int d[100][100];

	for(int i = 0; i < m; ++ i) {
		int x, y;
		cin >> x >> y;
		d[i][x] = y;
		if (i == mxi && p[x-1] + p[y-1] == k) {
			cout << min(x, y) << ' ' << max(x,y);
			return 0;			
		}
	}
	
/*	rep(i, n-1) {
		rep(j, n) {
			if (p[i] + p[j] == k) {
				
			}
		}
	}	
*/
	return 0;
}

