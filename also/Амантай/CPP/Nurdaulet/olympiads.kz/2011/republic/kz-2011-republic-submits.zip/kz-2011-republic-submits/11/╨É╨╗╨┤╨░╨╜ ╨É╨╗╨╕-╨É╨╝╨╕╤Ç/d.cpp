#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <ctime>

using namespace std;

#define N 200000

int n, m, l, r, t;
int a[N], b[N], ans[N];

int amo[N];

struct lr
{
	int l, r, p;
	bool operator < (const lr &a) const
	{
	 	if (l < a.l) return 1;
	 	if (l > a.l) return 0;
	 	if (r < a.r) return 1;
	 	return 0;
	}
} quer[N];

int main ()
{
	freopen ("D.in", "r", stdin);
	freopen ("D.out", "w", stdout);

	scanf ("%d%d", &n, &m);

	for (int i = 0; i < n; i++)
		scanf ("%d", &a[i]),
		b[i] = a[i];
	sort (b, b+n);
	t = unique (b, b+n)-b;

	for (int i = 0; i < n; i++)
		a[i] = lower_bound (b, b+n, a[i])-b;

	for (int i = 0; i < m; i++)
		scanf ("%d%d", &quer[i].l, &quer[i].r),
		quer[i].l--, quer[i].r--, quer[i].p = i;
	sort (quer, quer+m);

	amo[a[0]]++;
	for (int it = 0, i = 0, j = 0, tot=1; it < m; it++)
	{
		l = quer[it].l; r = quer[it].r;

		for (; j < r;)
		{
			j++;
			if (!amo[a[j]]) tot++;
			amo[a[j]]++;
		}

		for (; i < l; i++)
		{
			amo[a[i]]--;
			if (!amo[a[i]]) tot--;
		}

		for (; j > r; j--)
		{
			amo[a[j]]--;
			if (!amo[a[j]]) tot--;
		}

		ans[quer[it].p] = tot;
   }

	for (int i = 0; i < m; i++)
		printf ("%d\n", ans[i]);

	return 0;
}
