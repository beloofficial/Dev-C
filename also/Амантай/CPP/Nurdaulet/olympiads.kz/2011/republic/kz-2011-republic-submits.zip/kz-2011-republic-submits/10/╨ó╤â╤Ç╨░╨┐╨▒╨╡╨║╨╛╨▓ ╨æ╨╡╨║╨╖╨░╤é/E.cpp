#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstdlib>
#include<vector>
#include<utility>
#include<queue>
#include<ctime>
#include<list>
#include<set>
#include<map>

using namespace std;

#define tr(Con,it) for(typeof(Con.begin()) it=Con.begin();it!=Con.end();it++)
#define pb push_back
#define mp make_pair
int n,m,A,B,C,L,R,P,x;
long long ans;
int main(){
	freopen("E.in","r",stdin);
	freopen("E.out","w",stdout);
	scanf("%d %d %d %d %d %d",&A,&B,&C,&L,&R,&P); 
	
	for(int i=L;i<=R;i++) {
		x=((i-A)%P*1ll*(i-B)%P*(i-C))%P;
		ans=(ans*1ll+x)%P; 
	}
	ans=ans%P;
	printf("%d\n",ans);
return 0;
}