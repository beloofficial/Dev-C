#include <algorithm>
#include <iostream>
#include <cassert>
#include <cstring>
#include <cstdlib>
#include <string>
#include <vector>
#include <cstdio>
#include <ctime>
#include <cmath>
#include <set>
#include <map>

#define inf (int)1e9
#define EPS 1e-6
#define file "F"

typedef long long ll;
typedef long double ld;

using namespace std;

struct graph {

	int v, next;

	graph() {
		
		v = 0;
		next = -1;

	}

} g[300200];

struct ribs {

	int x, y;

	ribs() {

		x = y = 0;

	}

} e[200200];

int n, m, h[200200], head[200200], p[200200], c[200200], t[200200];

void dfs(int v, int c) {

	h[v] = c;

	for (int i = head[v]; i != -1; i = g[i].next)
		if (!h[g[i].v])
			dfs(g[i].v,c + 1);
				
}

void get_position(int v, int position) {

	p[v] = position;

	for (int i = head[v]; i != -1; i = g[i].next)
		if (p[g[i].v] == -1)
			get_position(g[i].v, position + 1);

}

void update(int i, int delta) {

	for (; i < m; i = (i | (i + 1)))
		t[i] += delta;
				
}

int sum(int i) {

	int res = 0;

	for (; i >= 0; i = (i & (i + 1)) - 1)
		res += t[i];

    	return res;

}

int sum(int l, int r) {

	return sum(r) - sum(l - 1);

}

int main() {

	freopen(file".in", "r", stdin);
	freopen(file".out", "w", stdout);

	scanf("%d%d", &n, &m);

	memset(head, -1, sizeof(head));

	for (int i = 0, j = 0; i < m; ++i) {

		int x, y;

		scanf("%d%d", &x, &y);

		g[j].next = head[x - 1], g[j].v = y - 1, head[x - 1] = j++;
		g[j].next = head[y - 1], g[j].v = x - 1, head[y - 1] = j++;
		e[i].x = x - 1;
		e[i].y = y - 1;

	}

	m = n - 1;

	dfs(0, 1);

	int maximum = 0, v = -1;

	for (int i = 0; i < n; ++i)
		if (h[i] > maximum)
			maximum = h[i], v = i;

   	memset(p, -1, sizeof(p));
   	get_position(v, 0);

   	for (int i = 0; i < n; ++i)
   		c[i] = 0;

   	int tests;

   	scanf("%d\n", &tests);

   	while (tests--) {

   		char type;

   		scanf("%c", &type);

   		if (type == '+') {

   			int k, y;

   			scanf("%d%d\n", &k, &v);

   			int ind = min(p[e[v - 1].x], p[e[v - 1].y]);

   			if (c[ind] == 1 && k == 1) {

   				update(ind, -1);
   				c[ind] = 0;

			} else if (c[ind] == 0 && k == 2) {

				update(ind, 1);
				c[ind] = 1;

		  	}

   		} else if (type == 'q') {
   		
   			int k, x, y;

   			scanf("%d%d%d\n", &x, &y, &k);

			int l = min(p[x - 1], p[y - 1]), r = max(p[x - 1], p[y - 1]) - 1, cnt = sum(l, r);

			if (k == 1)
				printf("%d\n", (r - l + 1) - cnt);
		     	else
		     		printf("%d\n", cnt);

   		} else
   			assert(0);

   	}

	return 0;
		
}
