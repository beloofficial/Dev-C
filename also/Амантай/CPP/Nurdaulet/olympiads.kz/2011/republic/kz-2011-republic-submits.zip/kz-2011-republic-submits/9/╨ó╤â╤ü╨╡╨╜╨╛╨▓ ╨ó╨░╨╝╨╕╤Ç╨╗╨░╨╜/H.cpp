#include<cstdio>
#define inf 10000000000009
using namespace std;

int n,m;
int q[3][2]={0,1,0,-1,1,0};
int a[1009][1009];
long long int  b[1009][1009];
int nastr,l=1;
int x[1000009],y[1000009];

int main()
{
freopen("H.in","r",stdin);
freopen("H.out","w",stdout);

scanf("%d%d",&n,&m);
for(int i=0;i<n;i++){
for(int j=0;j<m;j++){
scanf("%d",&a[i][j]);}}

scanf("%d",&nastr);

for(int i=0;i<n;i++){
for(int j=0;j<m;j++){
b[i][j]=inf;}}

x[0]=0;
y[0]=0;
b[0][0]=0;


for(int i=0;i<l;i++){
for(int j=0;j<3;j++){
if(x[i]+q[j][1]>=0 && x[i]+q[j][1]<m &&
   y[i]+q[j][0]>=0 && y[i]+q[j][0]<n){
if(b[y[i]+q[j][0]][x[i]+q[j][1]]>b[y[i]][x[i]]+a[y[i]+q[j][0]][x[i]+q[j][1]]){
b[y[i]+q[j][0]][x[i]+q[j][1]]=b[y[i]][x[i]]+a[y[i]+q[j][0]][x[i]+q[j][1]];

x[l]=x[i]+q[j][1];
y[l]=y[i]+q[j][0];
l++;}}}}

                                      
printf("%d",nastr-b[n-1][m-1]);


return 0;
}