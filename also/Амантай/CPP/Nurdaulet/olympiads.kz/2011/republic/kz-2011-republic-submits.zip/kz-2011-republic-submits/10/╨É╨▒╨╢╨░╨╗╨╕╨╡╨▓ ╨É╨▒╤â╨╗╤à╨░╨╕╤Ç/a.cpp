#include <algorithm>
#include <iostream>
#include <cstring>
#include <cassert>
#include <cstdlib>
#include <string>
#include <vector>
#include <cstdio>
#include <cmath>
#include <ctime>
#include <set>
#include <map>

#define inf (int)1e9
#define EPS 1e-6
#define file "A"

typedef long long ll;
typedef long double ld;

using namespace std;

int n, m, k, l, max_sum, r[30], p[30], s[30][30], cnt[30], res[30];
set <int> Set;

void rec(int v, int sum, int w) {

	if (v == m) {

		if (sum > max_sum) {

			max_sum = sum;
			l = 0;

			for (set <int> :: iterator it = Set.begin(); it != Set.end(); it++)
				res[l++] = *it;

		}

		return;

	}

	for (int i = v; i < m; ++i) {

		int tmp = 0;

		for (int j = 0; j < cnt[i]; ++j)
			if (Set.find(s[i][j]) == Set.end())
				tmp += r[s[i][j]];

	  	if (tmp && w + tmp <= k) {

	  		int List[30], size = 0;

	  		for (int j = 0; j < cnt[i]; ++j)
	  			if (Set.find(s[i][j]) == Set.end()) {

	  				Set.insert(s[i][j]);
	  				List[size++] = s[i][j];
	  					
	  			}

	  	   	rec(v + 1, sum + p[i], w + tmp);

	  	  	for (int j = 0; j < size; ++j)
	  	  		Set.erase(List[j]);

	  	  	rec(v + 1, sum, w);

	  	} 

	}

}

int main() {

	freopen(file".in", "r", stdin);
	freopen(file".out", "w", stdout);

	scanf("%d%d%d", &n, &m, &k);

	for (int i = 0; i < n; ++i)
		scanf("%d", &r[i]);

  	for (int i = 0; i < m; ++i)
  		scanf("%d", &p[i]);

   	scanf("\n");

     	for (int i = 0; i < m; ++i) {

     		char c = 0;

     		while (c != '\n') {

     			scanf("%c", &c);

     			if (isdigit(c)) 
     				s[i][cnt[i]] *= 10, s[i][cnt[i]] += (c - '0');
     		   	else  
     		   		s[i][cnt[i]++]--;

     		}

   	}

  	rec(0, 0, 0);

  	for (int i = 0; i < l; ++i)
  		printf("%d ", res[i] + 1);

 	printf("\n");

	return 0;

}