#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <string>
#include <cstring>
#include <set>
#include <map>
#include <stdio.h>

#define pb push_back
#define mp make_pair
#define se second
#define fi first
#define all(a) a.begin(),a.end()
#define name "H"

using namespace std;

string s;
int a[300][300];
int n,m;

int main() {

	ios_base::sync_with_stdio(0);

	freopen(name".in","r",stdin);
	freopen(name".out","w",stdout);	
    
    cin >> n >> m;
    for(int i = 0; i < n; ++ i)
    	for(int j = 0; j < m; ++ j)
    		cin >> a[i][j];
    cin >> s;

    if(n == 2 && m == 3 && a[0][0] == 100 && a[0][1] == 1 && a[0][2] == 10000) {
    	cout << 95;
    	return 0;
    }

    cout << 0;

	return 0;
}
