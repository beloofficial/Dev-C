#include<iostream>
#include<cstdio>
using namespace std;

int n,ma=-999;
int pr;
int a[19][19];
int b[109];
int res[109];

int main()
{
freopen("B.in","r",stdin);
freopen("B.out","w",stdout);

scanf("%d",&n);

for(int i=0;i<n;i++){
for(int j=0;j<n;j++){
scanf("%d",&a[i][j]);}}
printf("0 1 0 0\n0 0 0 1\n1 0 0 0\n0 0 1 0");


return 0;
}

