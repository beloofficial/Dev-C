#include <algorithm>
#include <iostream>
#include <cstdio>

const int dy[] = {+1, 0, -1}, dx[] = {0, +1, 0};

typedef long long ll;

using namespace std;

ll a[300][300], d[300][300], sd[300][300]; 

int main() {

	freopen("H.in", "r", stdin);
	freopen("H.out", "w", stdout);

	int n, m;

	scanf("%d%d", &n, &m);

	for (int i = 0; i < n; ++i)
		for (int j = 0; j < m; ++j)
			scanf("%I64d", &a[i][j]);

     	for (int i = 0; i < max(n, m); ++i)
     		sd[i][0] = 1;

   	for (int i = 1; i < max(n, m); ++i)
   		for (int j = 1; j <= i; ++j)
   			for (int k = 1; k <= i; ++k)
   				sd[i][j] += sd[i - k][j - 1];

  	ll s;

  	scanf("%I64d", &s);

 	d[0][0] = s;

 	for (int i = 0; i < n; ++i)
 		for (int j = 0; j < m; ++j)
 			for (int k = 0; k < 3; ++k)
 				if (j + dy[k] >= 0 && i + dx[k] < n && j + dy[k] < m)
 					d[i + dx[k]][j + dy[k]] = max(d[i + dx[k]][j + dy[k]], d[i][j] - a[i + dx[k]][j + dy[k]] - (sd[max(i, j)][min(i, j)] * (s - d[i][j])));

	printf("%I64d\n", d[n - 1][m - 1]);

	return 0;
		
}