#include <cstdio>
#include <vector>
#include <utility>
#include <iostream>
#include <algorithm>

using namespace std;

#define f first
#define s second

int n, ans;
int w[15], Ww[15];
pair <int, int> a[15][15];
vector <char> column(15), dig1(30), dig2(30);

void rec(int k, int sum) {
	if (k == n) {
		if (sum > ans) {
			for (int i = 0; i < n; i++)
				Ww[i] = w[i];
			ans = sum;
		}
		return ;
	}
	for (int i = n - 1; i >= 0; i--) {
	    int pos = a[k][i].s;
		if (column[pos] || dig1[k + pos] || dig2[k - pos + n]) continue;

		column[pos] = dig1[k + pos] = dig2[k - pos + n] = true;
		w[k] = pos;
				
		rec(k + 1, sum + a[k][i].f);

	    column[pos] = dig1[k + pos] = dig2[k - pos + n] = false;
	}
}

int main() {
	freopen("B.in", "r", stdin);
	freopen("B.out", "w", stdout);

	scanf("%d", &n);
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			scanf("%d", &a[i][j].f);
			a[i][j].s = j;	
		}
		sort(a[i], a[i] + n);	                  
	}

	rec(0, 0);

	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++)
			if (Ww[i] == j) printf("1 ");
			else printf("0 ");
		printf("\n");
	}

	return 0;
}