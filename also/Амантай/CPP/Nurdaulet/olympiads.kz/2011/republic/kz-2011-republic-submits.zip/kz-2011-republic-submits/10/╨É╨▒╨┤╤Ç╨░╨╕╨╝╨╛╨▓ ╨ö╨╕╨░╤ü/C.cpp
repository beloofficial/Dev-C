#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <cstdio>
#include <cstdlib>
#include <math.h>
#include <string>
#include <string.h>
#include <vector>
#include <queue>
#include <deque>
#include <list>
#include <set>
#include <map>
#include <algorithm>
#include <limits>
#include <utility>

#define FOR(i,a,b) for (int i=a; i<=b; i++)
#define FORD(i,a,b) for (int i=a; i>=b; i--)
#define INF numeric_limits <int> :: max()
#define p_b push_back
#define m_p make_pair

using namespace std;
vector <int> ans,one,two;
vector <int> ::iterator it;
int n,m,a[501][501],k[1200],mn,x,y,ind[1200];
bool used[1200];
/*   void dfs(int v)
    {
    mn=v;
     FOR(i,1,n+m)
     if (a[v][i]==1)
      {
       if (k[mn]>k[i]) mn=i;
    //   a[v][i]=0;
  //     used[v]=true;
       ans.p_b(mn);
       used[mn]=true;
       FOR(j,1,n+m)
       if (a[mn][j]==1) used[j]=true;
       dfs(mn);
      }
    }
  */

void QS(int l, int r)
 {
  int i,j,x,m;
  i=l; j=r; x=k[(rand()%(j-i)+1)+i];
  do
   {
   while (k[i]<x) i++;
   while (k[j]>x) j--;
    if (i<=j)
     {
      swap(k[i],k[j]);
      swap(ind[i],ind[j]);
      i++; j--;
     }
   } while (i<j);
   if (l<j) QS(l,j);
   if (i<r) QS(i,r);
 }

  void del(int v)
   {
   used[v]=true;
    FOR(i,1,n+m)
    if (a[v][i]==1 && !used[i]) used[i]=true;
   }

int main()
{
freopen("C.in","rt",stdin);
freopen("C.out","wt",stdout);
scanf("%d %d\n",&n,&m);
for (x=1; x<=n; x++)
 {
  scanf("%d",&k[x]);
  ind[x]=x;
  FOR(j,1,k[x])
  scanf("%d ",&y),a[x][y+n]=1;
  scanf("\n");
 }

for(y=n+1; y<=n+m; y++)
 {
 scanf("%d",&k[y]);
 ind[y]=y;
  FOR(j,1,k[y])
  scanf("%d ",&x),a[y][x]=1;
  scanf("\n");
 }

QS(1,n+m);

//FOR(i,1,n+m)
//cout<<k[i]<<" "<<ind[i]<<" \n";

FOR(i,1,n+m)

 if (!used[i]) ans.p_b(ind[i]),del(ind[i]);

 //cout<<endl;
FOR(i,0,ans.size()-1) 
if (ans[i]<=n) one.p_b(ans[i]); else two.p_b(ans[i]-n);
printf("%d %d %d\n",ans.size(),one.size(),two.size());
for (it=one.begin(); it!=one.end(); it++) printf("%d ",*it);
printf("\n");
for (it=two.begin(); it!=two.end(); it++) printf("%d ",*it);
fclose(stdin); fclose(stdout);
return 0;
}    