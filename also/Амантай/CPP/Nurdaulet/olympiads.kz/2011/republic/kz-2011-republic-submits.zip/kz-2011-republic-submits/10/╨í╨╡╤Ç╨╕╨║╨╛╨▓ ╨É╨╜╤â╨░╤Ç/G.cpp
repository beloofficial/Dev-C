// Solution by [A.S.]

#include <iostream>
#include <fstream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include "dist.h"

#define EPS 1e-7
#define border 1000000000

using namespace std;

int main()
{
        start();
	
	long long leftX = -border;
	long long rightX = border;

	long long leftY = -border;
	long long rightY = border;

	long long x = 0;
	long long y = 0;

	while (true)
	{
		x = (leftX + rightX) / 2;

		if (!dist (x, y))
		{
			finish (x, y);
			return 0;
		}

		if (dist (leftX, y) == dist (rightX, y))
			break;

		if (dist (leftX, y) - dist (rightX, y) >= EPS)
			leftX = x;
		else
			rightX = x;
	}

	while (true)
	{
		y = (leftY + rightY) / 2;

		if (!dist (x, y))
		{
			finish (x, y);
			return 0;
		}

		if (dist (x, leftY) - dist (x, rightY) >= EPS)
			leftY = y;
		else
			rightY = y;
	}


	return 0;
}
