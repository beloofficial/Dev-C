#include <cstdio>
#include <iostream>

using namespace std;

int main(){
	freopen("E.in", "r", stdin);
    freopen("E.out", "w", stdout);

	int a, b, c, l, r, p;
	cin>>a>>b>>c>>l>>r>>p;
	long long res = 0;

	for (long long x = l; x<=r; x++) {
		res = (res + ((((x-a) * (x-b)) % p) * (x-c)) % p) % p;
	}
	
	if (res < 0)
		{cout<<p + res;}
	else
		{cout<<res;}
	return 0;
}
