#include <cstdio>
int i, n, m, _n, _m, a[501], b[501], tmp, j;

int main()
{
	freopen("C.in", "r", stdin);
	freopen("C.out", "w", stdout);

	scanf("%d%d", &n, &m);

	for (i = 0; i < n; i++)
	{
		scanf("%d", &a[i]);
		for (j = 0; j < a[i]; j++) scanf("%d", &tmp);
		_m += a[i] == 0;
	}
	
	for (i = 0; i < m; i++)
	{
		scanf("%d\n", &b[i]);
		for (j = 0; j < b[i]; j++) scanf("%d", &tmp);
		_n += b[i] == 0;
	}

	if (n+_n > m+_m)
	{
		printf("%d %d %d\n", n+_n, n, _n);
		for (i = 1; i <= n; i++) printf("%d ", i); printf("\n");
		for (i = 0; i < m; i++) if (b[i] == 0) printf("%d ", i+1);
	}
	else
	{
		printf("%d %d %d\n", m+_m, _m, m);
		for (i = 0; i < n; i++) if (a[i] == 0) printf("%d ", i+1); printf("\n");
		for (i = 1; i <= m; i++) printf("%d ", i);
	}
	
	return 0;
}
