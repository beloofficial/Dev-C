#include <algorithm>
#include <iostream>
#include <cstring>
#include <cassert>
#include <cstdlib>
#include <string>
#include <vector>
#include <cstdio>
#include <cmath>
#include <ctime>
#include <set>
#include <map>

#define inf (int)1e9
#define EPS 1e-6
#define file "C"

typedef long long ll;
typedef long double ld; 

using namespace std;

struct VER {

	int in, out;

	VER() {

		in = out = 0;

	}

} cnt1[600], cnt2[600];

int n, m, res, k1, k2, a[600][600], b[600][600];
bool l[600], r[600];

bool check() {

	res = k1 = k2 = 0;

	for (int i = 0; i < n; ++i)
		if (l[i] && !cnt1[i].out)
			res++;
		else if (l[i] && cnt1[i].out)
			return false;

	for (int i = 0; i < m; ++i)
		if (r[i] && !cnt2[i].out)
			res++;
		else if (r[i] && cnt2[i].out)
			return false;

   	for (int i = 0; i < n; ++i)
   		if (l[i])
   			k1++;

    	for (int i = 0; i < m; ++i)
    		if (r[i])
    			k2++;

}

int main() {

	freopen(file".in", "r", stdin);
	freopen(file".out", "w", stdout);

	scanf("%d%d", &n, &m);

	memset(l, 1, sizeof(l));
	memset(r, 1, sizeof(r));

	for (int i = 0; i < n; ++i) {

		int k = 0;

		scanf("%d", &k);

		cnt1[i].out = k;

		for (int j = 0; j < k; ++j) {

			int v;

			scanf("%d", &v);

			a[i][v - 1] = 1;

			cnt2[v - 1].in++;


		}

	}

	for (int i = 0; i < m; ++i) {

		int k = 0;

		scanf("%d", &k);

		cnt2[i].out = k;

		for (int j = 0; j < k; ++j) {

			int v;

			scanf("%d", &v);

			b[i][v - 1] = 1;

			cnt1[v - 1].in++;

		}

	}

	for (int k = 0; k < n + m; ++k) {

		int in = 0, out = 0, v = 0;

		for (int i = 0; i < n; ++i)
			if (cnt1[i].in > in || (cnt1[i].in == in && cnt1[i].out > out))
				in = cnt1[i].in, out = cnt1[i].out, v = i;

	   	bool found = 0;

	   	for (int i = 0; i < m; ++i)
	   		if (cnt2[i].in > in || (cnt2[i].in == in && cnt2[i].out > out))
	   			in = cnt2[i].in, out = cnt2[i].out, v = i, found = 1;

	   	if (found) {

	   		r[v] = false;

	   		cnt2[v].out = cnt2[v].in = 0;

	   		for (int i = 0; i < n; ++i)
	   			if (b[v][i])
	   				cnt1[i].in--, b[v][i] = 0;

	   	   	for (int i = 0; i < n; ++i)
				if (a[i][v])
	   	   			a[i][v] = 0, cnt1[i].out--;


	   	} else {

	   		l[v] = false;

	   		cnt1[v].out = cnt1[v].in = 0;

	   		for (int i = 0; i < m; ++i)
	   			if (a[v][i])
	   				cnt2[i].in--, a[v][i] = 0;

	   	    	for (int i = 0; i < m; ++i)
				if (b[i][v])
	   	    			b[i][v] = 0, cnt2[i].out--;

	   	}
                       
	   	if (check())
	   		break;

	}

	printf("%d %d %d\n", res, k1, k2);

	for (int i = 0; i < n; ++i)
		if (l[i])
			printf("%d ", i + 1);

	printf("\n");

	for (int i = 0; i < m; ++i)
		if (r[i])
			printf("%d ", i + 1);

	printf("\n");
  	        
	return 0;

}