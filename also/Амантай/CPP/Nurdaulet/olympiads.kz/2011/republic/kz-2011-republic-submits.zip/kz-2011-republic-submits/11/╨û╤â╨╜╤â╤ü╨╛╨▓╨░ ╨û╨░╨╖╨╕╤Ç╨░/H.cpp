#include<iostream>
#include<algorithm>
#include<cstdio>
#include<string>
#include<cstring>
#include<cmath>
#include<vector>
#include<stack>
#include<queue>
#include<map>
#include<set>

#define mp make_pair
#define pb push_back
#define fi first
#define se second

using namespace std;

int a[210][210][500],n,m;
int d[1100],st[1100],c[210][210][1100];
int time=0,inf;
long long b[210][210];
queue<pair<int,int> > q;
string s;

bool check(int i,int j)
{
	if(d[0]<c[i][j][0])  return 1;
	if(d[0]>c[i][j][0])  return 0;

	int k;

    for(k=d[0];k>0;k--)
    	if(d[k]>c[i][j][k]) return 0;
    	else
    		if(d[k]<c[i][j][k])   return 1;

    return 0;    		
}

int check2()
{
	if(d[0]<st[0])  return 1;
	if(d[0]>st[0])  return 2;

	int k;

    for(k=st[0];k>0;k--)
    	if(d[k]>st[k]) return 2;
    	else
    		if(d[k]<st[k])   return 1;

    return 0;    		
}
 
void pl(int i1,int j1,int i2,int j2,int i3,int j3)
{
	int i,j,carry,k;
             
	for(i=0;i<=1000;i++)  d[i]=0;

	d[0]=c[i1][j1][0]+a[i2][j2][0];

	carry=0;
	for(i=1;i<=c[i1][j1][0];i++)
		for(j=1;j<=a[i2][j2][0];j++)
		{
			k=i+j-1;
			d[k]+=c[i1][j1][i]*a[i2][j2][j];
			carry=d[k]/10;
			d[k]%=10;

			while(carry>0)
			{
				++k;
				d[k]+=carry;
				carry=d[k]/10;
				d[k]%=10;
			}
		}

	while((d[0]>1)&&(d[d[0]]==0))         d[0]--;

	carry=b[i3][j3];
	for(i=1;i<=d[0];i++)
	{
		d[i]+=carry;
		carry=d[i]/10;
		d[i]%=10;
	}

	while(carry>0)
	{
		d[++d[0]]+=carry;
		carry=d[d[0]]/10;
		d[d[0]]%=10;
	}

    if(check(i3,j3))
    {
    	for(i=0;i<=d[0];i++)
    		c[i3][j3][i]=d[i];

   		q.push(mp(i3,j3));	
    }
}

int main()
{
	freopen("H.in","r",stdin);
	freopen("H.out","w",stdout);

	int i,j,carry,k,z;

	cin>>n>>m;

	for(i=1;i<=200;i++)
		a[1][i][0]=a[1][i][1]=a[i][i][0]=a[i][i][1]=1;
		
	for(i=2;i<200;i++)
		for(j=i+1;j<=200;j++)
		{
			a[i][j][0]=1;
			for(z=max(1,j-9);z<j;z++)
			{
				a[i][j][0]=max(a[i][j][0],a[i-1][z][0]);
				carry=0;
				for(k=1;k<=a[i][j][0];k++)
				{
					a[i][j][k]=a[i][j][k]+a[i-1][z][k]+carry;
					carry=a[i][j][k]/10;
					a[i][j][k]%=10;
				}

				if(carry>0)  a[i][j][++a[i][j][0]]=carry;
			} 
		}

	for(i=1;i<=n;i++)
		for(j=1;j<=m;j++)
			cin>>b[i][j];

	cin>>s;

	st[0]=s.length();
	for(i=0;i<st[0];i++)
		st[st[0]-i]=(int)s[i]-48;

	inf =100000000;
	for(i=1;i<=n;i++)
		for(j=1;j<=m;j++)
			c[i][j][0]=inf;

	c[1][1][0]=1;
	for(i=1;i<=1000;i++)  c[1][1][i]=0;
	q.push(mp(1,1));
	while(!q.empty())
	{
		if(time>50000000)  break;

		i=q.front().first;
		j=q.front().second;
		q.pop();

		/*
		cout<<i<<" " <<j<<"\n";

		for(k=c[i][j][0];k>=1;k--)  cout<<c[i][j][k];

		cout<<endl<<endl;
		  */
		if(j!=1)  pl(i,j,min(i,j-1),max(i,j-1),i,j-1);
		if(i!=n)  pl(i,j,min(i+1,j),max(i+1,j),i+1,j);
		if(j!=m)  pl(i,j,min(i,j+1),max(i,j+1),i,j+1);
	}

    if(c[n][m][0]==inf) cout<<s;
    else
    {
    	for(i=0;i<=c[n][m][0];i++)
    		d[i]=c[n][m][i];

    	if(check2()==0)  cout<<'0';
    	else
    	if(check2()==1)
    	{
    		carry=0;
    		for(i=1;i<=st[0];i++)
    		{
    			st[i]-=carry+d[i];
    			carry=0;	

    			if(st[i]<0)
    			{
    				st[i]+=10;
    				carry=1;
    			}
    		}

    		while((st[0]>1)&&(st[st[0]]==0))   st[0]--;

    		for(i=st[0];i>0;i--) cout<<st[i];
    	}
    	else
    	{
    		carry=0;
    		for(i=1;i<=d[0];i++)
    		{
    			d[i]-=carry+st[i];
    			carry=0;

    			if(d[i]<0)
    			{
    				d[i]+=10;
    				carry=1;
    			}
    		}

    		while((d[0]>1)&&(d[d[0]]==0))  d[0]--;

    		cout<<'-';
    		for(i=d[0];i>0;i--)
    			cout<<d[i];
    	}
    }  
    
	return 0;
}