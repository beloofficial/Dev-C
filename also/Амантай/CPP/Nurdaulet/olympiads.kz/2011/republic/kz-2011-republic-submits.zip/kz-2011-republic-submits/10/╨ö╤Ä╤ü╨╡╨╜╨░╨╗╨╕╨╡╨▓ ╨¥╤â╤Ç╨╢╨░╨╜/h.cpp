#include <set>
#include <map>
#include <vector>
#include <cstdio>
#include <cstdlib>
#include <string.h>
#include <iostream>
#include <algorithm>
using namespace std;

#define sz(a) (a).size()
#define pb push_back
#define mp make_pair

int main()
{
	freopen("H.in", "r", stdin);
	freopen("H.out", "w", stdout);
	printf("95");
	return 0;
}
