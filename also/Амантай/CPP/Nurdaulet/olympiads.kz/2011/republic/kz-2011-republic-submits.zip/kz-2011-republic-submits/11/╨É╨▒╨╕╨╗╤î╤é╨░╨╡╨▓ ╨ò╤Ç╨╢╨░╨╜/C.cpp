#include <iostream>
#include <string>
#include <cstdlib>
#include <cstdio>
using namespace std;
int main()
{
	freopen ("C.in","r",stdin);
	freopen ("C.out","w",stdout);
	int n,m,a[510][510],b[510][510],p[510],h[510],t[510],x,e[510],f[510],g[510];
	bool  d1[510],d2[510];

cin>>n>>m;  ///return 0;
for (int i=1; i<=n; i++)
{
	cin>>f[i]; p[i]=i; t[i]=i;
	for (int j=1; j<=f[i]; j++) {  cin>>x; a[i][x]=true;  }
} 
for (int i=1; i<=m; i++)
{
	cin>>g[i]; h[i]=i; e[i]=i;
	for (int j=1; j<=g[i]; j++) {  cin>>x; b[i][x]=true; }
}
//cout<<n; return 0; 
for (int i=1; i<n; i++)
for (int j=i+1; j<=n; j++)
if (f[i]<f[j]) { swap(p[i],p[j]); swap(f[i],f[j]); swap(t[p[i]],t[p[j]]); }

for (int i=1; i<m; i++)
for (int j=i+1; j<=m; j++)
if (g[i]<g[j]) { swap(h[i],h[j]); swap(g[i],g[j]); swap(e[h[i]],e[h[j]]); }

int sum=n+m;
//for (int i=1; i<=n; i++) cout<<p[i]<<t[i]; 
for (int i=1; i<505; i++) { d1[i]=false; d2[i]=false; } 
int i=1,j=1;
while (true)
{
	
	if (f[i]==0 || f[j]==0)  break;
	if (f[i]<g[j]) 
	{
	  for (int k=1; k<=n; k++) 
	  if (a[k][e[j]] && !d1[k])
	  {
		f[p[k]]--; a[k][e[j]]=false; b[e[j]][k]=false; int l=p[k];
		while (l<n)	
		            {
		              if (f[l]<f[l+1]) {  swap(f[l],f[l+1]); swap(p[l],p[l+1]); swap(t[p[l]],t[p[l+1]]); l++; }
				else break;	
		            }	
					
	  }
	  sum--; d2[e[j]]=true;	j++;           
		
	}
	else {
	    for (int k=1; k<=m; k++)
		if (b[k][t[i]] && !d2[k])
		{
		        g[h[k]]--;  a[t[i]][k]=false; b[k][t[i]]=false;   int l=h[k];
		        while (l<m)
			{
				if (g[l]<g[l+1]) {  swap(g[l],g[l+1]); swap(h[l],h[l+1]); swap(e[h[l]],e[h[l+1]]); l++; }
				else break;
			
			}
		}
	   sum--; d1[t[i]]=true; i++;  	
	}
	 	
}

cout<<sum<<" ";      int l=0;  
for (int i=1; i<=n; i++) if (!d1[i]) l++; cout<<l<<" ";  ; l=0;
for (int i=1; i<=m; i++) if (!d2[i]) l++; cout<<l<<endl; 
for (int i=1; i<=n; i++) if (!d1[i]) cout<<i<<" ";  cout<<endl;
for (int i=1; i<=m; i++) if (!d2[i]) cout<<i<<" ";


	return 0;
}