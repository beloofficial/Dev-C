//������� ������ 
//������
#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#include<cmath>
#include<vector>
#include<string>
#include<string.h>
#include<utility>

using namespace std;

#define sz size()
#define mp make_pair
#define pb push_back
#define sqr(x) ((x)*(x))

int a[50], b[50], l[50], r[50];
int n, m, k, c = 0, res = 0, cur;

inline bool bit(int x, int i)
{
	return (x & (1 << i));
}

inline int check(int x)
{
	int obw = 0, r1 = 0;
	for (int i = 0; i < m; i++)
	{
		if (!bit(x, l[i]) && !bit(x, r[i]))		return 0;
		if (bit(x, l[i]) && bit(x, r[i]))
		{
			obw += a[l[i]] + a[r[i]];
			r1 += b[l[i]] + b[r[i]];
			if (obw > k)
				return 0;			
		}
	}            
	return r1;
}

inline void out(int x)
{
	for (int i = 0; i < n; i++)
		if (bit(x, i))
			printf("%d ", i + 1);
}

int main()
{
	freopen("A.in", "rt", stdin);
	freopen("A.out", "wt", stdout);
		scanf("%d%d%d", &n, &m, &k);
		for (int i = 0; i < n; i++)	scanf("%d", &a[i]);
		for (int i = 0; i < n; i++)	scanf("%d", &b[i]);
		for (int i = 0; i < m; i++)
		{
			scanf("%d%d", &l[i], &r[i]); 
			l[i]--;
			r[i]--;
		}
		for (int i = 1; i < (1 << n); i++)
		{
			cur = check(i);
			if (cur > res)
			{
				res = cur;
				c = i;
			}
		}
		out(c);
	return 0;
}
