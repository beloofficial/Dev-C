#include <iostream>
#include <ctime>
#include <vector>
#include <cstdlib>
#include <cstdio>
#include <fstream>

using namespace std;


typedef long long ll;
typedef long double ld;
typedef vector<int> vi;

#define pb push_back
#define mp make_pair
#define sz size()
#define len length()
#define f first
#define s second

double Time () {
	return double(clock()) / double(CLOCKS_PER_SEC);
}
int n, m;
vector <int> g[1000];
vector <int> g1[1000];

int p[1100];
bool u[1100];

bool dfs (int x) {
	if (u[x]) return 0;
	u[x] = 1;
	for (int i = 0; i < g[x].sz; i++) {
		int j = g[x][i];
		if (p[j] == -1 || dfs(p[j])) {
			p[j] = x;
			return 1; 
		}
	}
	return 0;	
}
int res[1000]={0};
void dfs1 (int x, int c) {
	u[x] = 1;
	res[x] = c;
	for (int i = 0; i < g1[x].sz; i++)
		if (!u[g1[x][i]]) dfs1 (g1[x][i], c^1);
}
//#define debug

int main () 
{
	freopen ("C.in", "r", stdin);
	freopen ("C.out", "w", stdout);
	
	cin >> n >> m;
	int N = m+n;
	for (int i = 0; i < n; i++) {
		int k, x;
		cin >> k;
		for (int j = 0; j < k; j++)
			cin >> x, x += n, g[i].pb (x-1);
	}
	for (int i = 0; i < m; i++) {
		int k, x;
		cin >> k;
		for (int j = 0; j < k; j++)
			cin >> x, g[i+n].pb(x-1);
	}
	#ifdef debug
	for (int i = 0; i < N; i++){
		for (int j = 0; j < g[i].sz; j++)	cout << g[i][j] << " ";
		cout << endl;
		}
	#endif
	for (int i = 0; i < N; i++) p[i] = -1;
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < N; j++)   u[j] = 0;
		dfs (i);
	}
	for (int i = 0; i < N; i++){
		if (p[i] != -1) g1[i].pb (p[i]), g1[p[i]].pb (i);
		u[i] = 0;
	}
	int resf = 0, ress = 0;
	
	for (int i = 0; i < N; i++)
		if (!u[i]) dfs1(i,1);
	for (int i = 0; i < n; i++) resf += res[i];
	for (int i = n; i < N; i++) ress += res[i];
	cout << ress+resf << " " << resf << " " << ress << endl;
	for (int i = 0; i < n; i++) 
		if (res[i] == 1) cout << i+1 << " "; 
	cout << endl;
	for (int i = n; i < N; i++)
		if (res[i] == 1)	cout << i+1-n << " ";
	return 0;
}