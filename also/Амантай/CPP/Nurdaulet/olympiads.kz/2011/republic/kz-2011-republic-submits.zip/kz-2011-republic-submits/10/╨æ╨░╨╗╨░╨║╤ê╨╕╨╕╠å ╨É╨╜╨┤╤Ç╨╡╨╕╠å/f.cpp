//Solution by Balakshy Andrey 17.04.11

#include <cstdio>
#include <iostream>
#include <vector>
#include <cmath>
#include <cstdlib>
#include <algorithm>
#include <queue>
#include <memory.h>

using namespace std;

#define pb push_back
#define mp make_pair
#define ff first
#define ss second
#define For(i, p1, p2, st) for (int i = (int)p1; i < (int)p2; i += (int)st)
#define FoR(i, p1, p2, st) for (int j = (int)p1; i > (int)p2; i -= (int)st)  

const int num = 100001;

int kol;
int n, m, ai, aj, k, l;
bool used[100001];
char c;

struct graf{
 pair <int,int> str;
  int head; 
   graf(){ head = 1; str.ff = -1; str.ss = -1; }
} gr[num];

void read()
{
 cin >> n >> m; 
  For(i, 0, m, 1){
   scanf("%d%d", &ai, &aj);
     gr[i].str.ff = ai; 
      gr[i].str.ss = aj; 
  }
}

int FindInd(int nom)
{
 For(i, 0, n, 1)
  if ((gr[i].str.ff == nom || gr[i].str.ss == nom) && !used[i]) {
   used[i] = true; return i;
  } 
}

int findStreet(const int &kand, const int &ot, const int &doo)
{
  int per = ot, ind = FindInd(ot), kol = 0, sk = 1;
 while(per != doo){
     if (sk == 1){ 
   if (per == gr[ind].str.ss){
    per = gr[ind].str.ff; 
     if (gr[ind].head == kand) kol++; sk++; 
   }
    else{
     per = gr[ind].str.ss; 
      if (gr[ind].head == kand) kol++; sk++;  
       if (per == doo) break; 
    }
     }
    else ind = FindInd(per), sk = 1;
 }
  return kol;
}

int main()
{
 freopen("F.in", "r", stdin);
  freopen("F.out", "w", stdout); 

   read(); 

    cin >> k;
     For(i, 0, k, 1) {     
      scanf("\n%c", &c); 
       switch(c){
        case 'q':{ scanf("%d%d%d", &ai, &aj, &l);
         memset(used, false, sizeof(used));
          kol = findStreet(l, ai, aj);
           printf("%d\n", kol);  
         break;
        }
        case '+':{ scanf("%d%d", &ai, &aj);
	  gr[aj - 1].head = ai;
	 break;
	}
       }

     }   

  return 0;
}
