//Kushibar Kaisar
#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include <cctype>
#include <cstdio>
#include <ctime>
#include <cmath>
#include <set>
#include <map>

#define fname "F"
#define sz 300000
using namespace std;

//int head[sz], val[sz], next[sz], 
int a[3000][3000], b[3][sz];
int n, m, k, x, y, q, c, l, r, ans;
struct que{
	int d, cnt, f;
}lst[sz+sz];
char ch;

int get(int x, int y, int k){
int res, c;
que t;
bool ok[sz];
	for(int i=1; i<=n; i++)ok[i]=0;
	l=1; r=1; lst[1].d=x; lst[1].cnt=0; lst[1].f=0;
	while(1){
		t=lst[l];
		if(t.d==y){
			res=t.cnt;
			c=t.f;
			break;
		}
		for(int i=1; i<=n; i++)
		if(!ok[i] && a[t.d][i]>0){
			ok[i]=1;
			r++;
			lst[r].d=i; lst[r].cnt=t.cnt+1; 
			if(a[t.d][i]==1)lst[r].f=t.f+1; else lst[r].f=t.f;
		}
		l++;
	}
	if(k==1)return c; else return res-c;
}

int main(){
	freopen(fname".in","r",stdin);
	freopen(fname".out","w",stdout);
	scanf("%d%d\n", &n, &m);
//	for(int i=1; i<=n; i++)head[i]=-1;
	for(int i=1; i<=m; i++){
		scanf("%d%d\n", &x, &y);
		b[1][i]=x; b[2][i]=y;
//		printf("asd %d %d %d %d\n", x, y, b[1][i], b[2][i]); 
		a[x][y]=1; a[y][x]=1;
	}
	scanf("%d\n",&k);
	for(int i=1; i<=k; i++){
		scanf("%c", &ch);
		if(ch=='q'){
			scanf("%d%d%d\n", &x, &y, &c);
			ans=get(x, y, c);
			printf("%d\n",ans);
		} else {
			scanf("%d%d\n", &x, &y);
//			cout << "x y " << x << " " << y << endl;
			l=b[1][y]; r=b[2][y];
//			cout << "l r " << l << " " << r << endl<<endl;
			a[l][r]=x; a[r][l]=x;
		}    
	}
//	for(int i=1; i<=m; i++)printf("%d %d\n", b[1][i], b[2][i]);
//	for(int i=1; i<=n; i++, printf("\n"))
//		for(int j=1; j<=n; j++)printf("%d ", a[i][j]);
	return 0;
}
