//Kushibar Kaisar
#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include <cctype>
#include <cstdio>
#include <ctime>
#include <cmath>
#include <set>
#include <map>

#define fname "B"
using namespace std;

struct mass{
	int d[50][50];
};
int n, a[50][50], ans[50][50], s;
mass b, c;

void rec(int x, int y, mass b, mass c){
	if(y>n){
//		for(int i=1; i<=n; i++,printf("\n"))
//			for(int j=1; j<=n; j++)printf("%d ", b.d[i][j]);
		int buf=0;
		for(int i=1; i<=n; i++)
			for(int j=1; j<=n; j++)
				if(b.d[i][j])buf+=a[i][j];
//		   	cout << buf << " " << s << endl << endl;
		if(buf>s){
			s=buf;
			for(int i=1; i<=n; i++)
				for(int j=1; j<=n; j++)ans[i][j]=b.d[i][j];
		}
    	} else {
    		int xx, yy;
		b.d[x][y]=1;
		c.d[x][y]=1;
		for(int i=1; i<=n; i++)c.d[x][i]=1, c.d[i][y]=1;
		xx=x+1; yy=y+1;
		while(xx<=n && yy<=n){
			c.d[xx][yy]=1;
			xx++; yy++;
		}
		xx=x-1; yy=y-1;
		while(xx>0 && yy>0){
			c.d[xx][yy]=1;
			xx--; yy--;
		}
		xx=x+1; yy=y-1;
		while(xx<=n && yy>0){
			c.d[xx][yy]=1;
			xx++; yy--;
		}
		xx=x-1; yy=y+1;
		while(xx>0 && yy<=n){
			c.d[xx][yy]=1;
			xx--; yy++;
		}
		if(y+1>n)rec(1, y+1, b, c); else 
		for(int i=1; i<=n; i++)
			if(c.d[i][y+1]==0)rec(i, y+1, b, c);
    	}
}

int main(){
	freopen(fname".in","r",stdin);
	freopen(fname".out","w",stdout);
	scanf("%d",&n);
	for(int i=1; i<=n; i++)
		for(int j=1; j<=n; j++)scanf("%d", &a[i][j]);
	s=0;

	for(int i=1; i<=n; i++)rec(i, 1, b, c);

    	for(int i=1; i<=n; i++, printf("\n"))
    		for(int j=1; j<=n; j++)printf("%d ", ans[i][j]);
	return 0;
}
