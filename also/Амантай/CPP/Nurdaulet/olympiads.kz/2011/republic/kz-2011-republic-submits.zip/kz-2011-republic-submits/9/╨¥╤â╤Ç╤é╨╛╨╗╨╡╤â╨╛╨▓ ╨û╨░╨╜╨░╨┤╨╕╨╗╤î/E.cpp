#include <iostream>
#include <algorithm>
#include <fstream>
#include <vector>
#include <cmath>

using namespace std;

#define pb push_back
#define fi first
#define se second

int main(){
	freopen ("E.in", "r", stdin);
	freopen ("E.out", "w", stdout);
	int a, b, c, l, r, p;
	long long res = 0;
	scanf("%d %d %d %d %d %d", &a, &b, &c, &l, &r, &p);
	for (int i = l;i <= r;i++)
		res = (res + (long long)((long long)(i - a)*(long long)(i - b)*(long long)(i - c)))%p;
	cout << res;
}
