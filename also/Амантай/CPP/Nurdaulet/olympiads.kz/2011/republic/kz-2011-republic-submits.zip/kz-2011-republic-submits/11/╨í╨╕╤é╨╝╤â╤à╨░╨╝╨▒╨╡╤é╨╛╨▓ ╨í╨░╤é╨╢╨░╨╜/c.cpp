#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
const int  N = 1009;
int n, a[N][N], o[N], b[N][N], m, nn, mm, ok, c[N], d[N], u[N], st[N];
void go(int k, int l) {
	int i, tt, j;
	if (ok == 0) {
		if (k == 0) {                         
			ok = 1;
			for (i = 1; i <= m; i++)
				c[i] = d[i];
		}
		else {
			for (i = l; i <= mm - k + 1; i++) {
				d[k] = u[i];
				tt = 1;
				for (j = k + 1; j <= m; j++) 
					if (b[d[k]][d[j]] == 0)
						tt = 0;
				if (tt)	
					go(k - 1, i + 1);
		   	}
   		}
   	}
}
int main () 
{
	int  i, j, x, y, l, r;
	freopen("C.in", "r", stdin);
	freopen("C.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for (i = 1; i <= n; i++) {
		scanf("%d", &x);
		for (j = 1; j <= x; j++) {
			scanf("%d", &y); 
			a[i][y + n] = 1;
		} 
	}
	for (i = 1; i <= m; i++) {
		scanf("%d", &x);
		for (j = 1; j <= x; j++) {
			scanf("%d", &y);
			a[i + n][y] = 1;
		}
	}
	nn = n + m;
	for (i = 1; i <= nn; i++) {
		for (j = 1; j <= nn; j++) {
			if (a[i][j] + a[j][i] == 0)
				b[i][j] = 1;
			st[i] += b[i][j];
		}
		st[i]--;
		b[i][i] = 0;
	}	
//	for (i = 1; i <= nn; i++)    {
//		for (j = 1; j <= nn; j++) 
//			printf("%d ", b[i][j]);
//		puts("");
//	} puts("");

//	for (i = 1; i <= nn; i++)
//		printf("%d ", st[i]); puts("");
	l = 0; r = nn + 1;
	for ( ; r - l > 1; ) {
		m = (l + r) / 2;
		mm = 0;
		for (i = 1; i <= nn; i++)
			if (st[i] >= m - 1)
				u[++mm] = i;
//		for (i = 1; i <= mm; i++)
//			printf("%d ", u[i]); puts("");
//		printf("m = %d mm = %d\n", m, mm);
		if (mm < m) r = m;
		else {
			ok = 0;
			go(m, 1);
			if (ok) l = m;
			else r = m;
		}
	}      mm = 0;
	for (i = 1; i <= l; i++)
		if (c[i] > n)
			mm++;
	printf("%d %d %d\n", l, l - mm, mm);
	for (i = l; i > 0; i--)
		if (c[i] <= n) 
			printf("%d ", c[i]);
	puts("");
	for (i = l; i > 0; i--)
		if (c[i] > n) 
			printf("%d ", c[i]);
                                        		
}                            