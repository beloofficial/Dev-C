#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <ctime>

using namespace std;

typedef long long ll;

long long a, b, c, l, r, p, res;
int xcube, xsquare, x;
int csum, ssum;

int c1, c2;

ll mul (ll a, ll b)
{
 	return (a*b)%p;
}

ll get (ll n)
{
	ll ret = 0;
	ret = mul ((n*(n+1)/2)%p, c2);
	ll v1 = n, v2 = n+1, v3 = 2*n+1;
	if (v1 % 3 == 0) v1 /= 3;
	else if (v2 % 3 == 0) v2 /= 3;
	else v3 /= 3;

	if (v1 % 2 == 0) v1 >>= 1;
	else v2 >>= 1;

	ret -= mul (c1, mul (mul (v1, v2), v3));
	return ret%p;
}

struct matrix
{
	int a[10][10];
	int c[10][10];
	matrix () {memset (a, 0, sizeof (a));}
	void operator *= (const matrix &b)
	{
	 	for (int i = 0, j, k; i < 5; i++)
	 		for (j = 0; j < 5; j++)
	 		{
	 			c[i][j] = 0;
	 			for (k = 0; k < 5; k++) (c[i][j] += (a[i][k]*1ll*b.a[k][j])%p)%=p;
         }
      for (int i = 0, j; i < 5; i++)
      	for (j = 0; j < 5; j++)
      		a[i][j] = c[i][j];
	}
};

ll getpow (int n)
{
	if (!n) return 0;

	matrix a, res;
	for (int i = 0; i < 5; i++)
		res.a[i][i] = 1;
	a.a[0][0] = a.a[1][1] = a.a[2][2] = a.a[3][3] = a.a[4][4] = 1;
	a.a[0][3] = a.a[1][3] = a.a[2][3] = a.a[4][0] = 1;
	a.a[0][1] = a.a[0][2] = 3;
	a.a[1][2] = 2;

	ll ret = 0;

	for (; n>0;)
		if (n & 1)
			n--,
			res *= a;
		else
			n >>= 1,
			a *= a;

	for (int i = 0; i < 4; i++)
		ret += res.a[4][i];

	return ret%p;
}

int main ()
{
	freopen ("E.in", "r", stdin);
	freopen ("E.out", "w", stdout);

	cin >> a >> b >> c >> l >> r >> p;

	c1 = (a+b+c)%p;
	c2 = (mul (a, b)+mul (a, c)+mul (b, c))%p;

	res = (get (r)-get (l-1)+p)%p;

	res += getpow (r)-getpow (l-1);
	res -= mul (mul (a, mul (b, c)), r-l+1);
	res %= p;
	if (res < 0) res += p;

	printf ("%d\n", res);

	return 0;
}
