#include <iostream>
#include <algorithm>
#include <utility>
#include <iomanip>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <string.h>
#include <math.h>
#include <numeric>
#include <time.h>
using namespace std;
	int a, b, c, l, r, p;
	long long res = 0;
int main () {
	freopen ("E.in", "r", stdin);
	freopen ("E.out", "w", stdout);
	scanf ("%d%d%d%d%d%d", &a, &b, &c, &l, &r, &p);
	for (l; l <= r; l++) {
		res += ((l - a) * (l - b) * (l - c)) * 1ll;
	}
	printf ("%I64d", res % (p * 1ll));
	return 0;
} 