#include <set>
#include <map>
#include <cmath>
#include "dist.h"
//#include <brain.h>
#include <vector>
#include <cstdio>
#include <cstdlib>
#include <string.h>
#include <iostream>
#include <algorithm>
using namespace std;

#define sz(a) (a).size()
#define pb push_back
#define mp make_pair

const int W = int(1e9);

int x,y,l,r;
double d1,d2,d3;

int main()
{
	start();

	l = -W; r = W;
	while (l <= r)
	{
		x = (l + r) / 2;
		d1 = dist(x,0);
		d2 = dist(x-1,0);
		d3 = dist(x+1,0);
		if (d1<d2 && d1<d3) break;
		if (d2<d3)
			r = x-1;
		else
			l = x+1;
	}

	l = -W; r = W;
	while (l <= r)
	{
		y = (l + r) / 2;
		d1 = dist(x,y);
		d2 = dist(x,y-1);
		d3 = dist(x,y+1);
		if (d1<d2 && d1<d3) break;
		if (d2<d3)
			r = y-1;
		else
			l = y+1;
	}

	finish(x,y);
	return 0;
}
