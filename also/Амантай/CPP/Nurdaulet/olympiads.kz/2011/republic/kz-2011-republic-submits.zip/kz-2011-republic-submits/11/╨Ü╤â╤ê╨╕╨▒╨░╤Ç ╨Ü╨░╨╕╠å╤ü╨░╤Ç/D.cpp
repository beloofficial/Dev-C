//Kushibar Kaisar
#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include <cctype>
#include <cstdio>
#include <ctime>
#include <cmath>
#include <set>
#include <map>

#define fname "D"
#define sz 2000000
using namespace std;

struct tree{
	set <int> a;
} a[sz];
set <int> :: iterator pos;
int n, m, k, l, r, b;

int get(int l, int r, int c, int k, int t){
	if(l>k || r<c)	return 0;
	if(l<=c && k<=r) return a[t].a.size();
	return get(l, r, c, (c+k)/2, 2*t)+get(l, r, (c+k)/2+1, k, 2*t+1);
}

int main(){
//	cerr << time(0) << endl;
	freopen(fname".in","r",stdin);
	freopen(fname".out","w",stdout);
	scanf("%d%d",&n, &m);
//	printf("%d %d\n", n, m);
	k=1; while(k<n)k*=2;
	// printf("%d\n", k);
	for(int i=1; i<=n; i++){
		scanf("%d", &b);
          a[k+i-1].a.insert(b);
    	}
    	for(int i=k-1; i>0; i--){
    		if(a[2*i].a.size()>0)a[i]=a[2*i];
    		if(a[2*i+1].a.size()>0){
    			for(pos=a[2*i+1].a.begin(); pos!=a[2*i+1].a.end(); pos++){
    				b=*pos;
    				a[i].a.insert(b);
    			}
    		}
    	}
    //	for(int i=1; i<=2*k-1; i++)printf("%d ", a[i].a.size()); printf("\n");
    	for(int i=1; i<=m; i++){
    		scanf("%d%d", &l, &r);
    		b=get(k+l-1, k+r-1, k, 2*k-1, 1);
    		printf("%d\n", b);
    	}
//    	cerr << time(0) << endl;
	return 0;
}
