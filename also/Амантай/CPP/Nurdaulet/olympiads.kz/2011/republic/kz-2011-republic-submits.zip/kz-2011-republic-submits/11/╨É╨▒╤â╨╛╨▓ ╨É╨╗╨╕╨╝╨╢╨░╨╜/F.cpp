#include <iostream>
#include <cstdio>
#include <vector>
#include <string>
#include <cstring>
#include <cmath>
#include <map>
#include <algorithm>
#include <set>
#include <cctype>
#include <stack>

using namespace std;

const double pi = acos((double) - 1);
const int maxn = 8;

struct edge {
	int c, v, n;
};

bool cmp(pair <int, int> i, pair <int, int> j) {
	return i.second < j.second;
}

int main() {
	
	freopen("F.in", "r", stdin);
	freopen("F.out", "w", stdout);

	int n, m, x, y, cur;
	bool w1[maxn], w2[maxn];

	cin >> n >> m;

	for (int i = 0; i <= n; i++)
		w1[i] = w2[i] = 0;

	vector <edge> v[maxn];
	map <int, pair<int, int> > edges;
	edge buf;

	for (int i = 1; i <= m; i++) {
		cin >> x >> y;
		buf.c = 1;
		buf.n = i;
		buf.v = y;
		v[x].push_back(buf);
		buf.v = x;
		v[y].push_back(buf);
		if (y < x) swap(x, y);
		edges[i] = make_pair(x, y);
	}

	vector <int> s;
	vector <pair <int, int> > t;
	map <int, int> mm;
	bool ok;
	int tt = 0;

	s.push_back(1);
	while ((int) s.size() > 0) {
	 	cur = s.back();
	 	if (w1[cur]) {
			tt++;
	 		mm[cur] = tt;
	 		t.push_back(make_pair(tt, cur));
	 		s.pop_back();
	 	}
	 	w1[cur] = 1;
	 	for (int i = 0; i < (int) v[cur].size(); i++)
	 		if (!w1[v[cur][i].v]) {
	 			s.push_back(v[cur][i].v);
	 			ok = 1;
	 			break;
	 		}
	}

	stable_sort(t.begin(), t.end(), cmp);

	/*for (int i = 1; i <= n; i++)
		cout << mm[i] << ' ';
	cout << endl;
	for (int i = 0; i < t.size(); i++)
		cout << t[i].first << ' '; */

	int k, c, l, r;
	char ch;
	cin >> k;
	while (k > 0) {
		cin >> ch;
		if (ch == 'q') {
			cin >> x >> y >> c;
			l = mm[x];
			r = mm[y];
			if (l < r) swap(l, r);
		} else {
			cin >> y >> c;
			x = edges[y].first;
			for (int i = 0; i < (int) v[x].size(); i++)
				if (v[x][i].n == y) {
					v[x][i].c = c;
					break;
				}
			x = edges[y].second;
			for (int i = 0; i < (int) v[x].size(); i++)
				if (v[x][i].n == y) {
					v[x][i].c = c;
					break;
				}
		}
		k--;
	}

	cout << 2 << endl << 1;

	return 0;
}
