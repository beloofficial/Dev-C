//Zhienbek Shyngys 9 Astana KTL
#include<iostream>
#include<utility>
#include<map>
#include<cmath>
#include<math.h>
#include<stdio.h>
#include<stdlib.h>
#include<algorithm>
#include<cstdio>
#include<cstdlib>
#include<fstream>
#include<string>
#include<string.h>
#include<sstream>
#include<limits>
#include<assert.h>
#define inf numeric_limits<int> :: max()
#define For(i,a,b) for(int i=a;i<=b;i++)
using namespace std;

struct wow
 {
  int s,f;
 } h[1000001];

long long qw;
int c=0,n,m,d[1001][1001],p[1001][1001],a[1001][1001];

void swa(int x,int y)
 {
  swap(h[x].f,h[y].f);
  swap(h[x].s,h[y].s);
  p[h[x].f][h[x].s]=x; p[h[y].f][h[y].s]=y;
 }

void down(int x)
 {
  while (x<c)
   {
    int x1=x;
    if (x*2<=c && d[h[x].f][h[x].s]>d[h[x*2].f][h[x*2].s]) x1=x*2;
    if (x*2+1<=c && d[h[x1].f][h[x1].s]>d[h[x*2+1].f][h[x*2+1].s]) x1=x*2+1;
    if (x1!=x)
     {
      swa(x1,x);
      x=x1;
     } else break;
   }
 }

void up(int x)
 {
  while (x>1)
   {
    if (d[h[x].f][h[x].s]<d[h[x/2].f][h[x/2].s])
     {
      swa(x,x/2);
      x/=2;
     } else break;
   }
 }

void del()
 {
  h[1].f=h[c].f;
  h[1].s=h[c].s;
  c--;
  down(1);
 }

void add(int x,int y)
 {
  c++;
  h[c].f=x;
  h[c].s=y;
  p[x][y]=c;
  up(c);
 }

void djxtra()
 {
  add(1,1);
  while (c)
   {
    if (d[h[1].f+1][h[1].s]==inf)
     {
      d[h[1].f+1][h[1].s]=a[h[1].f+1][h[1].s]+d[h[1].f][h[1].s];
      add(h[1].f+1,h[1].s);
     } else
    if (d[h[1].f+1][h[1].s]>d[h[1].f][h[1].s]+a[h[1].f+1][h[1].s])
     {
      d[h[1].f+1][h[1].s]=d[h[1].f][h[1].s]+a[h[1].f+1][h[1].s];
      up(p[h[1].f+1][h[1].s]);
     }
    if (d[h[1].f][h[1].s+1]==inf)
     {
      d[h[1].f][h[1].s+1]=a[h[1].f][h[1].s+1]+d[h[1].f][h[1].s];
      add(h[1].f,h[1].s+1);
     } else
    if (d[h[1].f][h[1].s+1]>d[h[1].f][h[1].s]+a[h[1].f][h[1].s+1])
     {
      d[h[1].f][h[1].s+1]=d[h[1].f][h[1].s]+a[h[1].f][h[1].s+1];
      up(p[h[1].f][h[1].s+1]);
     }
    if (d[h[1].f][h[1].s-1]==inf)
     {
      d[h[1].f][h[1].s-1]=a[h[1].f][h[1].s-1]+d[h[1].f][h[1].s];
      add(h[1].f,h[1].s-1);
     } else
    if (d[h[1].f][h[1].s-1]>d[h[1].f][h[1].s]+a[h[1].f][h[1].s-1])
     {
      d[h[1].f][h[1].s-1]=d[h[1].f][h[1].s]+a[h[1].f][h[1].s-1];
      up(p[h[1].f][h[1].s-1]);
     }
    del();
   }
 }

int main()
{
 #ifndef ONLINE_JUDGE
  freopen("H.in","rt",stdin);
  freopen("H.out","wt",stdout);
 #endif

  scanf("%d%d",&n,&m);
  For(i,1,n)
   {
    For(j,1,m)
     {
      d[i][j]=inf;
      scanf("%d",&a[i][j]);
     }
   }
  scanf("%I64d",&qw);
  d[1][1]=0;
  djxtra();
  printf("%I64d",qw-(long long)d[n][m]);

 fclose(stdin);fclose(stdout);
 return 0;
}
