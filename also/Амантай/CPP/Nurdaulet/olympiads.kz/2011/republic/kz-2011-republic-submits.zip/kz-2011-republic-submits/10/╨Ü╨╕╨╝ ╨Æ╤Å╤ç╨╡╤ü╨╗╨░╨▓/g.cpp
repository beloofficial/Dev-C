// O, velikiy System Judge!
// Posshadi menya! Plzplzplzplzplz
#include <cstdio>
#include "dist.h"
#include <cmath>
#include <cstdlib>

int cur;
double tr (int x)
{
	int l, r, ll, rr;
	double d1, d2;
	l = -1000000000;
	r = 1000000000;
	for (int i = 0; i < 2498 && l < r; i++)
	{
		ll = l + (r - l + 1) / 3;
		rr = ll + (r - l + 1) / 3;
		d1 = dist(x, ll);
		d2 = dist(x, rr);
		if (d1 < d2)
			r = rr;
		else l = ll;	
    }         
	d1 = dist(x, l);
	d2 = dist(x, r);
	if (d1 < d2){
		cur = l;
		return d1;
	}
	else 
	{
		cur = r;
		return d2;
	}
}
        
main ()
{                        
	start();
	int l, r, ll, rr;
   	double d1, d2;
	l = -1000000000;
	r = 1000000000;
	tr(0);
	for (int i = 0; i < 2000 && l < r; i++)
	{
		ll = l + (r - l + 1) / 3;
		rr = ll + (r - l + 1) / 3;
		d1 = dist(ll, cur);
		d2 = dist(rr, cur);
		if (d1 < d2)
			r = rr;
		else l = ll;	
    }             
   	int c1, c2, X, Y;
   	d1 = dist(ll, cur);
   	d2 = dist(rr, cur);
    if (d1 < d2)
    {
    	X = l; Y = cur;
    }
    else { X = r; Y = cur;}
    double mn = 1000000000;
    for (int i = Y - 100; i <= Y + 100; i++){
    	d1 = dist(X, i);
    	if (d1 < mn){
    		mn = d1; Y = i;
    	}
    }
    finish(X + 1, Y);
//	printf("%d %d", X + 1 - ansx, Y - 1- ansy);                                   
}

