#include <algorithm>
#include <iostream>
#include <cstring>
#include <cassert>
#include <cstdlib>
#include <string>
#include <vector>
#include <cstdio>
#include <cmath>
#include <ctime>
#include <set>
#include <map>

#define inf (int)1e9
#define EPS 1e-6
#define file "D"

typedef long long ll;
typedef long double ld;

using namespace std;

int a[100200];

int main() {

	freopen(file".in", "r", stdin);
	freopen(file".out", "w", stdout);

	int n, m;

	scanf("%d%d", &n, &m);

	for (int i = 0; i < n; ++i)
		scanf("%d", &a[i]);

 	for (int i = 0; i < m; ++i) {

 		int x, y;

 		scanf("%d%d", &x, &y);

 		set <int> s;

 		for (int j = x - 1; j < y; ++j)
 			s.insert(a[j]);

 		printf("%d\n", s.size());

 	}

	return 0;

}