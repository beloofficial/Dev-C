// Zhalpakov Daulet
#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
#include <vector>
#include <cmath>
#include <map>
using namespace std;

int A, B, C, L, R, P;

int main()
{
	freopen("E.in", "r", stdin);
	freopen("E.out", "w", stdout);
	
	scanf("%d %d %d %d %d %d", &A, &B, &C, &L, &R, &P);

	long long res = 0;

	for (; L <= R; ++L) {
		res = (res + 1ll*(((L-A)*(L-B)%P)*(L-C))%P) % P;
	}

	cout << res << endl;

	return 0;
}
