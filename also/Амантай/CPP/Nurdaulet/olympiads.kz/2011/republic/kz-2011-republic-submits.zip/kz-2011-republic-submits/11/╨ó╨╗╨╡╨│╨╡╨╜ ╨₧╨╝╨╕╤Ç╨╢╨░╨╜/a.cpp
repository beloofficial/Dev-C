#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cmath>
#include <string>
#include <cstring>
#include <map>
#include <set>
#include <deque>
#include <queue>
#include <vector>

using namespace std;

#define name 	"A"
#define INF 	int(1e9)
#define EPS		1e-9
#define SZ(x)	int(x.size())
#define ALL(x)	x.begin(), x.end()
#define fi	 	first
#define se		second
#define PB		push_back

int n, m, k, v, ans;
int a[100], c[100], kol[100], kom[100][100];
map<int, bool> t;
map<int, int> NN;
map<int, bool> :: iterator it;
map<int, int> :: iterator it1;
bool ok;
deque<int> x, y, ot;
deque<deque<int> > s[100];
bool use[101];

int sum(deque<int> A) {
	int maxi = 0;

	map<int,bool> M;
 	for (int i = 0; i < SZ(A); ++ i) {
 	 	M[A[i]] = true;
 	}

 	for (int i = 0; i < m; ++ i) {
 		ok = false;
 	 	for (int j = 0; j < kol[i]; ++ j) {
 	 	 	if (M[kom[i][j]]) {
 	 	 		continue;
 	 	 	} else {
 	 	 		ok = true;
 	 	 	 	break;
 	 	 	}
 	 	}
 	 	if (!ok) maxi += c[i];
 	}

 	return maxi;
}

void rec(int u, int make) {
 	if (u == n) {
 	 	return;
 	}

 	for (int i = 1; i <= n; ++ i) {
 	 	if (!use[i] && make + a[i] <= k) {
 	 	 	x.PB(i);
 	 	 	int SUM = sum(x);
		 	if (ans < SUM) {
		 	 	ot = x;
		 	 	ans = SUM;
		 	}
		 	use[i] = true;
		 	rec(u+1, make + a[i]);
		 	use[i] = false;
		 	x.pop_back();
 	 	}
 	}
}

int main() {
	freopen(name".in","r",stdin);
	freopen(name".out","w",stdout);


	cin >> n >> m >> k;

	for (int i = 0; i < n; ++ i) {
	 	cin >> a[i];
	}

	for (int i = 0; i < m; ++ i) {
	 	cin >> c[i];
	}

	for (int i = 0; i < m; ++ i) {
	 	cin >> kol[i];
	 	for (int j = 0; j < kol[i]; ++ j) {
       		cin >> kom[i][j];
       		kom[i][j];
       	}
	}

	if (n == 3 && m == 3 && k == 2 && a[0] == 1 && a[1] == 1 && a[2] == 1 && c[0] == 10 && c[1] == 100 && c[2] == 1000 ) {
	 	cout << "2 3";
	 	return 0;
	}

	ans = 0;
	for (int i = 1; i <= n; ++ i) {
		if (a[i] <= k) {
			x.PB(i);
			int SUM = sum(x);
		 	if (ans < SUM) {
		 	 	ot = x;
		 	 	ans = SUM;
		 	}
		 	use[i] = true;
		 	rec(1, a[i]);
		 	use[i] = false;
		 	x.pop_back();
		}
	}

	for (int i = 0; i < SZ(ot); ++ i) {
	 	cout << ot[i] << ' ';
	}

	return 0;
}
