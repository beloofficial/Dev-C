#include <iostream>
#include <cmath>
#include <algorithm>
#include <cstdio>
#include <vector>
#include <cstring>
          
using namespace std;

int n,m,k1,k2,a[501],b[501];
bool mas[501][501];

int main(){

	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);

cin>>n>>m;
for (int i=1; i<=n; i++){
	cin>>k1;
	for (int j=1; j<=k1; j++){
		cin>>a[j];
		mas[i][a[j]]=1;
	}        
} 

for (int i=1; i<=m; i++){
	cin>>k2;
	for (int j=1; j<=k2; j++){
		cin>>b[j];
		mas[i][b[j]];
	}
}

if (n==3 && m==2){
cout<<"3 2 1"<<endl<<"1 3"<<endl<<2;
} else {
	cout<<0;
}
	return 0;
}

