#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <string>
#include <vector>
#include <cstdio>
#include <set>
#include <map>


using namespace std;

int n,m;
int l,r,mcnt;    
int a[100200];

void findcount(int l, int r){
	
map<long long, int>cnt;

 mcnt = r - l + 1;
 
	for (int i=l; i<=r; i++) 
		
	if ( cnt[a[i]] == 0 ) cnt[a[i]]++; else 
	if ( cnt[a[i]] > 0 ) mcnt--;       
                               
	
	printf("%d\n",mcnt);
}


int main(){
        freopen("D.in","r",stdin);
	freopen("D.out","w",stdout);
	 
	scanf("%d%d",&n,&m);
	
		for (int i=1; i<=n; i++)
			scanf("%d",&a[i]);
		        

	for (int i=1; i<=m; i++){		
	int mcnt = 0;	
		scanf("%d%d",&l,&r);
	       
		findcount(l,r);
        }        
		
fclose(stdout);
return 0;
}