#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>

using namespace std;

#define pb push_back()
#define fi first
#define se second

bool v[15], g[15], x[15], y[150];
int ress = 0;
int n;
int a[15][15];
vector < vector < bool > > res;
	
void rec(int k, vector < vector < bool > > vv){
	if (k == n){
		int sum = 0;
		for (int i = 0;i < n;i++)
			for (int j = 0;j < n;j++)
				if (vv[i][j])
					sum += a[i][j];
		if (sum > ress)
			ress = sum, res = vv;
		return;
	}
	for (int j = 0;j < n;j++){
		if (v[j] || x[k + j] || y[k - j + 75])
			continue;
		v[j] = g[k] = x[k + j] = y[k - j + 75] = 1;
		vv[k][j] = 1;
		rec(k + 1, vv);
		v[j] = g[k] = x[k + j] = y[k - j + 75] = 0;
		vv[k][j] = 0;
	}
}

int main(){
	freopen ("B.in", "r", stdin);
	freopen ("B.out", "w", stdout);
	cin >> n;
	for (int i = 0;i < n;i++)
		for (int j = 0;j < n;j++)
			cin >> a[i][j];
	vector < vector < bool > > v(n, vector < bool > (n, 0));
	rec(0, v);
	for (int i = 0;i < n;i++, cout << endl)
		for (int j = 0;j < n;j++)
			cout << res[i][j] << " ";
}