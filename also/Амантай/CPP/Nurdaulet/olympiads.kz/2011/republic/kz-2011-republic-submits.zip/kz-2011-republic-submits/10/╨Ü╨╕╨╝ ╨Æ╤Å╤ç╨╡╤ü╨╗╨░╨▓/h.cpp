// O, velikiy System Judge!
// Posshadi menya! Plzplzplzplzplz
#include <cstdio>
#include <queue>
#include <cstring>
#include <iostream>

using namespace std;
            #define top front
typedef unsigned long long ll;
int n, m;
ll a[300][300], b[300][300];
ll c[300][300];
queue<int>qx, qy;
int d[] = {0, 1, 0, -1, 1, 0};

bool check(int x, int y)
{
	return x >= 0 && x < n && y >= 0 && y < m;
}

ll calc(int x, int y)
{
	ll &res = c[x][y];
	if (y == 1){return (res = 1);}
	if (x == y){res = 1;return res;}
	if (x < y){res = 0;return res;}	
	if (res)
		return res;
	for (int i = 1; i < x; i++)
		res += calc(x - i, y - 1);
	return res;
}

char s[1200];
struct L
{
	int a[1200];
	int n;
	L(){n = 1; for (int i = 0; i < 1200; i++)a[i] = 0;}
	L(ll X)
	{
		n = 0;
		for (;X;n++, X /= 10)
			a[n] = X % 10;
		for (int i = n; i < 1200; i++)
			a[i] = 0;
	}
	void get()
	{
		scanf("%s", s);
		n = strlen(s);
		for (int i = 0; i < n; i++)
			a[i] = s[n - i - 1] - '0';
	}
	void put()
	{
		if(!n)n = 1;
		for (int i = n - 1; i >= 0; i--)
			cout << a[i];

	}
	void operator -= (L b)
	{
		ll carry = 0, t;
		for (int i = 0; i < 1200; i++){
			t = a[i] - b.a[i] - carry;
			carry = 0;
			a[i] = t;
			if (a[i] < 0){
				carry = 1;
				a[i] += 10;
			} 	
		}
		n = 1200;
		for(; !a[n -1]; n--);
			
	}
}ans;

int main ()
{
	freopen("H.in", "r", stdin);
	freopen("H.out", "w", stdout);
	cin >> n >> m;
	for (int i = 0; i < n; i++)
		for (int j = 0; j< m; j++)
		{	cin >> a[i][j];b[i][j] = (1LL << 63);}
//	cin >> ans;
	ans.get();
	b[0][0] = 0;           
	qx.push(0);qy.push(0);
	while(!qx.empty())
	{
		int x = qx.top(), y = qy.top();
		qx.pop(); qy.pop();
//		cout << x << " " << y << " = "<< b[x][y]<<endl;
		for (int i = 0; i < 6; i+=2)
		{
			int dx = x + d[i], dy = y + d[i + 1];
			if (check(x, y) && b[dx][dy] > a[dx][dy] + b[x][y] * calc(max(dx + 1, dy + 1), min(dx + 1, dy + 1)))
			{
				b[dx][dy] = a[dx][dy] +  b[x][y] * calc(max(dx + 1, dy + 1), min(dx + 1, dy + 1));
			 
				qx.push(dx);qy.push(dy);
			}
		}
	}
	L hh(b[n - 1][m - 1]);    

	ans -= hh;
	ans.put();      
		return 0;
}

