// Dyussupov Dauren 11 class Atyrau
#include<cstdio>
#include<iostream>
#include<cmath>
#include<cstdlib>
#include<cstring>
#include<set>
#include<map>
#include<vector>
#include<algorithm>
#include<ctime>

using namespace std;

#define F first
#define S second
#define sf scanf
#define pf printf
#define N 110000

bool fl;
int e[2 * N], prev[2 * N], z[2 * N], f[N], was[N]; 

void dfs(int x, const int stop, const int who, int num, const int col)
{
	was[x] = col;
	if (x == stop)
	{
		fl = 1;
		printf("%d\n", num);
	}

	if (fl) return;

	int pos = f[x];

	while (pos)
	{
		if (was[e[pos]] != col)
		{
			if (z[pos] == who) dfs(e[pos], stop, who, num + 1, col); else 
							   dfs(e[pos], stop, who, num, col);	
		}
		if (fl) return;
		pos = prev[pos];
	}
}

int main()
{
	freopen("F.in", "r", stdin);
	freopen("F.out", "w", stdout);

	int n, m, len = 0, i, k, l, r, w, num, x, y;
	char ch;

    scanf("%d%d", &n, &m);

    for (i = 1; i <= m; i++)   
    {
    	scanf("%d%d", &x, &y);
    	e[++len] = y;
    	z[len] = 1;
    	prev[len] = f[x];
    	f[x] = len;

    	e[++len] = x;
    	z[len] = 1;
    	prev[len] = f[y];
    	f[y] = len;
    }

    scanf("%d\n", &k);

    for (i = 0; i < k; i++)
    {
    	scanf("%c", &ch);

    	if (ch == 'q')
    	{
    		scanf("%d%d%d\n", &l, &r, &w);
    		fl = 0;
    		dfs(l, r, w, 0, i + 1);
    	} else
    	{
    		scanf("%d%d\n", &w, &num);
    		z[num * 2 - 1] = w;
    		z[num * 2] = w;
    	}
    }

	return 0;
}