#include<iostream>
#include<fstream>
#include<string>
using namespace std;
int main()
{
freopen("A.in","r",stdin);
freopen("A.out","w",stdout);
int n,m,k,c[25][25],i,j,t=0,h[25],d[25];
long long p,a[25],b[25],mx=0;
string s;
cin>>n>>m>>k;
for(i=1;i<=n;i++) cin>>a[i],h[i]=d[i]=0;
for(i=1;i<=m;i++) cin>>b[i],c[i][0]=0;
getline(cin,s);
for(i=1;i<=m;i++)
{
getline(cin,s);
s+=' ';
for(j=0;j<s.length();j++)
{
if(s[j]>='0' && s[j]<='9') t=t*10+s[j]-'0';
else
{
if(t)
{
c[i][0]++;
c[i][c[i][0]]=t;
}
t=0;
}
}
}
h[0]=0;
while(!h[0])
{
p=0;
for(i=1;i<=n;i++)
{
if(h[i]) p+=a[i];
}
if(p<=k)
{
p=0;
for(i=1;i<=m;i++)
{
for(j=1;j<=c[i][0];j++)
{
if(!h[c[i][j]]) break;
}
if(j>c[i][0]) p+=b[i];
}
if(p>mx)
{
mx=p;
for(i=1;i<=n;i++) d[i]=h[i];
}
}
j=n;
h[j]++;
while(h[j]>1)
{
h[j]=0;
j--;
h[j]++;
}
}
for(i=1;i<=n;i++)
{
if(d[i]) cout<<i<<" ";
}
return 0;
}