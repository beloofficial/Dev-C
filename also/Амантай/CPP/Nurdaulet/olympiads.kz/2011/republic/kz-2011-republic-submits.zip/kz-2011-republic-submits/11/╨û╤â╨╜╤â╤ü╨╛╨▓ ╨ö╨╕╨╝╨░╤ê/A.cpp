#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <string>
#include <cstring>
#include <set>
#include <map>
#include <stdio.h>

#define pb push_back
#define mp make_pair
#define se second
#define fi first
#define all(a) a.begin(),a.end()
#define name "A"

using namespace std;

long long n,m,k;
long long a[100],b[100];
long long sum[100],mas[100];
vector<long long> nab[100];
string s;
map<long long,long long> use,par;
vector<long long> pac;
            
vector<long long> f(string s) {
	vector<long long> d;
	int uk = 0;
	int x = 0;
	while(uk < s.length()) {
		if(s[uk] == ' ') {
			d.pb(x-1);
			x = 0;
		}
		else {	
			x = x*10 + (int)(s[uk])-48;
		}
        ++ uk;
	}

	if(x > 0)
		d.pb(x-1);

	return d;
}

long long find_uk(long long s) {
	for(int i = 0; i < m; ++ i) {
		if(sum[i] == s)
			return i+1;
	}
	return 0;
}

int main() {

	freopen(name".in","r",stdin);
	freopen(name".out","w",stdout);	
    
    cin >> n >> m >> k;
    for(int i = 0; i < n; ++ i) {
    	cin >> a[i];
    }

    for(int i = 0; i < n; ++ i) {
    	cin >> b[i];
    }

    scanf("\n");

    for(int i = 0; i < m; ++ i) {
    	getline(cin,s);
    	nab[i] = f(s);
    	for(int j = 0; j < nab[i].size(); ++ j) {
    		mas[i] += a[nab[i][j]];
    		sum[i] += b[nab[i][j]];
    	}
    }

    use[0] = 0;
    pac.pb(0);

    for(int i = 0; i < m; ++ i) {
    	for(int j = 0; j < pac.size(); ++ j)    	
    		if(pac[j] + mas[i] <= k && use[pac[j] + mas[i]] < use[pac[j]] + sum[i]) {
    			if(use[pac[j] + mas[i]] == 0) {
    				pac.pb(pac[j] + mas[i]);
    				par[pac[j] + mas[i]] = pac[j];
                    use[pac[j] + mas[i]] = use[pac[j]] + sum[i];
    			} else {
    				par[pac[j] + mas[i]] = pac[j];
                    use[pac[j] + mas[i]] = use[pac[j]] + sum[i];
    			}       
    		}    		
    }
/*
    for(int i = 0; i < pac.size(); ++ i) {
    	cout << pac[i] << ' ';
    }
    cout << "\n";

    for(int i = 0; i < pac.size(); ++ i) {
    	cout << use[pac[i]]-use[par[pac[i]]] << ' ';
    }
    cout << "\n";
*/
    set<long long> ans;

    for(int i = 0; i < pac.size(); ++ i) {
    	long long k = find_uk(use[pac[i]]-use[par[pac[i]]]);
//    	cout << k << endl;
    	if(k)
	    	for(int j = 0; j < nab[k-1].size(); ++ j)
    			ans.insert(nab[k-1][j]+1);
    }

    while(!ans.empty()) {
    	cout << *ans.begin() << ' ';
    	ans.erase(ans.begin());
    }

	return 0;
}

	