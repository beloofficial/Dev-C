#include<cstdio>
using namespace std;

long long int res,a,b,c,l,r,p;
                        
int main()
{
freopen("E.in","r",stdin);
freopen("E.out","w",stdout);

scanf("%d%d%d%d%d%d",&a,&b,&c,&l,&r,&p);

for(int i=l;i<=r;i++){
res+=((i-a)*(i-b)*(i-c))%p;
res%=p;}

printf("%lld",res);


return 0;
}

