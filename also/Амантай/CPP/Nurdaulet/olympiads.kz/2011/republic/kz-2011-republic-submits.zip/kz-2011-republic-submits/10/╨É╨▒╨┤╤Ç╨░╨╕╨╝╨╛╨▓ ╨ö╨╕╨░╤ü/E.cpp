#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <cstdio>
#include <cstdlib>
#include <math.h>
#include <string>
#include <string.h>
#include <vector>
#include <queue>
#include <deque>
#include <list>
#include <set>
#include <map>
#include <algorithm>
#include <limits>
#include <utility>

#define FOR(i,a,b) for (int i=a; i<=b; i++)
#define FORD(i,a,b) for (int i=a; i>=b; i--)
#define INF numeric_limits <int> :: max()
#define p_b push_back
#define m_p make_pair

using namespace std;
int a,b,c,l,r,p,ans;

   int f(int x)
    {
     return (((x-a)%p *(x-b)%p)%p *(x-c)%p)%p;
    }

int main()
{
freopen("E.in","rt",stdin);
freopen("E.out","wt",stdout);
scanf("%d %d %d %d %d %d",&a,&b,&c,&l,&r,&p);
ans=0;
FOR(i,l,r)
ans=(ans%p+f(i)%p)%p;
cout<<ans%p;

fclose(stdin); fclose(stdout);
return 0;
}    