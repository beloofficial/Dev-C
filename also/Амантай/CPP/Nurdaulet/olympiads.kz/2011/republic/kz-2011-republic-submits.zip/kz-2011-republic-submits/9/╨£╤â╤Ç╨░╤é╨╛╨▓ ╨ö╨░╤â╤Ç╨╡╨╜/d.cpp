#include <set>
#include <cstdio>
#include <iostream>

using namespace std;

#define maxn 100005

int n, m;
int a[maxn];
set <int> Q;

int main() {
	freopen("D.in", "r", stdin);
	freopen("D.out", "w", stdout);

	scanf("%d %d\n", &n, &m);
	for (int i = 0; i < n; i++) {
	 	scanf("%d", &a[i]);
	}
	while (m--) {
	    int l, r; scanf("%d %d\n", &l, &r); --l, --r;
	    Q.clear();
		for (int i = l; i <= r; i++)	                                                 	
			Q.insert(a[i]);
		printf("%d\n", Q.size());
	}

	return 0;
}