#include<algorithm>
#include<iostream>
#include<utility>
#include<cstdlib>
#include<cstring>
#include<string>
#include<cstdio>
#include<vector>
#include<ctime>
#include<cmath>
#include<new>
#include<map>
using namespace std;
const int N = 1000;
#define max(a,b) (a<b?b:a)
#define min(a,b) (a<b?a:b)
#define cl(a,b) memset(a,b,sizeof(a));
#define pb push_back
#define mp make_pair
#define F first
#define S second 
int n,m,p1[N],d[N],x,i,j,t,p2[N];
bool was[N];
struct way
{
	int num,list[N],ans,cur;
	bool w;


}; way a[N];
bool cmp(way l,way r) 
{
	return l.num > r.num;
}
int main () {
	freopen("C.in","r",stdin);
	freopen("C.out","w",stdout);
	scanf("%d%d\n",&n,&m);
	for (i = 1; i <= n; i++) {
		scanf("%d",&t);
		for (j = 1; j <= t; j++) { 
			scanf("%d",&x);
			a[i].list[j] = n+x;
	        }
	        a[i].ans = i;
	        a[i].cur = i;
	        a[i].num = t;
	        scanf("\n");
	}
	for (i = 1; i <= m; i++) {
		scanf("%d",&t);
		for (j = 1; j <= t; j++) {
			scanf("%d",&x);
			a[n+i].list[j] = x; 
		}
		a[n+i].w = true;
		a[n+i].num = t;
		a[n+i].ans = i;
		a[n+i].cur = n+i;
		scanf("\n");
	}
	sort(a+1,a+n+m+1,cmp);
	int k1=0,k2=0;
	for (i = 1; i <= n+m; i++) d[a[i].cur] = i;
	for (i = 1; i <= n+m; i++) {
		if (a[i].num > 0) { 
			was[a[i].cur] = true;
			int k=1;
			while (a[i].list[k] != 0) {
				if (!was[a[i].list[k]])  {
					int pos = d[a[i].list[k]];
					a[pos].num--;
				}
				k++;
			}
		} else {
			if (!a[i].w) p1[++k1] = a[i].ans; 
			        else p2[++k2] = a[i].ans; 
		}
	}
	printf("%d %d %d\n",k1+k2,k1,k2);
	for (i = 1; i <= k1; i++) printf("%d ", p1[i]);
	printf("\n");
	for (i = 1; i <= k2; i++) printf("%d ", p2[i]);
	                         
 return 0;
}
