//������� ������ 
//������
#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#include<cmath>
#include<vector>
#include<string>
#include<string.h>
#include<utility>
#include<algorithm>
#include<queue>

using namespace std;

#define sz size()
#define mp make_pair
#define pb push_back
#define sqr(x) ((x)*(x))
#define base 1000000000
#define F first
#define S second
int n, m;
long long kol[201][201], x;

void init()
{
	memset(kol, 0, sizeof(kol));
	kol[1][1] = 1;
	for (int i = 2; i <= max(n, m); i++)
		for (int j = 1; j <= i; j++)
			kol[i][j] = kol[i - 1][j] + kol[i - 1][j - 1];
}

long long a[201][201], res[201][201], s;

void bfs()
{
	bool u[201][201];
	queue<pair<int, int> > q;
	q.push(mp(1, 1));
	res[1][1] = 0;
	u[1][1] = 1;
	long long temp;
	while(!q.empty())
	{
		int i = q.front().F;
		int j = q.front().S;
		q.pop();
		temp = (res[i][j] * kol[max(i, j)][min(i, j)]) + a[i][j];

		if ( i == n && j == m)	break;
		if ( i == 1 && j == 1)	temp = 0;
		if (j + 1 <= m)
		{
			if (!u[i][j + 1])	
			res[i][j + 1] = temp, u[i][j + 1] = 1, q.push(mp(i, j + 1)); else	
				if (temp < res[i][j + 1])
					res[i][j + 1] = temp,  u[i][j + 1] = 1, q.push(mp(i, j + 1));
		}

		if (j - 1 > 0)
		{
			if (!u[i][j - 1]) 		res[i][j - 1] = temp, u[i][j - 1] = 1, q.push(mp(i, j - 1)); else
				if (temp < res[i][j - 1])
					res[i][j - 1] = temp, u[i][j - 1] = 1, q.push(mp(i, j - 1));
		}
	
		if (i + 1 <= n)
		{
			if (!u[i + 1][j])		res[i + 1][j] = temp,u[i + 1][j] = 1, q.push(mp(i + 1, j)); else
				if (temp < res[i + 1][j])                  
					res[i + 1][j] = temp, u[i + 1][j] = 1, q.push(mp(i + 1, j));
		}
	}
}

int main()
{
	freopen("H.in", "rt", stdin);
	freopen("H.out", "wt", stdout);
		scanf("%d%d", &n, &m);
		for (int i = 1; i <= n; i++)
			for (int j = 1; j <= m; j++)
			{
				scanf("%I64d", &x);
				a[i][j] = x;
			}
		scanf("%I64d", &s);
		init();
		bfs();
		cout<<s - res[n][m] * kol[max(n, m)][min(n, m)] - a[n][m];
	return 0;
}
