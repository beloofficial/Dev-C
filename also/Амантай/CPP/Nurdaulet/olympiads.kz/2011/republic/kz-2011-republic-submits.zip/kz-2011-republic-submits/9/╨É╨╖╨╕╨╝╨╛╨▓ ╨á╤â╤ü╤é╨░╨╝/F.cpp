#include<iostream>
#include<fstream>
#include<queue>
#include<cstdio>
#include<vector>
#include<string>
#include<map>
#include<set>
#include<stack>
#include<cstdio>
using namespace std;
#define pb push_back
#define mk make_pair
#define f first
#define s second
      int qw,we,rt;
     vector< vector < int > > a;
        int x,y;
       int n,m;
  void bfs (int s,int kuda)
   {
    queue<int> q;
     bool used[100005];
          int d[100005];
      for(int i=0;i<n;i++){used[i]=false;d[i]=0;}
     q.push(s);
     d[s]=0;
     while(!q.empty()){
          int v=q.front();
          q.pop();
      // cout<<v<<endl;
       for(int i=0;i<a[v].size();i++)
         {
          int to=a[v][i];
           if (used[to]==false)
            {
             q.push(to);
             d[to]=d[v]+1;
             used[to]=true;
            }
         }
     }
        cout<<d[kuda]<<endl;
   }

int main ()
 {
    freopen ("F.in","r",stdin);
    freopen ("F.out","w",stdout);
       cin>>n>>m;
       a.resize(n*3);
        for(int i=0;i<m;i++)
          {
           cin>>x>>y;
           x--;y--;
           a[x].pb(y);
           a[y].pb(x);
          }
           int k;
           cin>>k;
           char l;
           for(int i=1;i<=k;i++)
            {
             cin>>l;
              if (l=='q')
                {
                cin>>qw>>we>>rt;
                qw--;
                we--;
                bfs(qw,we);
               // break;
                }
                else
                 {
                 int za,az;
                 cin>>az>>za;
                 }
            }
  return 0;
 }