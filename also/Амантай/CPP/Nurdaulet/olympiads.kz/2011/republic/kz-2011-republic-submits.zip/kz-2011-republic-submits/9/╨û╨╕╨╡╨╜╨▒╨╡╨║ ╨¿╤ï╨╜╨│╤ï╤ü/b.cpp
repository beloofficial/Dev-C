//Zhienbek Shyngys 9 Astana KTL
#include<iostream>
#include<utility>
#include<map>
#include<cmath>
#include<math.h>
#include<stdio.h>
#include<stdlib.h>
#include<algorithm>
#include<cstdio>
#include<cstdlib>
#include<fstream>
#include<string>
#include<string.h>
#include<sstream>
#include<limits>
#include<assert.h>
#define eps 1e-12
#define mp(x,y) make_pair(x,y)
#define inf numeric_limits<int> :: max()
#define For(i,a,b) for(int i=a;i<=b;i++)
#define FOR(i,a,b) for(int i=a;i>=b;i--)
using namespace std;

int n,a[101][101];

int main()
{
 #ifndef ONLINE_JUDGE
  freopen("B.in","rt",stdin);
  freopen("B.out","wt",stdout);
 #endif
  
  scanf("%d",&n);
  a[1][2]=1;
  a[2][4]=1;
  a[4][3]=1;
  a[3][1]=1;
  For(i,1,n) {
  For(j,1,n) printf("%d ",a[i][j]);
  printf("\n");  }
  
 fclose(stdin);fclose(stdout);
 return 0;
}
