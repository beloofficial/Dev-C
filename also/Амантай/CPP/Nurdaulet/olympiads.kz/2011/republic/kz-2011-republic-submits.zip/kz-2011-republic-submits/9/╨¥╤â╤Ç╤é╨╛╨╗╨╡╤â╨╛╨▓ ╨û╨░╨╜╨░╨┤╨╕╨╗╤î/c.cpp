#include <iostream>
#include <algorithm>
#include <utility>
#include <fstream>
#include <vector>
#include <cmath>
#include <queue>

using namespace std;

#define pb push_back()
#define fi first
#define se second

int main(){
	freopen ("C.in", "r", stdin);
	freopen ("C.out", "w", stdout);
	int n, m;
	long long a[100], b[100];
	fill(a, a + 100, 0ll);
	fill(b, b + 100, 0ll);
	scanf("%d%d", &n, &m);
	for (int i = 0;i < n;i++){
		int x;
		scanf("%d", &x);
		for (int j = 0;j < x;j++){
			int y;
			scanf("%d", &y);
			a[i] |= (1ll << (y - 1));
		}
	}
	for (int i = 0;i < m;i++){
		int x;
		scanf("%d", &x);
		for (int j = 0;j < x;j++){
			int y;
			scanf("%d", &y);
			b[i] |= (1ll << (y - 1));
		}
	}
	queue < pair < long long, long long > > q;
	q.push(make_pair(0, 0));
	while (!q.empty()){
		long long x = q.front().fi;
		long long y = q.front().se;
		q.pop();
		bool w = 0;
		for (int i = 0;i < n;i++){
			if (x & (1ll << i))
				continue;
			for (int j = 0;j < m;j++){
				if (y & (1ll << j))
					continue;
				if (a[i] & (1ll << j)){
					q.push(make_pair(x, y | (1 << j)));
					w = 1;
				}
				if (b[j] & (1ll << i)){
					q.push(make_pair(x | (1 << i), y));
					w = 1;
				}
			}
		}
	       if (!w){
	       	   int res = 0, fi = 0, se = 0;
	       	   for (int i = 0;i < n;i++)
	       	   	if(!(x & (1ll << i)))res++;
	       	   fi = res;
	       	   for (int i = 0;i < m;i++)
	       	   	if(!(y & (1ll << i)))res++;
	       	   se = res - fi;
	           printf("%d %d %d\n", res, fi, se);
	           for (int i = 0;i < n;i++)
	           	if (!(x & (1ll << i)))
	           		printf("%d ", i + 1);
	           printf("\n");
	           for (int i = 0;i < m;i++)
	           	if (!(y & (1ll << i)))
	           		printf("%d ", i + 1);
	           cout << endl;   
	       	  return 0;
	       }
	}               	       	   	

}