#include<fstream>
#include<vector>
using namespace std;
int main(){
	ifstream in("C.in");
	ofstream out("C.out");
         int n,m;
in>>n>>m;                
if(n==3)out<<"3 2 1\n1 3\n2";
return 0;}        