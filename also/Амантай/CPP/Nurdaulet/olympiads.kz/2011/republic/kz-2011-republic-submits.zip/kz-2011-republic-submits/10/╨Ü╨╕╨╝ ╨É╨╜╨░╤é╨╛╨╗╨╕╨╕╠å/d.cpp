#include <iostream>
#include <cmath>
#include <algorithm>
#include <cstdio>
#include <vector>
#include <cstring>
          
using namespace std;

int n,m,l,r,k;
int a[100005];

int num(int s, int e){
bool b[100005]={0};
k=0;
	for (int i=s; i<=e; i++){
		if (!b[a[i]]){
			k++;
			b[a[i]]=1;
		}
	}	
return k;
}

int main(){

	freopen("d.in","r",stdin);
	freopen("d.out","w",stdout);

	cin>>n>>m;
	for (int i=1; i<=n; i++)
		cin>>a[i];
    for (int i=1; i<=m; i++){
		cin>>l>>r;
		cout<<num(l,r)<<endl;
	}
                       
	return 0;
}