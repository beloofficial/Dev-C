#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <cstdio>
#include <cstdlib>
#include <math.h>
#include <string>
#include <string.h>
#include <vector>
#include <queue>
#include <deque>
#include <list>
#include <set>
#include <map>
#include <algorithm>
#include <limits>
#include <utility>

#define FOR(i,a,b) for (int i=a; i<=b; i++)
#define FORD(i,a,b) for (int i=a; i>=b; i--)
#define INF numeric_limits <int> :: max()
#define p_b push_back
#define m_p make_pair

using namespace std;
int n,m ,xx,yy,ans;

int dx[4]={0 , 0, 1 };
int dy[4]={-1, 1, 0 };
int d[201][201],a[201][201];

   struct  Tema
    {
     queue <int> x;
     queue <int> y;
    };

  Tema q;

int main()
{
freopen("H.in","rt",stdin);
freopen("H.out","wt",stdout);
scanf("%d %d\n",&n,&m);
FOR(i,1,n)
{
 FOR(j,1,m)
 {
 scanf("%d ",&a[i][j]);
 d[i][j]=INF;
 }
 scanf("\n");
}
cin>>ans;
d[1][1]=0;

 q.x.push(1); q.y.push(1);
 
  while (!q.x.empty())
   {
    xx=q.x.front();
    yy=q.y.front();
    q.x.pop();  q.y.pop();
    FOR(i,0,2)
     {
      if (xx+dx[i]>0 && yy+dy[i]>0 && xx+dx[i]<=n && yy+dy[i]<=m)
       {
        if (d[xx][yy]+a[xx+dx[i]][yy+dy[i]]<d[xx+dx[i]] [yy+dy[i]])
         {
          q.x.push(xx+dx[i]); q.y.push(yy+dy[i]);
          d[xx+dx[i]] [yy+ dy[i]]=d[xx][yy] +a[xx+dx[i]] [yy+dy[i]];
         }
       }
     }
   }


cout<<ans-d[n][m]-n;

fclose(stdin); fclose(stdout);
return 0;
}    