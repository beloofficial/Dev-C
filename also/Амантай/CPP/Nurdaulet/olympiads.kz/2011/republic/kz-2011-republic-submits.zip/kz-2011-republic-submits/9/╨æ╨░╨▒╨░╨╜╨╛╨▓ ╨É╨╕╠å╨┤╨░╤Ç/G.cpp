#include<fstream>
using namespace std;
ifstream in("G.in");
ofstream out("G.out");
int main(){
         int n,p;
	in>>n>>p;
	if(n>=p)out<<0;
	else {
	int fac=1;
	for(int i=1;i<=n;i++){
	fac*=i%p;
	fac=fac%p;
	if(fac==0){out<<0;return 0;}
}
out<<fac%p;   }
return 0;}