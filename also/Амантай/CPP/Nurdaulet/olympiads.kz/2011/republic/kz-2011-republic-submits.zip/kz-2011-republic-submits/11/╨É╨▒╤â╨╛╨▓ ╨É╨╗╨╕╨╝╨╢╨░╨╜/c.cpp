#include <iostream>
#include <cstdio>
#include <vector>
#include <string>
#include <cstring>
#include <cmath>
#include <map>
#include <algorithm>
#include <set>
#include <queue>

using namespace std;

const double pi = acos((double) - 1);
const int maxn = 510;

int main() {
	
	freopen("C.in", "r", stdin);
	freopen("C.out", "w", stdout);

	int n, m, y, j;
	vector <int> v[2 * maxn], comp[2 * maxn];
	bool a[maxn * 2];	
	cin >> n >> m;
	for (int i = 1; i <= n; i++) {
		cin >> j;
		for (j; j > 0; j--) {
			cin >> y;
			v[i].push_back(y + n);
		}
		a[i] = 1;
	}
	for (int i = n + 1; i <= n + m; i++) {
		cin >> j;
		for (j; j > 0; j--) {
			cin >> y;
			v[i].push_back(y);
		}
		a[i] = 1;
	}

	int c[2 * maxn];
	for (int i = 1; i <= n + m; i++)
		c[i] = 0;

	queue <int> q;
	int cc = 1, buf;
	for (int i = 1; i <= n + m; i++) {
		if (c[i] == 0) {
			q.push(i);
			while (!q.empty()) {
				buf = q.front();
				c[buf] = cc;
				comp[cc].push_back(buf);
				q.pop();
				for (int j = 0; j < (int) v[buf].size(); j++)
					if (c[v[buf][j]] == 0) q.push(v[buf][j]);
			}
			cc++;
		}
	}

	for (int i = 1; i <= cc; i++) {
		y = 0;
		for (int j = 0; j < (int) comp[i].size(); j++)
			if (comp[i][j] > n) y++;
		if (y >= (int) comp[i].size() - y) {
			for (int j = 0; j < (int) comp[i].size(); j++)
				if (comp[i][j] <= n) a[comp[i][j]] = 0;
		} else {
			for (int j = 0; j < (int) comp[i].size(); j++)
				if (comp[i][j] > n) a[comp[i][j]] = 0;
		}
   	}

/*   	for (int i = 1; i <= n + m; i++)
   		cout << a[i] << ' ';
   	cout << endl;
*/
   	int k1 = 0, k2 = 0;
   	for (int i = 1; i <= n; i++) {
   		if (a[i]) k1++;
	}
	for (int i = n + 1; i <= n + m; i++) {
		if (a[i]) k2++;
	}

	cout << k1 + k2 << ' ' << k1 << ' ' << k2 << endl;
	for (int i = 1; i <= n; i++) {
   		if (a[i]) cout << i << ' ';
	}
	cout << endl;
	for (int i = n + 1; i <= n + m; i++) {
		if (a[i]) cout << i - n << ' ';
	}

	return 0;
}
