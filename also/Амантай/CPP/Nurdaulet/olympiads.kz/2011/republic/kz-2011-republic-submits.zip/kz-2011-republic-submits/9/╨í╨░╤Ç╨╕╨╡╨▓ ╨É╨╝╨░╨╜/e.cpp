#include<iostream>
#include<fstream>
using namespace std;
int main()
{
freopen("E.in","r",stdin);
freopen("E.out","w",stdout);
unsigned long long a,b,c,l,r,s=0,p,u,t;
cin>>a>>b>>c>>l>>r>>p;
while(l<=r)
{
s=(s+(l-a)*(l-b)%p*(l-c))%p;
l++;
}
cout<<s;
return 0;
}