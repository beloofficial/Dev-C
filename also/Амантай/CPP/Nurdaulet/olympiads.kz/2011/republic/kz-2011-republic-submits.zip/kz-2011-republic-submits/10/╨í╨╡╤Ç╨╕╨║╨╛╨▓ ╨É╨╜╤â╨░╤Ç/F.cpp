// Solution by [A.S.]

#include <iostream>
#include <vector>
#include <fstream>

#define max_n 100000
         
using namespace std;

class road
{
	public:
	int v, id, person;
};

road make_road (int v1, int id1, int person1)
{
	road res;

	res.v = v1;
	res.id = id1;
	res.person = person1;

	return res;
}

vector <road > g[max_n];
int n, m, p[max_n];
bool u[max_n];
int ans, tx;

void trim()
{
	for (int i = 0; i < n; i++)
		u[i] = false;		
}

void dfs (int x)
{
	u[x] = true;

	for (int i = 0; i < g[x].size(); i++)
		if (!u[g[x][i].v])
			p[g[x][i].v] = x,
			dfs (g[x][i].v);
}       

void get_answer (int x, int y, int c)
{
	trim();
	
	dfs (x);
	
	tx = y, ans = 0;

        while (tx != x)
        {
        	for (int i = 0; i < g[tx].size(); i++)
        		if (g[tx][i].v == p[tx])
        		{
        			if (g[tx][i].person == c)
        				ans++;
        			break;
        		}

        	tx = p[tx];
        }  	

	printf ("%d\n", ans);
}

void modify (int x, int y)
{
	for (int i = 0; i < n; i++)
		for (int j = 0; j < g[i].size(); j++)
			if (g[i][j].id == y)
				g[i][j].person = x;
}

int main()
{
	freopen ("F.in", "r", stdin);
	freopen ("F.out", "w", stdout);

	int a1, b1, x, y, c;
	char command;

	scanf ("%d %d", &n, &m);
                                    
	for (int i = 0; i < m; i++)
	{
		scanf ("%d %d", &a1, &b1);

		g[a1 - 1].push_back (make_road (b1 - 1, i, 1));
		g[b1 - 1].push_back (make_road (a1 - 1, i, 1));
	}


	for (int i = 0; i < n; i++)
		p[i] = i;

	int k;

	scanf ("%d", &k);

	while (k--)
	{
		cin >> command;

		if (command == 'q')
		{
			scanf ("%d %d %d", &x, &y, &c);

			get_answer (x - 1, y - 1, c);
		}
		else
		{
			scanf ("%d %d", &x, &y);

			modify (x, y - 1);
		}		
	}

	return 0;
}
