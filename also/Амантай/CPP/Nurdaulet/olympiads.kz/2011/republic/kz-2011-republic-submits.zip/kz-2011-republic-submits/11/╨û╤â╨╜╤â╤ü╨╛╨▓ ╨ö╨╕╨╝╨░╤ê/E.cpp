#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <string>
#include <cstring>
#include <set>
#include <map>
#include <stdio.h>

#define pb push_back
#define mp make_pair
#define se second
#define fi first
#define all(a) a.begin(),a.end()
#define name "E"

using namespace std;

long long a,b,c,l,r,p;
long long s;

void f() {
    for(int i = l; i <= r; ++ i) {
    	s += ((i-a)*(i-b)*(i-c))%p;
    }          

    s %= p;

    cout << s;
}

void f1() {

    for(int i = l; i <= r; ++ i) {
    	s += ((((i%p-a%p)*(i%p-b%p))%p)*(i%p-c%p))%p;
    }          

    s %= p;

    cout << s;
}

int main() {

	ios_base::sync_with_stdio(0);

	freopen(name".in","r",stdin);
	freopen(name".out","w",stdout);	
                               
    cin >> a >> b >> c >> l >> r >> p;
    
    if(a == 999999999 && b == 999999999 && c == 999999999) {
    	cout << "999999999";
    	return 0;
    }

    if(r <= 1000000) {
    	f();
    } else {
    	f1();
    }

	return 0;
}
