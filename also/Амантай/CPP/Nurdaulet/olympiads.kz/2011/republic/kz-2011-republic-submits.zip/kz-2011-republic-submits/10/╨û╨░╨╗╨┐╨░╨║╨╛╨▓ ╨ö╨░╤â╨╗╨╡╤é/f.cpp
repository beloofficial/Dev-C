// Zhalpakov Daulet
#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
#include <vector>
#include <cmath>
#include <map>
using namespace std;

#define pb push_back
#define mp make_pair
#define fi first
#define se second

struct Position {
	int ax, ay, bx, by;
} pos[101000];

int n, m, d[101000], q[100100];
bool was[101000];
vector < pair <int, int> > g[101000];

int res (int s, int f, int k)
{
	memset(was, 0, sizeof(was));
	was[s] = 1;
	d[s] = 0;
	q[0] = s;

	for (int l = 0, r = 1, v; l < r; ++l) {
		v = q[l];
		for (int i = 0; i < g[v].size(); ++i) {
			if (!was[g[v][i].fi]) {
				was[g[v][i].fi] = 1;
				d[g[v][i].fi] = d[v] + (g[v][i].se == k);
				q[r++] = g[v][i].fi;
			} 
			if (was[f]) return d[f];
		}	
	}
}	

int main()
{
	freopen("F.in", "r", stdin);
	freopen("F.out", "w", stdout);

	scanf("%d%d", &n, &m);
	for (int i = 1, x, y; i <= m; ++i) {
		scanf("%d%d", &x, &y);	
		   	
		g[x].pb(mp(y, 1));
	    g[y].pb(mp(x, 1));
		pos[i].ax = x;
		pos[i].ay = g[x].size() - 1;	               
		pos[i].bx = y;
		pos[i].by = g[y].size() - 1;
	}

	int t, x, y, k;
	scanf("%d\n", &t);
	while (t--) {
		char ch;
		scanf("%c ", &ch);	

		if (ch == '+') {
		    scanf("%d %d\n", &x, &y);

			g[pos[y].ax][pos[y].ay].se = x;
			g[pos[y].bx][pos[y].by].se = x;
		} else {
			scanf("%d%d%d\n", &x, &y, &k);
			
			printf("%d\n", res(x,y,k));
		}	
	}

	return 0;
}
