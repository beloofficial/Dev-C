#include <cstdio>
#include <iostream>
using namespace std;

int a, b, c, s, l, r, p, x;

void Int()
{
	for (x = l; x <= r; x++)
		s = (s + (x-a) % p * (x-b) % p * (x-c) % p) % p;
}

void Int64()
{
	for (x = l; x <= r; x++)
		s = (s + 1ll * (x-a) * (x-b) % p * 1ll * (x-c) % p) % p;
}

int main()
{
	freopen("E.in", "r", stdin);
	freopen("E.out", "w", stdout);
	scanf("%d %d %d %d %d %d", &a, &b, &c, &l, &r, &p);
	if (p <= 45000) Int(); else Int64();
	printf("%d\n", s);
	return 0;
}
