#include<iostream>
#include<fstream>
using namespace std;
int n,a[105][105],k=0,t[105],us[105];
void dfs(int v,int u)
{
int i;
t[v]=u;
us[v]=1;
for(i=1;i<=n;i++)
{
if(a[i][v] || a[v][i])
{
if(!us[i]) dfs(i,u^1);
else t[i]&=(u^1);
}
}
}
void md(int v)
{
int y[105],usd[105],i,k1=0,k2=0;
for(i=1;i<=n;i++) y[i]=t[i],usd[i]=us[i];
dfs(v,1);
for(i=1;i<=n;i++)
{
if(!usd[i] && us[i]) k1+=t[i],t[i]=y[i];
us[i]=usd[i];
}
dfs(v,0);
for(i=1;i<=n;i++)
{
if(!usd[i] && us[i]) k2+=t[i],t[i]=y[i];
us[i]=usd[i];
}
if(k1>k2) dfs(v,1);
else dfs(v,0);
}
int main()
{
freopen("C.in","r",stdin);
freopen("C.out","w",stdout);
int m,i,j,k1=0,k2=0;
cin>>n>>m;
for(i=1;i<=n;i++)
{
us[i]=t[i]=0;
for(j=1;j<=n+m;j++) a[i][j]=0;
cin>>k;
while(k)
{
k--;
cin>>j;
a[i][j+n]=1;
}
}
n+=m;
m=n-m;
for(;i<=n;i++)
{
us[i]=t[i]=0;
for(j=1;j<=n;j++) a[i][j]=0;
cin>>k;
while(k)
{
k--;
cin>>j;
a[i][j]=1;
}
}
for(i=1;i<=n;i++)
{
if(!us[i]) md(i);
}
for(i=1;i<=n;i++)
{
if(t[i] && i<=m) k1++;
if(t[i] && i>m) k2++;
}
cout<<k1+k2<<" "<<k1<<" "<<k2<<endl;
for(i=1;i<=m;i++) if(t[i]) cout<<i<<" ";
cout<<endl;
for(i=m+1;i<=n;i++) if(t[i]) cout<<i-m<<" ";
return 0;
}