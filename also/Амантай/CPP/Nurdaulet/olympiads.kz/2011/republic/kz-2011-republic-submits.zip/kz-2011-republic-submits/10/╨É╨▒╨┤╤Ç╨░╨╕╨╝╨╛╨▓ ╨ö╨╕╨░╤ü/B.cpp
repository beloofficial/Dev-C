#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <cstdio>
#include <cstdlib>
#include <math.h>
#include <string>
#include <string.h>
#include <vector>
#include <queue>
#include <deque>
#include <list>
#include <set>
#include <map>
#include <algorithm>
#include <limits>
#include <utility>

#define FOR(i,a,b) for (int i=a; i<=b; i++)
#define FORD(i,a,b) for (int i=a; i>=b; i--)
#define INF numeric_limits <int> :: max()
#define p_b push_back
#define m_p make_pair
//#define debug

using namespace std;
int n,a[20][20],ans[20][20];
bool used[20][20];
int sum,mx=0,k;
bool bo;
vector <int> q,w;

     void move(int x, int y)
      {
      q.p_b(x);  w.p_b(y);
       used[x][y]=true;

       FOR(i,1,n)
        used[x][i]=true, used[i][y]=true;

       int sum=x+y,tp=0;
       while (sum)
        {
         sum--;
         tp++;
         used[sum][tp]=true;
        }
        int xx=x,yy=y;
        while (xx>0 && yy>0)
        xx--,yy--,used[xx][yy]=true;
        xx=x,yy=y;
        while (xx<n && yy<n )
        xx++,yy++,used[xx][yy]=true;  
      }

         void rec(int x, int y)
          {
          k++;
          move(x,y);
       #ifdef debug
       cout<<endl;
        FOR(t,1,n)
        {
        FOR(tt,1,n) cout<<used[t][tt]<<" ";
        cout<<endl;
        }
        cout<<endl;
       #endif
            

           if (k<n) 
           {
           FOR(i,1,n)
           FOR(j,1,n)
           if (!used[i][j]) rec(i,j),sum+=a[i][j];
           }
          }

int main()
{
freopen("B.in","rt",stdin);
freopen("B.out","wt",stdout);
 scanf("%d\n",&n);
 FOR(i,1,n)
  {
   FOR(j,1,n)
   scanf("%d ",&a[i][j]);
   scanf("\n");
  }

    FOR(i,1,n)
    {
     FOR(j,1,n)
      {
       q.clear();  w.clear();
       memset(used,0,sizeof(used));
       sum=a[i][j]; k=0;
       rec(i,j);
        
        if (sum>mx && k==n)
         {
         mx=sum;
         memset(ans,0,sizeof(ans));
          FOR(z,0,q.size()-1)
          ans[q[z]][w[z]]=1;
         }
      }
     }

   FOR(i,1,n)
    {
     FOR(j,1,n) printf("%d ",ans[i][j]);
     printf("\n");
    }

fclose(stdin); fclose(stdout);
return 0;
}    