// O, velikiy System Judge!
// Posshadi menya! Plzplzplzplzplz
#include <cstdio>
#include <ctime>

#define bit(x,y) ((x>>(y))&1)
int n, c[30][30], a[30], ans[30], ma, hor, di, dg, sum;
bool go (int x);
int main ()
{
	freopen("B.in", "r", stdin);
	freopen("B.out", "w", stdout);
	
	scanf("%d", &n);
	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)
			scanf("%d", &c[i][j]);
	go(0);
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
			printf("%d ", bit(ans[i], j));puts("");
	}
	return 0;
}
bool go (int x){
	for (int i = 0; i < n; i++)if (!bit(hor,i) && !bit(di, i + x) && !bit(dg, i + n - x - 1))
	{
	        hor |= (1<<i);
		di |= (1 << (i + x));
		dg |= (1 << (i + n - x - 1));
		sum += c[x][i];
		a[x] |= (1 << i);
		if (x == n - 1)
		{
			if (sum > ma)
			{
				ma = sum;
				for (int j = 0; j < n; j++)
					ans[j] = a[j];
			}
			if (double(clock())/double(CLOCKS_PER_SEC) >= 1.8)
				 return 1;
		}
		else if(go(x + 1))return 1;
	        hor ^= (1<<i);
		di ^= (1 << (i + x));
		dg ^= (1 << (i + n - x - 1));
		sum -= c[x][i];
		a[x] ^= (1 << i);
	}
}

