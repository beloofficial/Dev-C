#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <cstdio>
#include <cstdlib>
#include <math.h>
#include <string>
#include <string.h>
#include <vector>
#include <queue>
#include <deque>
#include <list>
#include <set>
#include <map>
#include <algorithm>
#include <limits>
#include <utility>

#define FOR(i,a,b) for (int i=a; i<=b; i++)
#define FORD(i,a,b) for (int i=a; i>=b; i--)
#define INF numeric_limits <int> :: max()
#define p_b push_back
#define m_p make_pair

using namespace std;
int n,m, s[3100000], next[3100000], head[3100000], q[3100000], w[3100000],c[10001][10001],x,y,dep,k,res,tp,d[3100000];
char ch;


/*   void dfs(int v, int f)
    {
    used[v]=true;
    cout<<v<<" ";
    if (v!=f)
     {
     int j=head[v];
//      if (!j) res=0;
      while (j)
       {
        if (!used[s[j]]) 
        {
        if (c[v][s[j]]==dep ) res++;
  //      cout<<s[j]<<" ";
        //if (s[head[s[j]]]!=v) 
        dfs(s[j],f);
        }
       j=next[j]; 
       }
     } 
    }
  */

    int bfs(int start, int finish,int dep)
     {
       queue <int> q;
       int i,j,kol=0;
       q.push(start);
        while (!q.empty())
         {
          i=q.front(); q.pop();
          j=head[i];
           while (j)
            {
             if (d[s[j]]>d[i]) d[s[j]]=d[i]+1,q.push(s[j]);
            j=next[j];
            }
         }

        q.push(finish);
        while (!q.empty())
         {
         i=q.front(); q.pop();
         j=head[i];
          while (j)
           {
            if (d[s[j]]==d[i]-1) 
            {
            q.push(s[j]);
            if (c[i][s[j]]==dep) kol++;
            }
            j=next[j];
           }
         }
        return kol;
     }

   int ans(int start, int finish, int dep)
    {
      res=tp=0;
      FOR(i,1,n) d[i]=INF;
      d[start]=0;
      return bfs(start,finish,dep);
    }
    
int main()
{
freopen("F.in","rt",stdin);
freopen("F.out","wt",stdout);
scanf("%d %d\n",&n,&m);

 FOR(i,1,m)
  {
  scanf("%d %d\n",&x,&y);
  s[i]=y;
  next[i]=head[x];
  head[x]=i;

  s[i+m]=x;
  next[i+m]=head[y];
  head[y]=i+m;
  c[x][y]=1;
  c[y][x]=1;
  q[i]=x; w[i]=y;
  }
  scanf("%d\n",&k);
//  FOR(i,1,12)
//  cout<<s[i]<<" "<<next[i]<<" " <<head[i]<<"\n";
  FOR(i,1,k)
   {
   scanf("%c",&ch);
   if (ch=='+') scanf(" %d %d\n",&dep,&x),c[q[x]][w[x]]=dep,c[w[x]] [q[x]]=dep; else
   if (ch=='q') scanf(" %d %d %d\n",&x,&y,&dep),printf("%d\n",ans(x,y,dep));
   }

fclose(stdin); fclose(stdout);
return 0;
}    