#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <vector>
#include <set>
#include <queue>
#include <deque>
#include "dist.h"

#define pb			push_back
#define mp			make_pair
#define eps			1e-9
#define sqr(x)  	((x)*(x))
#define rep(i, x)   for(int i = 0; i < x; ++ i)
#define sz			size()
#define fi			first
#define se			second
#define name		""

using namespace std;
typedef long long LL;
typedef pair <int, int> Pair;
/*
int ansx , ansy ;
int zapr = 0;

double dist(int x, int y){
	zapr++;	
	return sqrt(1.0*sqr((x-ansx)) + 1.0*sqr((y-ansy)));

}

void finish(int x, int y) {
	if(zapr > 10000) {
		cout << "WA";
		exit(0);
	}

	if (x == ansx && y == ansy) {
		cout << "OK\n" << zapr;
		exit(0);
	}
}      
*/
int main() {
	
	start();
/*
    int dx, dy;
	bool ok = false;
	cin >> ansx >> ansy;
*/
	LL lx = -100000, rx = 100000;
	LL ly = -100000, ry = 100000;
	LL mx, my;

	do {
		mx = (lx+rx)/2;
		my = (ly+ry)/2;
//		cout << mx << ' '<< my << endl;

		if (dist(lx, mx) - dist(mx, rx) > eps)
			lx = mx;
		else
			rx = mx;

		if (dist(ly, my) - dist(my, ry) > eps)
			ly = my;
		else
			ry = my;
					
	} while (dist(mx, my) != 0.00000000);
		

	finish(mx, my);




	return 0;
}

