//Zhienbek Shyngys 9 Astana KTL
#include<iostream>
#include<utility>
#include<map>
#include<cmath>
#include<math.h>
#include<stdio.h>
#include<stdlib.h>
#include<algorithm>
#include<cstdio>
#include<cstdlib>
#include<fstream>
#include<string>
#include<string.h>
#include<sstream>
#include<limits>
#include<assert.h>
#define inf numeric_limits<int> :: max()
#define For(i,a,b) for(int i=a;i<=b;i++)
using namespace std;

long long a,b,c,l,r,p,ans=0;

int main()
{
 #ifndef ONLINE_JUDGE
  freopen("E.in","rt",stdin);
  freopen("E.out","wt",stdout);
 #endif
  
  scanf("%I64d%I64d%I64d%I64d%I64d%I64d",&a,&b,&c,&l,&r,&p);
  For(i,l,r) ans+=(((i-a)%p)*((i-b)%p)%p*((i-c)%p)%p);
  printf("%I64d",ans%p);

 fclose(stdin);fclose(stdout);
 return 0;
}
