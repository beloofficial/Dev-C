#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <string>
#include <cstring>
#include <set>
#include <map>
#include <stdio.h>

#define pb push_back
#define mp make_pair
#define se second
#define fi first
#define all(a) a.begin(),a.end()
#define name "D"

using namespace std;

set<long long> t[500010];
vector<long long> b[500010];
long long a[100010];
long long n,m;
long long x,y;

vector<long long> finds(int k,int l,int r,int dl,int dr) {
	if(dl == l && dr == r)
		return b[k];
	else {
		long long m = (dl + dr) / 2;

		if(m >= r) 
			return finds(k*2,l,r,dl,m);

		if(m < l) 
			return finds(k*2+1,l,r,m+1,dr);

        vector<long long> ans = finds(k*2,l,m,dl,m),ans1;
        for(int j = 0; j < ans.size(); ++ j)
        	ans1.pb(ans[j]);

        ans = finds(k*2+1,m+1,r,m+1,dr);
        for(int j = 0; j < ans.size(); ++ j)
        	ans1.pb(ans[j]);

		return ans1;
	}
}

void build(long long k,long long l,long long r) {
	if(l == r) {
		b[k].pb(a[l]);
		t[k].insert(a[l]);
	}
	else {
		long long m = (l+r) / 2;
		build(k*2,l,m);
		build(k*2+1,m+1,r);

		for(int i = 0; i < b[k*2].size(); ++ i) {
			t[k].insert(b[k*2][i]);
			b[k].pb(b[k*2][i]);
		}

		for(int i = 0; i < b[k*2+1].size(); ++ i) {
			t[k].insert(b[k*2+1][i]);
			b[k].pb(b[k*2+1][i]);
		}
	}
}

int main() {

	freopen(name".in","r",stdin);
	freopen(name".out","w",stdout);	
    
    cin >> n >> m;
    for(int i = 0; i < n; ++ i)
    	cin >> a[i];

    build(1,0,n-1);

    for(int i = 0; i < m; ++ i) {	
    	cin >> x >> y;
        -- x;
        -- y;

        vector<long long> ans = finds(1,x,y,0,n-1);
        set<long long> ans1;
        for(int j = 0; j < ans.size(); ++ j)
        	ans1.insert(ans[j]);

        cout << ans1.size() << endl;
    }

	return 0;
}
