//Mukhamejanov Azamat 2011y                                                   
#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <ctime>
#include <map>
#include <set>
using namespace std;
#define fname1 "E."
#define fname2 ""
#define inf 1<<30
#define eps 1e-5
#define ll long long

ll a,b,c,l,r,p,f,s;
ll ans[100010];

ll get (ll x){
	return (((x-a)%p*(x-b)%p)%p*(x-c)%p)%p;
}
void add (ll *a,ll b){
	a[1]+=b;
	for (int i=1;i<=a[0];++i)
		while (a[i]>9){
			if (i==a[0])a[0]++;
			a[i+1]+=a[i]/10;
			a[i]%=10;
		}
}
int main (){
	freopen (fname1"in"fname2,"r",stdin);
	freopen (fname1"out"fname2,"w",stdout);

	scanf ("%lld %lld %lld %lld %lld %lld",&a,&b,&c,&l,&r,&p);

	if (r-l>10000000){printf ("0\n");return 0;}
	int fl=l,fr=r;
	ans[0]=1;
	while (1){
		int x=fl++;
		f=(((x-a)%p*(x-b)%p)%p*(x-c)%p)%p;
		s=(s+f)%p;
//		add (ans,f);
		if (fl>=fr)break;
		x=fr--;
		f=(((x-a)%p*(x-b)%p)%p*(x-c)%p)%p;
		s=(s+f)%p;
//		add (ans,f);
		if (fr<=fl)break;
	}

	printf ("%lld\n",s);
//	for (int i=ans[0];i>0;--i)printf ("%lld",ans[i]);

	return 0;
}
