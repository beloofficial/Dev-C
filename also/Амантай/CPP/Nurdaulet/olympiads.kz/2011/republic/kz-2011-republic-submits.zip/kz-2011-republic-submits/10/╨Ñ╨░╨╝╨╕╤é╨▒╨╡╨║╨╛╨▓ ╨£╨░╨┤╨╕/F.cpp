#include <iostream>
#include <ctime>
#include <queue>
#include <vector>
#include <cstdlib>
#include <cstdio>
#include <fstream>

using namespace std;


typedef long long ll;
typedef long double ld;
typedef vector<int> vi;

#define pb push_back
#define mp make_pair
#define sz size()
#define len length()
#define f first
#define s second

double Time () {
	return double(clock()) / double(CLOCKS_PER_SEC);
}

int n, m;
vector <int> a[100070], w[100070];
int u[100007], d[100007];
int f[100007], T[100008];

queue <int> q;

int bfs (int x, int y, int t) {
	for (int i = 0; i < n; i++) d[i] = 0, u[i] = -1;
	q.push ( x );                   
	u[x] = 0;
	while (!q.empty()) {
 		int x = q.front();
 		q.pop();
 		for (int i = 0; i < a[x].sz; i++)
 			if (u[a[x][i]] == -1)  {
 				d[a[x][i]] = d[x] + w[x][i], u[a[x][i]] = u[x] + 1;
 				if (a[x][i] == y) {
 					while (!q.empty())q.pop();
 		//			cout << u[y] << " " << d[y] << endl;
 					return ((t == 2) ? u[a[x][i]] - d[a[x][i]] : d[a[x][i]]);
 				}
 				q.push (a[x][i]);
 			}
        }
        return ((t == 1) ? u[y] - d[y] : d[y]);
}

int main () 
{
	ios_base::sync_with_stdio(0);

	freopen ("F.in", "r", stdin);
	freopen ("F.out", "w", stdout);
	
	cin >> n >> m;
	for (int i = 0; i < m; ++i) {
		cin >> f[i] >> T[i];
		f[i]--, T[i]--;
		int x = f[i], y = T[i];
		a[x].pb (y);
		a[y].pb (x);
		w[x].pb (1);
		w[y].pb (1);
	}
	int k;
	cin >> k;
	int x, y, t;
	for (int i = 0; i < k; ++i) {
		char c;
		cin >> c >> x >> y;
		if (c == 'q') cin >> t, cout << bfs(x-1,y-1,t) << "\n";
		else {
			y--;
			t = x;
			x = f[y];
			y = T[y];
			int j = lower_bound(a[x].begin(), a[x].end(), y) - a[x].begin();
			w[x][j] = (t == 2 ? 0 : 1);
			j = lower_bound(a[y].begin(), a[y].end(), x) - a[y].begin();
			w[y][j] = (t == 2 ? 0 : 1);
		}
	}


	return 0;
}