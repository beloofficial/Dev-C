//������� ������ 
//������
#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#include<cmath>
#include<vector>
#include<string>
#include<string.h>
#include<utility>
#include<algorithm>

using namespace std;

#define sz size()
#define mp make_pair
#define pb push_back
#define sqr(x) ((x)*(x))
//int log = 0;
/*
void dfs(int i, int parent = 0, int depth = 0)
{
	d[i] = depth;
	if (parent)
		p[i][0] = parent;	
	for (int j = head[i]; j != 0; j = next[j])
	{
		for (int q = 0; p[parent][q] > 0; q++)
			p[v[j]][q + 1] = p[parent][q];
		dfs(v[j], i, depth + 1);
	}
}

int get(int a, int b)
{
	if (d[b] > d[a])
		swap(a, b);
	while (d[a] > d[b])
	{
		for (int i = log - 1; i >= 0; i--)
			if (d[p[a][i]] >= d[b])
			{
				a = p[a][i];
				break;
			}
	}
	while (a != b)
	{
		for (int i = 0; i < log; i++)
			if (p[a][i] == p[b][i])
			{
				a = b = p[a][i];
				break;
			}
	}
	return a;
}

int go(int a, int b)
{
	if (a == b)	return;
	for (int j = head[a]; j != 0; j = next[j])
	{
		
	}
}

void print(int cur, int x, int y)
{
	printf("%d\n", go(cur, x) + go(cur, y));
}
*/
int main()
{
	freopen("F.in", "rt", stdin);
	freopen("F.out", "wt", stdout);
//		scanf("%d%d", &n, &m);
/*		d[0] = 1 << 30;
		while ((1 << log) < n) log++;

		for (int i = 1; i <= m; i++)
		{
			scanf("%d%d", &x, &y);
			next[i] = head[x];
			head[x] = i;
			v[i] = y;
			next[i + m] = head[y];
			head[y] = i + m;
			v[i + m] = x;
			w[j] = w[j + m] = 1;
		}
		dfs(1);
		scanf("%d\n", &k);
		for (;k--;)
		{
			scanf("%c", &c);
			if (c == 'q')
			{
				scanf("%d%d%d", &x, &y, &who);
				cur = get(x, y);
				print(cur, x, y);
			} else
			if (c == '+')
			{
				scanf("%d%d", &x, &y);
				w[y] = w[y + m] = x;
			}
			scanf("\n");
		}
        */
        printf("2\n1");
	return 0;
}
