#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <string>
#include <cstring>
#include <set>
#include <map>
#include <stdio.h>

#define pb push_back
#define mp make_pair
#define se second
#define fi first
#define all(a) a.begin(),a.end()
#define name "B"

using namespace std;

int dx[] = {1,1,-1,-1,2,2,-2,-2};
int dy[] = {2,-2,2,-2,1,-1,1,-1};
int ans,ans1[20][20];
int b[20][20],a[20][20];
int n,sum;
vector<pair<int,int> > kord;

bool check(int x,int y) {
	if(x < 0 || x >= n || y < 0 || y >= n)
		return 0;
	if(b[x][y] == 1)
		return 0;

	for(int i = 0; i < kord.size(); ++ i)
		if(kord[i].fi == x || kord[i].se == y) {
			return 0;
		}
		else
		if(abs(kord[i].fi-x)==abs(kord[i].se-y))
			return 0;

	return 1;
}

void check_ans() {
	sum = 0;
	for(int i = 0; i < n; ++ i)
		for(int j = 0; j < n; ++ j)
			if(b[i][j] == 1)
				sum += a[i][j];
	if(sum > ans) {
		ans = sum;
		for(int i = 0; i < n; ++ i)	
			for(int j = 0; j < n; ++ j)
				ans1[i][j] = b[i][j];
	}
}

void wr() {
	for(int i = 0; i < kord.size(); ++ i)
		cout << kord[i].fi << ' ' << kord[i].se << "   ";
	cout << "\n";
}

void f1(int kol,int i,int j) {
/*
	cout << "\n" << i << ' ' << j << endl;
   	for(int z = 0; z < 8; ++ z) 
   		if(check(dx[z]+i,dy[z]+j)) {
	 		cout << dx[z]+i << ' ' << dy[z]+j << "  ok \n";
		} else  {
	 		cout << dx[z]+i << ' ' << dy[z]+j << "\n";
	 		wr();
	 	}
*/

	if(kol >= n) {
//		wr();
		check_ans();
		return;
	}
    else {
    	for(int ii = -5; ii < 6; ++ ii)
    		for(int jj = -5; jj < 6; ++ jj)
    		if(check(ii+i,jj+j)) {
    			int z=0;
    			dx[z] = ii;
                dy[z] = jj;
    			b[dx[z]+i][dy[z]+j] = 1;
    			kord.pb(mp(dx[z]+i,dy[z]+j));
    			f1(kol+1,dx[z]+i,dy[z]+j);
    			kord.erase(kord.begin() + kord.size() - 1);
    			b[dx[z]+i][dy[z]+j] = 0;
    		}
    }
}

void f(int kol,int i,int j) {
/*
	cout << "\n" << i << ' ' << j << endl;
   	for(int z = 0; z < 8; ++ z) 
   		if(check(dx[z]+i,dy[z]+j)) {
	 		cout << dx[z]+i << ' ' << dy[z]+j << "  ok \n";
		} else  {
	 		cout << dx[z]+i << ' ' << dy[z]+j << "\n";
	 		wr();
	 	}
*/

	if(kol >= n) {
//		wr();
		check_ans();
		return;
	}
    else {
    	for(int z = 0; z < 8; ++ z) {
    		if(check(dx[z]+i,dy[z]+j)) {
    			b[dx[z]+i][dy[z]+j] = 1;
    			kord.pb(mp(dx[z]+i,dy[z]+j));
    			f(kol+1,dx[z]+i,dy[z]+j);
    			kord.erase(kord.begin() + kord.size() - 1);
    			b[dx[z]+i][dy[z]+j] = 0;
    		}
    	}
    }
}

void fresh() {
	for(int i = 0; i < n; ++ i)
		for(int j = 0; j < n; ++ j)
			b[i][j] = 0;
}

int main() {

	freopen(name".in","r",stdin);
	freopen(name".out","w",stdout);	
    
    cin >> n;

    for(int i = 0; i < n; ++ i)
    	for(int j = 0; j < n; ++ j)
    		cin >> a[i][j];

    for(int j = 0; j < n; ++ j) {
        	fresh();
        	b[0][j] = 1;
        	kord.pb(mp(0,j));
        	if(n < 6)
	        	f(1,0,j);
	        else
	        	f1(1,0,j);
    		kord.clear();
        	b[0][j] = 0;
        }

//    cout << ans << endl;

    for(int i = 0; i < n; ++ i) {
    	for(int j = 0; j < n; ++ j)
    		cout << ans1[i][j] << ' ';
    	cout << "\n";
	}    

	return 0;
}


	