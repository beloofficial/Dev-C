#include <iostream>
#include <string>
#include <cmath>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
using namespace std;

int  sum=0,s,n,m,a[100100],b[100100],mn[100100],d[100100];    bool used[100100];

void  bfs(int x, int y)
{
	int  q[100100],h,t,cur;
         q[1]=x;
		h=1; t=1; cur=0;
	while (h<=t)
	{
		int p=t;	
     		for (int j=h; j<=p; j++)
     		               {
     		                     cout<<q[j]; d[q[j]] = cur;  int e=q[j];
							if (q[j]==y) {  sum=cur; return; }

				     for (int k=1; k<=m; k++)
	                                if (a[k]==e) 
	                                     {
	                                         if (!used[k])  {  t++; q[e]=b[k]; }

	                                     }
	                                else if (b[k]==e){
	                                         if (!used[k])  {  t++; q[e]=a[k];  }


	                                     }
					h++;	
     		               }
	       cur ++; 
	}
} 
void path (int x, int y, int l)
{
	int  k = sum-1,j=x;   s=0;
    while (j!=y)
    {
	for (int i=1; i<=m; i++)
	{
		if (a[i]==j) {
		             if (d[b[i]]==k) { k--; j=b[i]; if (l==mn[i]) s++; break; }
		}
		else {
		             if (d[a[i]]==k) { k--; j=a[i]; if (l==mn[i]) s++; break; }
		}	
	}
    }	
}

int main()
{
	freopen ("F.in","r",stdin);
	freopen ("F.out","w",stdout);
	int   k,x,y,l;   char  ch;


	cin>>n>>m;
	for (int i=1; i<=m; i++) 
	{
		cin>>a[i]>>b[i];  //f[a[i]][b[i]]=true; f[b[i]][a[i]]=true; 			
	}
	cin>>k;
	for (int i=1; i<=k; i++)
	{
		cin>>ch;	
		       if (ch=='q') {
		                          cin>>x>>y>>l;
						for (int j=0; j<100000; j++)  {  d[j]=0; used[j]=false; }
						
		                          bfs (x,y); cout<<d[3]; return 0;  path(x,y,l);  cout<<s<<endl;

		                    }
		       else  {
		                          cin>>x>>y;
				          mn [y] = x; 


				}	

	}	

	return 0;
}