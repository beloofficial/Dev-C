#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <string>
#include <vector>
#include <cstdio>
#include <set>
#include <map>


using namespace std;

int ind1[100][100],
ind2[100][100],
k1[1000],
k2[1000],
max1,
max2,
b1[1000],
b2[1000],
l1,
l2,
len;

int n,m;
int main(){
        freopen("C.in","r",stdin);
	freopen("C.out","w",stdout);

	    scanf("%d%d",&n,&m); 
    
           for (int i=1; i<=n; i++){
		scanf("%d",&k1[i]);

		if ( k1[max1] < k1[i] ) max1 = i;

		  for (int j = 1; j<=k1[i]; j++)     {
			scanf("%d",&ind1[k1[i]][j]);	
		cout<<ind1[k1[i]][j]<<endl;
	      }
			                      }
	

	   for (int i=1; i<=m; i++) {	
		scanf("%d",&k2[i]);
		if ( k2[max2] < k2[i] ) max2 = i;
                for (int j = 1; j<=k2[i]; j++)
		    scanf("%d",&ind2[k2[i]][j]);
	}

	for (int i=0; i<=n; i++){
                for ( int j=1; j <=k1[i]; j++ )
			cout<<ind1[k1[i]][j];
 	cout<<endl;
}
		
	for (int i=1; i<=n; i++) 
     	ind2[i][k1[max1]] = 0;
    
        for (int i=1; i<=m; i++) 
	ind1[i][k2[max2]] = 0;

	
	for (int i=1; i<=n; i++) {
	bool f = false;
		for (int j=1; j<=m; j++)
		if ( ind1[j][k1[i]] == 1 ) { f = true; break; }
	if ( !f ) b1[l1++] = i;
}   


	for (int i=1; i<=m; i++) {
	bool f = false;
		for (int j=1; j<=n; j++)
		if ( ind2[j][k2[i]] == 1 ) { f = true; break; }
	if ( !f ) b2[l2++] = i;

} 
	len = l2 + l1;
		
	printf("%d %d %d\n",len,l1, l2);  

	for (int i=0; i<l1; i++)
		printf("%d ",b1[i]);
	
	  printf("\n");

	for (int i=0; i<l2; i++)
		printf("%d ",b2[i]);


		

	fclose(stdout);
return 0;
}