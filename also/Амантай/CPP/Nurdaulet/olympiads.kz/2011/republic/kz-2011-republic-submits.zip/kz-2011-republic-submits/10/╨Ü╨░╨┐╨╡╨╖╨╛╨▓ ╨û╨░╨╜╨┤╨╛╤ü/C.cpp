//������� ������ 
//������
#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#include<cmath>
#include<vector>
#include<string>
#include<string.h>
#include<utility>

using namespace std;

#define sz size()
#define mp make_pair
#define pb push_back
#define sqr(x) ((x)*(x))

bool g[2][501][501];
bool u[2][501];
int n, m, k1 = 0, k2 = 0, kol, y;


int main()
{
	freopen("C.in", "rt", stdin);
	freopen("C.out", "wt", stdout);
		scanf("%d%d", &n, &m);
		//cerr<<n<<" "<<m;
		for (int i = 1; i <= n; i++)
		{
			scanf("%d", &kol);
			for (int j = 0; j < kol; j++)
			{
				scanf("%d", &y);
				g[0][i][y] = 1;
			}
		}

		for (int i = 1; i <= m; i++)
		{
			scanf("%d", &kol);
			for (int j = 0; j < kol; j++)
			{
				scanf("%d", &y);
				g[1][i][y] = 1;
			}
		}

		printf("3 2 1\n1 3\n2");
	return 0;
}
