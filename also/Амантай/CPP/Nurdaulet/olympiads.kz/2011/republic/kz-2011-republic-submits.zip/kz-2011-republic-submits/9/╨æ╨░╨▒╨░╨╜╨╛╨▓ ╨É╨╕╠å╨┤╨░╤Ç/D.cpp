#include<fstream>
using namespace std;
int main(){
      ifstream in("D.in");
	ofstream out("D.out");
int n,m;
in>>n>>m;
int a[100010];
for(int i=1;i<=n;i++){
in>>a[i];
for(int j=1;j<i;j++){
if(a[i]==a[j])a[i]=0;
}
}
int k,l;
int coun=0;

for(int i=0;i<m;i++){
        in>>k>>l;
coun=0;
for(int j=k;j<=l;j++){
if(a[j]!=0)coun++;
}
out<<coun<<endl;
}

return 0;
}