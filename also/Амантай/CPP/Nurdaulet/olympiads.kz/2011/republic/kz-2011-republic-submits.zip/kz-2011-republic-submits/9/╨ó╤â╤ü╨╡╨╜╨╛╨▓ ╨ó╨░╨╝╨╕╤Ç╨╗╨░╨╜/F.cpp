#include<iostream>
#include<cstdio>
#include<string>
using namespace std;

int x,y,k,n,m,e;
char s[9];          
int f,t,w;

            
int main()
{

freopen("F.in","r",stdin);
freopen("F.out","w",stdout);

scanf("%d%d",&n,&m);
for(int i=0;i<m;i++){
scanf("%d%d",&f,&t);}

scanf("%d",&e);

for(int i=0;i<e;i++){
scanf("%s",&s);
if(s[0]=='q'){
scanf("%d%d%d",&x,&y,&k);}}
printf("2\n1");

return 0;
}

