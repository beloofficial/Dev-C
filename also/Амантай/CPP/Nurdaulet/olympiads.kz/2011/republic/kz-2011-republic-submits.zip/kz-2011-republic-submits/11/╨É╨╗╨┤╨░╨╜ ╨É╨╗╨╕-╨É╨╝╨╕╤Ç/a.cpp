#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <ctime>

using namespace std;

#define N 30
#define M 30

int n, m, k;
int wei[N], pow[M], mask[M];
int ves[(1<<25)+5];

long long res, cur;
int w, wans;
int iter;

void dfs (int u)
{
	if (ves[w] > k) return;
	if (u == n)
	{
		if (cur > res)
		{
		 	res = cur;
		 	wans = w;
		}
	}
	else
	{
		cur += pow[u];
		int prev = w;
		w |= mask[u];
		dfs (u+1);
		w = prev;
		cur -= pow[u];	

		dfs (u+1);
	}
}

//Precalc
int curwei, curmask;
void precalc (int u)
{
	if (u == n) ves[curmask] = curwei;
	else
	{
	 	precalc (u+1);
	 	if (curwei+wei[u]>k)
	 	{
	 		int prev = curwei;
	 		curwei = k+1; curmask ^= 1<<u;
	 		precalc (u+1);
	 		curwei = prev; curmask ^= 1<<u;
      }
      else
      {
      	curwei += wei[u]; curmask ^= 1<<u;
      	precalc (u+1);
      	curwei -= wei[u]; curmask ^= 1<<u;
      }
	}
}

int main ()
{
	freopen ("A.in", "r", stdin);
	freopen ("A.out", "w", stdout);

	scanf ("%d%d%d", &n, &m, &k);

	for (int i = 0; i < n; i++)
		scanf ("%d", &wei[i]);

	for (int i = 0; i < m; i++)
		scanf ("%d", &pow[i]);

	for (int i = 0; i < m; i++)
	{
	 	for (int a, b;;)
	 	{
	 		scanf ("%d", &a); a--;
	 		b = getchar ();
	 		mask[i] |= (1<<a);

	 		if (b == '\n' || b == EOF) break;
	 	}
	}

	precalc (0);
	dfs (0);

	for (int i = 0; i < n; i++)
		if ((wans>>i)&1)
			printf ("%d ", i+1);
	puts ("");

	return 0;
}
