#include<iostream>
#include<fstream>
#include<map>
#include<cstdlib>
#include<string>
#include<vector>
#include<deque>
#include<set>
#include<cstdio>
#include<cmath>
#include<algorithm>

#define INF (1 << 30)
#define pb push_back
#define mp make_pair
#define VI vector <int>
#define VVI vector < VI >
#define PI pair <int, int>
#define fi first
#define se second

using namespace std;

VVI g;
int n, m, a, b, k, c, rrr;
bool u[100010], qq;
VI vv;
map < PI, int > mm;

PI aa[100010];

void out(){
	for(int i = 0; i < vv.size(); ++i)
			cout << vv[i] << " ";
	cout << endl;	
}

void dfs(int v, int des, int c, int fr){
	if(qq) return;
	u[v] = 1;
	if(v == des){
		rrr = 0;
		if(mm[mp(min(fr, vv[0]), max(fr, vv[0]))] == c) ++rrr;
		for(int i = 0; i < vv.size() - 1; ++i)
			if(mm[mp(min(vv[i], vv[i + 1]), max(vv[i], vv[i + 1]))] == c) ++rrr;

		printf("%d\n", rrr);
		qq = 1;
		return;
	}
	for(int i = 0; i < g[v].size(); ++i)
		if(!u[g[v][i]]){
			vv.pb(g[v][i]);
			dfs(g[v][i], des, c, fr);
			vv.pop_back();
		}
}

int main(){

	freopen("f.in", "r", stdin);
	freopen("f.out", "w", stdout);

	scanf("%d %d", &n, &m);

	g.resize(n);

	for(int i = 0; i < m; ++i){
		scanf("%d %d", &a, &b);
		--a, --b;
		g[a].pb(b);
		g[b].pb(a);
		mm[mp(min(a, b), max(a, b))] = 1;
		aa[i].fi = a, aa[i].se = b;
	}               

	scanf("%d", &k);
	char cc;

	for(int i = 0; i < k; ++i){

		cin >> cc;

		if(cc == 'q'){
			scanf("%d %d %d", &a, &b, &c);
			--a, --b;
			for(int j = 0; j < n; ++j) u[j] = 0;
			vv.clear();
			qq = 0;
			dfs(a, b, c, a);	
		}

		else{
			scanf("%d %d", &a, &b);
			--b;
			mm[mp(min(aa[b].fi, aa[b].se), max(aa[b].fi, aa[b].se))] = a;
		}
	}

	return 0;
}