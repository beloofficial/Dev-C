#include<fstream>
using namespace std;
int a[1010][1010];
int b[1010][1010];
int main(){
ifstream in("H.in");
ofstream out("H.out");
         int n,m;
in>>n>>m;

for(int i=1;i<=n;i++){
for(int j=1;j<=n;j++){
in>>a[i][j];
}
}

for(int i=0;i<=n;i++){
for(int j=0;j<=m;j++){
b[i][j]=9999999;
}
}
b[1][1]=0;
for(int i=1;i<=n;i++){
for(int j=1;j<=m;j++){
if(b[i][j]+a[i][j+1]<b[i][j+1])b[i][j+1]=b[i][j]+a[i][j+1];
if(b[i][j]+a[i][j-1]<b[i][j-1])b[i][j-1]=b[i][j]+a[i][j-1];
if(b[i][j]+a[i+1][j]<b[i+1][j])b[i+1][j]=b[i][j]+a[i+1][j];
}
for(int j=1;j<=m;j++){
if(b[i][j]+a[i][j+1]<b[i][j+1])b[i][j+1]=b[i][j]+a[i][j+1];
if(b[i][j]+a[i][j-1]<b[i][j-1])b[i][j-1]=b[i][j]+a[i][j-1];
if(b[i][j]+a[i+1][j]<b[i+1][j])b[i+1][j]=b[i][j]+a[i+1][j];
b[0][j]=9999999;
b[n+1][j]=9999999;

}
b[i][0]=9999999;
b[i][n+1]=9999999;
}
int x=n,y=m;
int nastr;
in>>nastr;
      out<<nastr-b[n][m]; 
return 0;}