//Solution by Balakshy Andrey 17.04.11

#include <cstdio>
#include <iostream>
#include <cstdlib>
#include <vector>
#include <cmath>
#include <algorithm>
#include "dist.h"

using namespace std;

#define pb push_back
#define mp make_pair
#define For(i, p1, p2, st) for (int i = (int)p1; i < (int)p2; i += (int)st)
#define FoR(i, p1, p2, st) for (int j = (int)p1; i > (int)p2; i -= (int)st)  

int x = 0, y = 0, nx, ny;
long long z;
double r1, r2, r; // nx - po x, ny - po y 1 - pravo(vverx) 0 - levo(cniz)

int main()
{
   start();     
    r1 = dist(0, 0);  r = r1;
     if (!r1) finish(0, 0);
      r2 = dist(1, 0); 
       if (!r2) finish(1, 0);
        if (r2 < r1) nx = 1; else nx = 0;
      
   
      r2 = dist(0, 1); 
       if (!r2) finish(0, 1);
        if (r2 < r1) ny = 1; else ny = 0;
                
         z = int(r * r);

       for (int i = 0; i * i * 1ll <= z; i++){  
        x = i; y = int(sqrt((z - x * x) * 1.0));
          r = dist(x, y);
           if (!r){
            if (!ny) y *= -1;
             if (!nx) x *= -1;
              finish(x, y);
           }   
       }

  return 0;
}
