#include <iostream>
#include <cmath>
#include <cstdio>

using namespace std;

int mas[16][16];

struct st{
	int i, j, s;
} v[100];

int n;

int os = -1;
int o[16][16];

int sum(){
	int s;
	for(int i = 0; i<n; i++){
		 s += v[i].s;
	}
}

void rec(int g){
	if (g == n){
		int temp = sum();
		if (temp > os){
		 	for(int i = 0; i<n; i++){
		 	 	for(int j = 0; j<n; j++){
		 	 	 	if (j == v[i].j){
		 	 	 	 	o[i][j] = 1;
		 	 	 	} else {
		 	 	 	 	o[i][j] = 0;
		 	 	 	}
		 	 	}
		 	}
		}
	}

	bool t = true;

	for(int j = 0; j<n; j++){
		t = true;

		for(int i = 0; i<g; i++){
		 	if ( (abs(g-v[i].i)==abs(j-v[i].j)) or (g==v[i].i) or (j == v[i].j) ){
				t = false;
		 	} 
		
		}

		if (t){
			v[g].i = g;
			v[g].j = j;
			v[g].s = mas[g][j];
			rec(g+1);
		}

	}
}

main(){
	freopen("b.in", "r", stdin);
	freopen("b.out", "w", stdout);

	cin >> n;
	for (int i = 0; i<n; i++){
	 	for(int j = 0; j<n; j++){
	 	 	cin >> mas[i][j];
	 	}
	}

	rec(0);

	for (int i = 0; i<n; i++){
	 	for(int j = 0; j<n; j++){
	 	 	cout << o[i][j] << " ";
	 	}
	 	cout << endl;
	}
 
	fclose(stdout);
}