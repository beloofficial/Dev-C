#include<iostream>
#include<fstream>
#include<algorithm>
#include<cstdio>
#include<cstdlib>
#include<utility>
#include<queue>
#include<ctime>
#include<cctype>
#include<cstring>
#include<list>
#include<set>
#include<map>

using namespace std;
long long Try;
int n,m,k;
int a[30],c[30],magic[30],tmp,ans;
string s;
char ch;
int main(){
	freopen("A.in","r",stdin);
	freopen("A.out","w",stdout);
	scanf("%d%d%d\n",&n,&m,&k);
	for(int i=0;i<n;i++){
		scanf("%d",&a[i]);
		Try+=a[i];
	}
	//-----------
	if(Try<=k){	for(int i=0;i<n;i++)	printf("%d ",i+1);	return 0; }
	//-----------
	
	for(int i=1;i<=m;i++) scanf("%d",&c[i]); scanf("\n");

	for(int i=1;i<=m;i++){
		tmp=0;
		while(scanf("%c",&ch)!=EOF){//	printf("%c",ch);
			if(ch!=' ' && !isdigit(ch)) break;
			if(isdigit(ch))	tmp=tmp*10+(ch-'0');
			else
			{	                         
				magic[i]+=(1<<(tmp-1)); //		printf("%d ",tmp);
				tmp=0;   
			}
			                              

	 	}
//		printf("%d\n",tmp);
		magic[i]+=(1<<(tmp-1));
	}
	int N=0;
	for(int i=1;i<=m;i++) N=(N|magic[i]);

//	printf("%d",N);                        
                                               

	int check; long long ok,mx; mx=0;
	for(int mask=N;mask>0;mask=(mask-1)&mask){

		
//		for(int i=0;i<n;i++) 
//			if(mask&(1<<i)) printf("%d ",i+1); printf("\n");

		check=k; ok=0;

		for(int i=0;i<n;i++) 
			if(mask&(1<<i)) if(check-a[i]<0) {ok=1;break;} else check-=a[i];
			
		if(ok) continue;   

		for(int i=1;i<=m;i++) 	if((mask&magic[i])==magic[i])	ok+=c[i]; //	printf("mask : %d ok : %d\n",mask,ok);
		if(ok>mx) {mx=ok;ans=mask;}

	}
	for(int i=0;i<n;i++) 
		if(ans&(1<<i)) printf("%d ",i+1);

return 0;
}