// O, velikiy System Judge!
// Posshadi menya! Plzplzplzplzplz
#include <cstdio>
#include <cmath>

int list[1001000], N, h[101000], first[101000];
int n, m, d[1001000][60], lg2[1001000];
int no[100100], ne[100100], he[100100], nc = 1;
int add[100100], sum[100100], e1[100100], e2[100100], clr[100100];

int minh(int x, int y)
{
	if (h[x] < h[y])
		return x;
	return y;
}
                      
void init ()
{
	for (int i = 0; i < N; i++)
		d[i][0] = list[i];
	for (int j = 1; (1 << j) <= N; j++)
		for(int i = 0; (i + (1 << j)) <= N; i++)
			d[i][j] = minh(d[i][j - 1], d[i + (1 << (j - 1))][j - 1]); 
}

int get (int l, int r)
{
	int k = lg2[r - l + 1];
	return minh(d[l][k], d[r - (1 << k) + 1][k]);
}

void dfs (int v)
{
	list[N++] = v;
	for (int i = he[v]; i; i = ne[i])
	{                        
		int u = no[i];
		h[u] = h[v] + 1;
		dfs(u);
		list[N++] = v;
	}
}

void spread (int v)
{
	sum[v] += add[v];
	int spr = add[v];
	add[v] = 0;
//	printf("for %d sum is %d\n", v, sum[v]);                
	for (int i = he[v]; i; i = ne[i])
	{
		int u = no[i]; 
		add[u] += spr; 
		spread(u);       
	}
}                                
main ()
{
	freopen ("f.in", "r", stdin);
	freopen ("f.out", "w", stdout);
	scanf("%d %d\n", &n, &m);
	for (int i = 0; i < m; i++){
		scanf("%d %d\n", e1 + i, e2 + i);e1[i]--;e2[i]--;
		no[nc] = e2[i]; ne[nc] = he[e1[i]]; he[e1[i]] = nc; nc++;
	}
//	puts("input finished");
	dfs(0);//puts("dfs finished");
	init();//puts("sparse table finished");
	for (int i = 1; i <= N; i++)
		lg2[i] = log2(i);
	for (int i = N - 1; i >= 0; i--)
		first[list[i]] = i;	
//	puts("preproccessing finished");                                 
	int k, x, y, who, X, Y; char cmd; 
	scanf("%d\n", &k);
	for (; k--; )
	{
		scanf("%c ", &cmd);	
		if (cmd == '+')
		{
			scanf("%d %d\n", &who, &x); who--;x--;
			if (clr[x] != who)
			{
				clr[x] = who;
				if (who)
					add[e2[x]]++;
				else add[e2[x]]--;
			}
	   	}
		else
		{
			//puts("spread");
			spread(0); // puts("finished");                           
			scanf("%d %d %d\n", &x, &y, &who);who--;x--;y--;
			X = first[x]; Y = first[y];
			if (X > Y){int t = X;X = Y; Y = t;}

			int lca = get(X, Y), ans = sum[x] + sum[y] - 2 * sum[lca];
//			printf("sum = %d ", ans);
			if (!who) ans = - ans + h[x] + h[y] - 2 * h[lca];
//			printf("lca = %d ", lca);                      
			printf("%d\n", ans);
		}
		
//		puts("");	for (int i = 0; i < n; i++)printf("%d ", sum[i]);puts("");
//		for (int i = 0; i < n; i++)printf("%d ", add[i]);puts("");

	}
}                                         