//Solution by Balakshy Andrey 17.04.11

#include <cstdio>
#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>

using namespace std;

#define pb push_back
#define mp make_pair
#define For(i, p1, p2, st) for (int i = (int)p1; i < (int)p2; i += (int)st)
#define FoR(i, p1, p2, st) for (int j = (int)p1; i > (int)p2; i -= (int)st)  

typedef unsigned long long ULL;

vector <vector <ULL> > pole, nast;
vector <ULL> b;
int n, m, kol = 0;
ULL ch, nastr;

void print()
{
 cout << nastr - nast[n - 1][m - 1];
 /*For(i, 0, n, 1){

   For(j, 0, m, 1) printf("%d ", nast[i][j]);
 cout << endl;
 }    */
}

int main()
{
  freopen("H.in", "r", stdin);
   freopen("H.out", "w", stdout); 

    scanf("%d%d", &n, &m);
     For(i, 0, n, 1){
      For(j, 0, m, 1) scanf("%d", &ch), b.pb(ch);
       pole.pb(b), b.clear(); 
     }
    scanf("%d", &nastr);

    b.clear(); For(i, 0, m, 1) b.pb(0);
     For(i, 0, n, 1) nast.pb(b);
      b.clear();

      nast[0][0] = 0;
    For(i, 0, n, 1){
     For(j, 0, m, 1){
      if (!i && !j) continue;
       if (!i){
        nast[i][j] = nast[i][j - 1] + pole[i][j];
       } else
          if (!j){
           nast[i][j] = nast[i - 1][j] + pole[i][j];
          }
          else 
           nast[i][j] = pole[i][j] + min(nast[i][j - 1], nast[i - 1][j]);

          }
     }	

   print();

  return 0;
}
