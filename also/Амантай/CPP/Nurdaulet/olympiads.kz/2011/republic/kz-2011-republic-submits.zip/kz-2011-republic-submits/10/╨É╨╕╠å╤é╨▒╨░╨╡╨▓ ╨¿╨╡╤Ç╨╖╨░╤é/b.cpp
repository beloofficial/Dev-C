#include<iostream>
#include<fstream>
#include<map>
#include<cstdlib>
#include<string>
#include<vector>
#include<deque>
#include<set>
#include<cstdio>
#include<cmath>
#include<algorithm>

#define INF (1 << 30)
#define pb push_back
#define mp make_pair
#define VI vector <int>
#define VVI vector < VI >
#define fi first
#define se second

using namespace std;

int n, b[20][20], a[100][100], v[100], g[100], d1[1000], d2[1000], ew = 0, mx = -1, r[20][20], we;

void rec(int x, int y, int f){
	if(f == n){
		we = 0;
		for(int i = 0; i < n; ++i)
			for(int j = 0; j < n; ++j)
				if(a[i][j])
					we += b[i][j];
                if(we == 1000 * n){
			for(int i = 0; i < n; ++i){
				for(int j = 0; j < n; ++j)
					cout << a[i][j] << " ";;
				cout << endl;
			}                
			exit(0);
                }
                if(we > mx){
	                cerr << we << endl;
                	mx = we;
                	for(int i = 0; i < n; ++i)
				for(int j = 0; j < n; ++j)
					r[i][j] = a[i][j];
                }
		return;
	}
	if(v[y] || g[x] || d1[x + y] || d2[x - y + 100]) return;
	v[y] = g[x] = d1[x + y] = d2[x - y + 100] = 1;
	for(int i = x + 1; i < n; ++i)
		for(int j = 0; j < n; ++j){
			if(v[j] || g[i] || d1[i + j] || d2[i - j + 100]) continue;
			a[i][j] = 1, rec(i, j, f + 1);
			a[i][j] = 0;
		}
	v[y] = g[x] = d1[x + y] = d2[x - y + 100] = 0; 
}

int main(){

	freopen("b.in", "r", stdin);
	freopen("b.out", "w", stdout);		

	cin >> n;

	for(int i = 0; i < n; ++i)
		for(int j = 0; j < n; ++j)
			scanf("%d", &b[i][j]);

	rec(0, 0, 0);

	for(int i = 0; i < n; ++i)
		for(int j = 0; j < n; ++j)
			a[i][j] = 1, rec(i, j, 1), a[i][j] = 0;

	for(int i = 0; i < n; ++i){
		for(int j = 0; j < n; ++j)
			printf("%d ", r[i][j]);
		puts("");
	}

	return 0;
}