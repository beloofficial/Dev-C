#include <iostream>
#include <cstdio>

#define name		"B"

using namespace std;

typedef long long LL;
typedef pair <int, int> Pair;

int n;
int a[50][50], f[50][50];

bool check1(int x, int y) {
	int dx = x-1, dy = y;
	
	for(; f[dx][dy] == 0; dx--);
	return (f[dx][dy] == -1);
}

bool check2(int x, int y) {
	int dx = x+1, dy = y;
	
	for(; f[dx][dy] == 0; dx++);
	return (f[dx][dy] == -1);
	
}

bool check3(int x, int y) {
	int dx = x, dy = y-1;
	
	for(; f[dx][dy] == 0; dy--);
	return (f[dx][dy] == -1);
	
}

bool check4(int x, int y) {
	int dx = x, dy = y+1;
	
	for(; f[dx][dy] == 0; dy++);
	return (f[dx][dy] == -1);
}

bool check5(int x, int y) {
	int dx = x+1, dy = y+1;
	
	for(; f[dx][dy] == 0; dx++, dy++);
	return (f[dx][dy] == -1);
}

bool check6(int x, int y) {
	int dx = x-1, dy = y-1;
	
	for(; f[dx][dy] == 0; dx--, dy--);
	return (f[dx][dy] == -1);
}

bool check7(int x, int y) {
	int dx = x+1, dy = y-1;
	
	for(; f[dx][dy] == 0; dx++, dy--);
	return (f[dx][dy] == -1);
}

bool check8(int x, int y) {
	int dx = x-1, dy = y+1;
	
	for(; f[dx][dy] == 0; dx--, dy++);
	return (f[dx][dy] == -1);
}


bool Ok(int x, int y) {
	return (check1(x, y) && check2(x, y) && check3(x, y) && check4(x, y) && 
	    check5(x, y) && check6(x, y) && check7(x, y) && check8(x, y));
}

void print() {
	for(int i = 1; i <= n; ++ i) {
		for(int j = 1; j <= n; ++ j) {
			cout << f[i][j] << ' ';
		}
		cout << endl;
	}
}

void Clear() {
	for(int i = 1; i <= n; ++ i) {
		for(int j = 1; j <= n; ++ j) {
			f[i][j] = 0;
		}
	}
	
}

int main() {
	freopen(name".in", "r", stdin);
	freopen(name".out", "w", stdout);
	
	cin >> n;
	for (int i = 0; i <= n+1; ++i) {
		f[i][0] = f[0][i] = f[n+1][i] = f[i][n+1] = -1;
	}

	int ind_i, ind_j, Max = -100;
	for(int i = 1; i <= n; ++ i) {
		for(int j = 1; j <= n; ++ j) {
			cin >> a[i][j];
			if (Max < a[i][j]) {
				Max = a[i][j];
				ind_i = i;
				ind_j = j;
			}	
		}
	}
	
	int kol = 0;
	f[ind_i][ind_j] = 1;

	

/*	while (kol != n) {
//		Clear();
		for(int i = 0; i <= n; ++ i) {
			for(int j = 0; j <= n; ++ j) {
				if (Ok(i, j)) {
//					cout << "\n";
//					print();
					f[i][j] = 1;
					sum += a[i][j]
					kol++;
					if (kol == n) {
						print();
						return 0;
					}
				}
			}
		}
		kol = 0;
	}
*/	
	
	while (kol != n) {
		for(int i = 0; i <= n; ++ i) {
			for(int j = 0; j <= n; ++ j) {
				if (Ok(i, j)) {
//					cout << "\n";
//					print();
					f[i][j] = 1;
//					sum += a[i][j];
					kol++;
					if (kol == n || kol == n-1) {
						print();
						return 0;
					}
				}
			}
		}
		kol = 0;
	}



	return 0;
}

