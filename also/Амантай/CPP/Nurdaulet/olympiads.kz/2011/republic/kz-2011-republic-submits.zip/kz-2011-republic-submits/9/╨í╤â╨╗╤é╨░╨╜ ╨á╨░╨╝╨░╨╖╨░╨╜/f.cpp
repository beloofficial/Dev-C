#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <string>
#include <vector>
#include <cstdio>
#include <set>
#include <map>


using namespace std;

int a[2][10000][10000],n,k,m,kol;  
int x[100000],y[100000];
char op;
bool was[100];

void dfs(int v,int yi,int q){
	was[v] = true;
	if ( v == yi ) return;
	

	for (int i=1; i<=yi; i++)
	if ( a[q][v][i] == 1 && !was[i] ) { dfs(i,yi,q); }

	kol++;
}
int main(){
        freopen("F.in","r",stdin);
	freopen("F.out","w",stdout);
	    scanf("%d%d",&n,&m);
	
	   for (int i=1; i<=m; i++) { 
		scanf("%d%d",&x[i],&y[i]);
		a[1][x[i]][y[i]] = 1;
		a[1][y[i]][x[i]] = 1;
}

	scanf("%d",&k);
	
	int kl =1;

	for (int i=1; i<=k+1; i++){
		scanf("%c",&op);
                if ( op == '+' ) {
		int j , h;
	
 			scanf("%d%d",&j,&h); 
	
			a[kl][x[h]][y[h]] = 0;
			a[kl][y[h]][x[h]] = 0;              
                        a[j][x[h]][y[h]] = 1;
			a[j][y[h]][x[h]] = 1;
		kl = j; 
		
		 
}
		if ( op == 'q' ) { 

	       for (int l =1; l<=n; l++)
		was[l] = false;

			int j, h, q;
			kol = 0;
			scanf("%d%d%d",&j,&h,&q);
			
			dfs(j,h,q);
		
		
		printf("%d\n",kol);

}
		scanf("\n");
	}

	
	fclose(stdout);
return 0;
}