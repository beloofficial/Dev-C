#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <string>
#include <vector>
#include <cstdio>
#include <set>
#include <map>


using namespace std;

long long a[1020][1020],b[1020][1020],n,m;

long long s;

int main(){
        freopen("H.in","r",stdin);
	freopen("H.out","w",stdout);
	 scanf("%d%d",&n,&m);
	
	 for (int i=1; i<=n; i++)
		for (int j=1; j<=m; j++)
		scanf("%d",&a[i][j]);  

	scanf("%i64",&s);
	//cout<<s;
	
	int i=2; 
	b[1][1] = 0;

	
	while ( i<=n ) { 
	b[1][i] += a[1][i] + b[1][i-1];
	b[i][1] += a[i][1] + b[i-1][1];
	i++;
}

	for (int i=2; i<=n; i++)
		for (int j=2; j<=m; j++)
		if ( b[i-1][j] < b[i][j-1] ) b[i][j] += (a[i][j] +  b[i-1][j]); else b[i][j] += (a[i][j] + b[i][j-1]);
	      
 cout<<s - b[n][m];                                                                                      
	fclose(stdout);
return 0;
}