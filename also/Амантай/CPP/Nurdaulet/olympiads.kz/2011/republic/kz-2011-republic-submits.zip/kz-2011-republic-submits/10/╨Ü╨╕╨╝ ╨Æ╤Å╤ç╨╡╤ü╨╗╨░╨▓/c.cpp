// O, velikiy System Judge!
// Posshadi menya! Plzplzplzplzplz
#include <cstdio>

const int N = 1200;
int a[N][N], t[N][N], n, m, NN, mx, ans, mxi, temp, u[N], k1, k2;

void inc (int i, int x, int j)
{
	for(; i < NN; i |= (i + 1))
		t[j][i] += x;
}

int sum (int j)
{
	int r = 0, i = NN - 1;
	for (; i >= 0; i &= (i + 1), i--)
		r += t[j][i];
	return r;
}
int main ()
{
	freopen("C.in", "r", stdin);
	freopen("C.out", "w", stdout);
	scanf("%d%d", &n, &m);
	ans = NN = n + m;
	for (int i = 0; i < n; i++)
	{
		int k, to;
		scanf("%d", &k);
		for (int j = 0; j < k; j++)
		{
			scanf("%d", &to);to--;
			if(a[i][to + n] == 0)inc(to + n, 1, i);
			a[i][to + n] = 1;
			if(a[to + n][i] == 0)inc(i, 1, to + n);
			a[to + n][i] = 1;         
			temp = sum(i);
			if (temp > mx){
				mx = temp; mxi = i;}
			temp = sum(to + n);
			if (temp > mx){
				mx = temp; mxi = to + n;}
		}
	}
//	for (int i = 0; i < n; i++)for(int j = n; j < NN; j++)printf("%d%c", a[i][j], j == NN - 1 ? '\n' : ' ');
	for (int i = 0; i < NN; i++)
		u[i] = 1;
	while(mx > 0){
//		printf("mxi = %d\n", mxi);
		ans--;
		u[mxi] = 0;
		mx = 0;
		for(int i = (mxi >= n ? 0 : n); i <= (mxi >= n ? n : NN) - 1; i++){if(a[i][mxi]){
			a[i][mxi] = a[mxi][i] = 0;
			inc(i, -1, mxi);
			inc(mxi, -1, i);                  
		}

			temp = sum(i);                 
			if (temp > mx){
				mx = temp; mxi = i;}
		}
			
	}
	for (int i = 0; i < NN; i++)
		if (i < n)k1 += u[i];
		else k2 += u[i];
	printf("%d %d %d\n", ans, k1, k2);
	for (int i = 0; i < n; i++)if(u[i])printf("%d ", i + 1);puts("");
	for (int i = n; i < NN; i++)if(u[i])printf("%d ", i - n + 1);puts("");
}