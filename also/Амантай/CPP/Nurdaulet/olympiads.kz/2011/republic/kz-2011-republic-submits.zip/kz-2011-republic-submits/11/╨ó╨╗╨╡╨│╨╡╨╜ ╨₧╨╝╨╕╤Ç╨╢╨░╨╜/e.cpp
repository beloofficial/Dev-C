#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cmath>
#include <string>
#include <cstring>
#include <map>
#include <set>
#include <deque>
#include <queue>
#include <vector>

using namespace std;

#define name 	"E"
#define INF 	int(1e9)
#define EPS		1e-9
#define SZ(x)	int(x.size())
#define ALL(x)	x.begin(), x.end()

typedef long long LL;

int a, b, c, l, r, p;

LL f(int x) {
	return ( ( (LL(x-a)*LL(x-b))%p ) * LL(x-c) )%p;
}

int main() {
	freopen(name".in","r",stdin);
	freopen(name".out","w",stdout);

	LL sum = 0;

	cin >> a >> b >> c >> l >> r >> p;


	for (int i = l; i <= r; ++ i) {
	 	sum += f(i);
	 	sum %= p;
	}

	cout << sum;

	return 0;
}
