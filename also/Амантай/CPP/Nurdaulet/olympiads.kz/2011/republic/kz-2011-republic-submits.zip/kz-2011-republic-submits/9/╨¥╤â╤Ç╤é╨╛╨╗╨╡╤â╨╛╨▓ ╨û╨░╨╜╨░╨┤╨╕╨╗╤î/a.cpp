#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>

using namespace std;

#define pb push_back()
#define fi first
#define se second

int main(){
	freopen ("A.in", "r", stdin);
	freopen ("A.out", "w", stdout);
	int n, m, k;
	int a[30];
	int w[30], c[30];
	int e[30][30];
	fill(a, a + 30, 0);
	cin >> n >> m >> k;
	for (int i = 0;i < n;i++)cout << i + 1 << " ";	
}
