#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
int n, ans, v[99], d1[99], d2[99], b[99], c[99], a[99][99], d[99][99];
void go(int x, int z) {
	int i, y, t;        
	if (x > n) {
	//	printf("ok");
		if (z > ans) {
			ans = z;
			for (i = 1; i <= n; i++) 
				c[i] = b[i];
		}
	}
	else {
		for (i = 1; i <= n; i++) {
			y = x + i;
			t = n - x + i;
			if (v[i] == 0 && d1[y] == 0 && d2[t] == 0) {
				v[i] = d1[y] = d2[t] = 1;
			    b[x] = i;
			    go(x + 1, z + a[x][i]);
			    v[i] = d1[y] = d2[t] = 0;
			}                                        
		}
	}
}	

	 
int main () 
{
	freopen("B.in", "r", stdin);
	freopen("B.out", "w", stdout);
	int i, j;
	scanf("%d", &n);
	for (i = 1; i <= n; i++)
		for (j = 1; j <= n; j++)
			scanf("%d", &a[i][j]);
	//		printf("%d", n);
	go(1, 0);
	for (i = 1; i <= n; i++) 
		d[i][c[i]] = 1;
//		printf("%d ", c[i]);
//	} puts("");
	for (i = 1; i <= n; i++) {
		for (j = 1; j <= n; j++)
			printf("%d ", d[i][j]);
		puts("");
	}
	
}