#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
#define mp make_pair
#define fx first
#define sx second
const int N = 100009;
int n, m, x, y, next[N], cnt, u[N], z;
pair <int, int> a[N], b[N], c[N];
int main () 
{
	freopen("D.in", "r", stdin);
	freopen("D.out", "w", stdout);
	int i, j;
	scanf("%d %d", &n, &m);
	for (i = 1; i <= n; i++) {
		scanf("%d", &x);
		a[i] = mp(x, i);
		c[i] = a[i];
	}
	sort(c + 1, c + 1 + n);
	c[0] = mp(0, 0); j = 0;
	for (i = 1; i <= n; i++) {
		if (c[i].fx != c[i - 1].fx) 
			a[c[i].sx].fx = ++j;	
		else
			a[c[i].sx].fx = j;
	}	
	for (i = 1; i <= n; i++) {
		x = a[i].fx;
		next[u[x]] = i;
		u[x] = i;
	}
	//for (i = 1; i <= n; i++)
//		printf("%d ", next[i]);
//	puts("");
	for (j = 1; j <= m; j++) {
		scanf("%d %d", &x, &y);
		if (x == 1 && y == n) 
			cnt = j;
		else {	
			cnt = 0;            
			for (i = x; i <= y; i++) 
				if (next[i] > y || next[i] == 0)
					cnt++;		
		}
		printf("%d\n", cnt);
	}
		
	
}