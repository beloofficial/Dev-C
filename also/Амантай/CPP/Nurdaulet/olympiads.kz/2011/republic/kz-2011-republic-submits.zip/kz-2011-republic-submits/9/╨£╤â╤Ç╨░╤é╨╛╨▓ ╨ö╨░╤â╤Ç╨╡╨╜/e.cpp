#include <cstdio>
#include <iostream>

using namespace std;

#define LL long long

LL A, B, C, L, R, mod, ans;

LL modul(LL x) {
	return x % mod;
}

LL f(LL x) {
	LL res = modul(modul(modul(x - A) * modul(x - B)) * modul(x - C));
	return modul(res);
}

int main() {
	freopen("E.in", "r", stdin);
	freopen("E.out", "w", stdout);

	scanf("%I64d %I64d %I64d %I64d %I64d %I64d", &A, &B, &C, &L, &R, &mod);

	for (; L <= R; L++) {
		ans = modul(ans + f(L));
	}
	
	printf("%I64d", modul(ans));

	return 0;
}