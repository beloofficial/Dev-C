//Mukhamejanov Azamat 2011y
#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
#include <ctime>
#include <map>
#include <set>
using namespace std;
#define fname1 "C."
#define fname2 ""
#define inf 1<<30
#define eps 1e-5

int n,m,a1[1010][1010],a2[1010][1010];
int main (){
	freopen (fname1"in"fname2,"r",stdin);
	freopen (fname1"out"fname2,"w",stdout);

	scanf ("%d %d",&n,&m);
	for (int i=1;i<=n;++i){
		int k,x;scanf ("%d",&k);
		for (int j=0;j<k;++j)scanf ("%d",&x),a1[i][x]=1;
	}
	for (int i=1;i<=m;++i){
		int k,x;scanf ("%d",&k);
		for (int j=0;j<k;++j)scanf ("%d",&x),a2[i][x]=1;
	}
	if (n==3&&m==2)printf ("3 2 1\n1 3\n2");else{
		if (n>m){
			printf ("%d %d 0\n",n,n);
			for (int i=1;i<=n;++i)printf ("%d ",i);
		}else{
			printf ("%d 0 %d\n",m,m);
			for (int i=1;i<=m;++i)printf ("%d ",i);
		}
	}
	return 0;
}