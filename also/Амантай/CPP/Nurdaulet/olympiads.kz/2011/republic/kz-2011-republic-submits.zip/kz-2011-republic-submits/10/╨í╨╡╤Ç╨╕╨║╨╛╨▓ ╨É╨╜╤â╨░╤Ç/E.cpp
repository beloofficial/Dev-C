// Solution by [A.S.]

// O(r - l) solution

#include <iostream>
#include <fstream>
         
#define intl long long

using namespace std;

intl ans, a, b, c, l, r, p;

intl fx (int x)
{
	return (((x - a) % p) * ((x - b) % p) * ((x - c) % p)) % p;	
}

int main()
{
	freopen ("E.in", "r", stdin);
	freopen ("E.out", "w", stdout);

	cin >> a >> b >> c >> l >> r >> p;

	ans = 0;

	for (int i = l; i <= r; i++)
		ans += fx(i);

	cout << ans;

	return 0;
}
