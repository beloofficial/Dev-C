#include<iostream>
#include<cstdio>
using namespace std;

int n,m,p;
int a[109][109];
int klv1,klv2,o1[109],o2[109];
int main()
{
freopen("C.in","r",stdin);
freopen("C.out","w",stdout);
  
scanf("%d%d",&n,&m);
for(int i=1;i<=n;i++){
scanf("%d",&p);
if(p==0){
o1[klv1]=i;
klv1++;
}
else{
for(int j=1;j<=p;j++){
scanf("%d",&a[p][j]);}}}

for(int i=1;i<=m;i++){
scanf("%d",&p);
if(p==0){
o2[klv2]=i;
klv2++;
}
else{
for(int j=1;j<=p;j++){
scanf("%d",&a[j][p]);}}}

if(n+klv2>=m+klv1){
printf("%d %d %d\n",n+klv2,n,klv2);
for(int i=1;i<=n;i++){
printf("%d ",i);}
printf("\n");
for(int i=0;i<klv2;i++){
printf("%d ",o2[i]);}}

else {
printf("%d %d %d\n",m+klv1,m,klv1);
for(int i=0;i<klv1;i++){
printf("%d ",o1[i]);}
printf("\n");
for(int i=1;i<=m;i++){
printf("%d ",i);}
}



return 0;
}

