#include <iostream>
#include <cstdio>
#include <vector>

using namespace std;

struct st {
	int c, d;
} str;

vector <st> v[2][501], bfs;
int mas[2][501];
int kl[501][2];
bool used[2][501];

void init(){
    for(int i = 0; i<500; i++){
     	mas[0][i] = 0;
    	mas[1][i] = 0;
    	used[0][i] = false;
    	used[1][i] = false;
    	kl[i][0] = 0;
    	kl[i][1] = 0;
   	}
}	

main(){
	init();

	freopen("c.in", "r", stdin);
	freopen("c.out", "w", stdout);

	int n, m, temp, k;

	cin >> n >> m;
	
	str.c = 1;
    for(int i = 0; i<n; i++){
    	cin >> k;
    	for(int j =0; j<k; j++){
    		cin >> str.d;
    		str.d--;
    		v[0][i].push_back(str);
    	}
	}	
	str.c = 0;
	for(int i = 0; i<m; i++){
		cin >> k;
		for(int j =0; j<k; j++){
    		cin >> str.d;
    		str.d--;
    		v[1][i].push_back(str);
    	}
	}

	k = 0;

	for(int i = 0; i<n; i++){
		if(used[0][i] == false){
			for(int j = 0; j<v[0][i].size(); j++)
				bfs.push_back(v[0][i][j]);	

			if (bfs.size()>0){
				k++;
			}
            while( bfs.size()>0 ){
             	if (used[ bfs[0].c ][ bfs[0].d ] == false){
             		used[ bfs[0].c ][ bfs[0].d ] = true;             	 	
             		for(int j = 0; j<v[ bfs[0].c ][ bfs[0].d ].size(); j++)
						bfs.push_back(v[ bfs[0].c ][ bfs[0].d ][j]);	
					mas[ bfs[0].c ][ bfs[0].d ] = k;             	 	
             	}
             	bfs.erase(bfs.begin());
            }
		}
	}

	for(int i = 0; i<n; i++){
		if (mas[0][i] != 0)
		 	kl[ mas[0][i] ][0]++;
	}
	for(int i = 0; i<m; i++){
		if (mas[1][i] != 0)
		 	kl[ mas[1][i] ][1]++;
	}

	kl[0][0] = n;
	kl[0][1] = m;

	for(int i = 1; i<=k; i++){
	 	if(kl[i][0] < kl[i][1]){
	 		kl[0][0] -= kl[i][0];
	 		kl[i][1] = 0;
	 	} else { //kl[k][0] > kl[k][1]
	 	    kl[i][0] = 0;
	 	    kl[0][1] -= kl[i][1];
	 	}
	}    

	cout << kl[0][0] + kl[0][1] << " " ;
	cout << kl[0][0] << " ";
	cout << kl[0][1] << endl;
	for(int i = 0; i<n; i++){
		if (mas[0][i] == 0){
		 	cout << i + 1 << " "; 
		} else {
			if( kl[ mas[0][i] ][0] == 0 )
		 	cout << i+1 << " ";
		}
	}
	cout << endl;
	for(int i = 0; i<m; i++){
		if (mas[1][i] == 0){
		 	cout << i + 1 << " "; 
		} else {
			if( kl[ mas[1][i] ][1] == 0 )
		 	cout << i+1 << " ";
		}
	}

	fclose(stdout);
}
