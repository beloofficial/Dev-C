#include<iostream>
#include<algorithm>
#include<cstdio>
#include<string>
#include<cstring>
#include<cmath>
#include<vector>
#include<stack>
#include<queue>
#include<map>
#include<set>

#define mp make_pair
#define pb push_back
#define fi first
#define se second

using namespace std;

int n,m,k,i,j,x,a[1100][1100];
bool r[1100];

int main()
{
	freopen("C.in","r",stdin);
	freopen("C.out","w",stdout);

	cin>>n>>m;

	for(i=1;i<=n;i++)
	{
		cin>>k;

		a[0][i]=k;
		for(j=1;j<=k;j++)
		{
			cin>>x;

			a[i][x+n]=1;
			a[x+n][0]++;
		}
	}

	for(i=1;i<=m;i++)
	{
		cin>>k;

		a[0][n+i]=k;
		for(j=1;j<=k;j++)
		{
			cin>>x;

			a[x][0]++;
			a[i+n][x]=1;
		}
	}

	m+=n;

	k=m;
	while(true)
	{
		x=0;
		for(i=1;i<=m;i++)
			if((a[0][i]>0)||(a[i][0]>0))
			if((a[0][i]+a[i][0]>a[0][x]+a[x][0])||((a[0][i]+a[i][0]==a[0][x]+a[x][0])&&((a[i][0]>a[x][0])||((a[i][0]==a[x][0])&&(a[0][i]>a[0][x])))))	
				x=i;

		if(x==0)  break;
		   
        r[x]=1;
        k--;

       	a[0][x]=a[x][0]=0;
       	for(i=1;i<=m;i++)
       	{
       		if(a[i][x]==1)
       		{
       			a[i][0]--;
       			a[i][x]=0;
       		}
       		if(a[x][i]==1)
       			a[0][i]--;
       	}
	}

    m-=n;

    if(k<max(m,n))
    {
    	if(m>n)	
    	{
    		cout<<m<<" 0 "<<m<<"\n";
    		for(i=1;i<=m;i++)  cout<<i<<" ";
    	}
    	else 
    	{
    		cout<<n<<" "<<n<<" 0 "<<"\n";
    		for(i=1;i<=n;i++)  cout<<i<<" ";
    	}
    }
    else
    {
    	j=0;
    	for(i=1;i<=n;i++)
    		if(!r[i])  j++;

    	cout<<k<<" "<<j<<" "<<k-j<<"\n";

    	for(i=1;i<=n;i++)  if(!r[i])
    		cout<<i<< " ";

    	cout<<"\n";

    	for(i=n+1;i<=n+m;i++)
    		if(!r[i])  cout<<i-n<<" ";
    }   

	return 0;
}