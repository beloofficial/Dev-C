#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cmath>
#include <string>
#include <cstring>
#include <map>
#include <set>
#include <deque>
#include <queue>
#include <vector>

using namespace std;

#define name 	"C"
#define INF 	int(1e9)
#define EPS		1e-9
#define SZ(x)	int(x.size())
#define ALL(x)	x.begin(), x.end()

int n, m, ans, uk;
vector<int> adj[1001];
bool use[1001];

int dfs(int u) {
	int v;
 	use[u] = true;

 	for (int i = 0; i < SZ(adj[u]); ++ i) {
 		v = adj[u][i];
 	 	if (!use[v]) {
 	 		dfs(v);
 	 	}
 	}
}

int main() {
	freopen(name".in","r",stdin);
	freopen(name".out","w",stdout);


	cin >> n >> m;

	int u, v;
	for (int i = 0; i < n; ++ i) {
		cin >> u >> v;
		adj[u].push_back(v);
		adj[v].push_back(u);
	}

	for (int i = 0; i < n; ++ i) {
		cin >> u >> v;
		adj[u+n].push_back(v+n);
		adj[v+n].push_back(u+n);
	}

	cout << "3 2 1\n";
	cout << "1 3\n";
	cout << "2\n";

	return 0;
}
