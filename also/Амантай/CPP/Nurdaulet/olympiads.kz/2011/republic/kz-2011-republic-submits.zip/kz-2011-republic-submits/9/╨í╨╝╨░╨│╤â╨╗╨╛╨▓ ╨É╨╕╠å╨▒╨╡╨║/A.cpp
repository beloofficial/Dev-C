#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <string.h>
#include <math.h>
#include <numeric>
#include <vector>
#include <time.h>
#define f first
#define s second
using namespace std;
int n, m, k, w[10000];
pair <int, int> p[10000];
vector < vector <int> > v;
bool used[10000], us[10000];
long long int mx = -999999999, cost = 0, wf = 0;
long long tup () {
	printf ("%I64d %I64d %I64d\n", mx, cost, wf);
	for (int i = 1; i <= m; i++) {
		if (used[i]) continue;
		used[i] = 1;
		for (int j = 1; j < v[p[i].s].size (); j++) {
			wf = wf + w[v[p[i].s][j]] * 1ll;
			us[v[p[i].s][j]] = 1;
			cost += p[i].f * 1ll;
			if (wf <= k) { 
				mx = max (mx, cost);
				tup ();
			}
			wf = wf - w[v[p[i].s][j]] * 1ll;
			us[v[p[i].s][j]] = 0;
			cost -= p[i].f * 1ll;
		}
		used[i] = 0;
	}
	return mx;
}
int main () {
	freopen ("A.in", "r", stdin);
	freopen ("A.out", "w", stdout);
	scanf ("%d%d%d", &n, &m, &k);
	v. resize (m + 1);
	for (int i = 1; i <= n; i++) 
		scanf ("%d", &w[i]);
	for (int i = 1; i <= m; i++)
		scanf ("%d", &p[i].f);
        for (int i = 1; i <= m; i++) {
        	v[i].push_back (-1);
       		while (1) {
       			char z;
       			int inx;
       			scanf ("%d%c", &inx, &z);
       			p[i].s = i;
       			v[i].push_back (inx);
       			if (char (z) == 10) break;
       			exit (0);
       		}
        } 
        printf ("%I64d", tup ());
	return 0;
} 