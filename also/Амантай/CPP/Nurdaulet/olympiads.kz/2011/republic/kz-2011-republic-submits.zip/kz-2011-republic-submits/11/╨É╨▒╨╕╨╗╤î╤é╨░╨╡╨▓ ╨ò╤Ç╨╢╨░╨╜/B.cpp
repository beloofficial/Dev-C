#include <iostream>
#include <algorithm>
#include <string>
#include <cstdlib>
#include <cstdio>
using namespace std;

int  maxi=0,st,r[55],b[55],n,k,a[55][55];   bool  v[55],d1[55],d2[55],d3[55],d4[55];

void  print(int l, int h, int s)
{
if (s>maxi) {
maxi=s;
for (int i=l; i<=h; i++) r[i]=b[i];
}	
}

void  rec (int p,int s)
{
if (p>k) {
	print(st,p-1,s); return;
}
for (int j=1; j<=n; j++)
if (!v[j])  
{
	int  ff=0;  if (!d1[p+j-1]) ff++;
	if (p-j+1<1) { if (!d3[j-p+1]) ff++;  }
	else if (!d2[p-j+1]) ff++;

	if (ff==2) {
	v[j]=true; d1[p+j-1]=true;
	if (p-j+1<1) d3[j-p+1]=true;
	else  d2[p-j+1]=true;
	b[p]=j;  
	
	rec(p+1,s+a[p][j]);

	v[j]=false; d1[p+j-1]=false;
	if (p-j+1<1) d3[j-p+1]=false;
	else  d2[p-j+1]=false;	
	}
}	

}

int main()
{
freopen ("B.in","r",stdin);
freopen ("B.out","w",stdout);
	int m;
cin>>n; 
for (int i=1; i<=n; i++)
{
	for (int j=1; j<=n; j++)
	cin>>a[i][j];
}	           

if (n>7) k=7; else k=n; //cout<<k<<" ddd";
//memset(v,false,sizeof(v));
//memset(d,false,sizeof(d));
st=1;  for (int i=0; i<50; i++) { v[i]=false; d1[i]=false; d2[i]=false; d3[i]=false; } 
rec (1,0);
//cout<<maxi<<endl;  
for (int i=0; i<50; i++) { v[i]=false; d1[i]=false; d2[i]=false; d3[i]=false; } 
for (int i=1; i<=k; i++)
{
	v[r[i]]=true; d1[i+r[i]-1]=true;
	if (i-r[i]+1<1) d3[r[i]-i+1]=true;
	else  d2[i-r[i]+1]=true;
}
 int p=k; st=p+1; k=n; maxi=0; rec(p+1,0);
for (int i=1; i<=n; i++)
{
for (int j=1; j<=n; j++)
{
	if (r[i]==j) cout<<"1 "; else cout<<"0 ";
} cout<<endl; }	
	return 0;
}