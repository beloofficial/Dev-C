#include<iostream>
#include<fstream>
#include<vector>
#include<set>
#include<map>
#include<cstdio>
#include<stack>
#include<queue>
#include<string>
#include<utility>
#include<cmath>
#include<bitset>
#include<list>
using namespace std;
#define ll long long 
#define pb push_back
#define mk make_pair
#define s second
#define f first
   ll   d[1000015];
   int  b[1000015];
   int  n,m,x[1005][1005];
   int  z[1005][1005];
 vector< vector< pair < int,int > > > a;
  void dix(int s)
    {
        for(int i=0;i<n*m;i++)
       {
        d[i]=32000000000LL;
        b[i]=false;
       }
       d[s]=0;
       int t=0;
        while(t<n*m)
          {
          ll mini=1000000000000LL, c1=-1;
            for(int i=0;i<n*m;i++)
              {
               if (d[i]<mini && b[i]==false)
                {
                 mini=d[i];
                 c1=i;
                }
              }
               if (c1==-1) break;
               b[c1]=true;
                for(int i=0;i<a[c1].size();i++)
                 {
                 int to,w;
                 to=a[c1][i].f;
                  w=a[c1][i].s;
                  if (d[to]>w+d[c1] && w>0)
                    {
                     d[to]=w+d[c1];
                    }
                 }
          t++;
          }
 
    }
int main ()
 {
   freopen ("H.in","r",stdin);
   freopen ("H.out","w",stdout);
      cin>>n>>m;
      int g=0;
       ll s;
      a.resize(n*m);
      for(int i=1;i<=n;i++)
       {
        for(int j=1;j<=m;j++)
         {
         scanf("%d", &x[i][j]);
         z[i][j]=g;g++;
         }
       }
        cin>>s;
        for(int i=1;i<=n;i++)
          {
           for(int j=1;j<=m;j++)
            {
            int as=z[i][j];
              if (i+1<=n)   {
              a[as].pb(mk(z[i+1][j],x[i+1][j])); }
             if (j+1<=m)
              a[as].pb(mk(z[i][j+1],x[i][j+1]));
             if (j-1>=1)
                a[as].pb(mk(z[i][j-1],x[i][j-1])); 
            }
          } 
          dix(0);
           cout<<s-d[n*m-1];
  
  return 0;
 }