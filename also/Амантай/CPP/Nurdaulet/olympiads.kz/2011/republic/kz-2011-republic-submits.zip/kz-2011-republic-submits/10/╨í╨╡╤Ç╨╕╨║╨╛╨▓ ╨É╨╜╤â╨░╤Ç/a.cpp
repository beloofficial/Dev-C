// Solution by [A.S.]

#include <algorithm>
#include <iostream>
#include <cstring>
#include <fstream>
#include <vector>

using namespace std;

vector <int > ans;
vector <int > l[30];
int n, m, s[100], p[100], k;
char b[200];

int main()
{
	freopen ("a.in", "r", stdin);
	freopen ("a.out", "w", stdout);

	cin >> n >> m >> k;

	for (int i = 0; i < n; i++)
		cin >> s[i];

	for (int i = 0; i < m; i++)
		cin >> p[i];

	gets (b);

	for (int z = 0; z < m; z++)
	{
		gets (b);

		k = 0;

		for (int i = 0; i < strlen (b); i++)
		{
			if (isdigit (b[i]))
				k *= 10, k += (b[i] - '0');
			else
				l[z].push_back (k), k = 0;		
		}	
		if (k)
			l[z].push_back (k);
	}
                             /*
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < l[i].size(); j++)
			cout << l[i][j] << " ";
		cout << "\n";
	}                      */


	bool ok, have;
	int maxS, sum, per[100] = {0}; 

        while (!per[n])
	{
		ok = true;
		maxS = sum = 0;

		for (int i = 0; i < n; i++)
			if (per[i])
				sum +=  s[i];
		
		if (sum > k)
		{
			ok = false;
			goto skip;
		}


		for (int i = 0; i < m; i++)
		{
			have = true;

			for (int j = 0; j < l[i].size(); j++)
			{
				if (!per[l[i][j] - 1])
				{
					have = false;
					break;
				}	
			}

			if (have)
			{
				maxS += p[i];
			}
		}


		skip:

		if (ok && maxS > ans.size())
		{
			ans.resize (0);
			for (int i = 0; i < n; i++)
				if (per[i])
					ans.push_back (i + 1);
		}

		per[0]++;

		for (int i = 0; i < n; i++)
			if (per[i] > 1)
				per[i] = 0,
				per[i + 1]++;
	}


	for (int i = 0; i < ans.size(); i++)
		cout << ans[i] << " ";

	return 0;
}
