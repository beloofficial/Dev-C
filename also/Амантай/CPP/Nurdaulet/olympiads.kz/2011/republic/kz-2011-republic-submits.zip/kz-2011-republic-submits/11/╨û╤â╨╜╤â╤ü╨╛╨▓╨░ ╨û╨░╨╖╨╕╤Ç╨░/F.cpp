#include<iostream>
#include<algorithm>
#include<cstdio>
#include<string>
#include<cstring>
#include<cmath>
#include<vector>
#include<stack>
#include<queue>
#include<map>
#include<set>

#define mp make_pair
#define pb push_back
#define fi first
#define se second

using namespace std;

queue<int> q;
char c;
int m,n,l,kol[100010][3],vv[100010][2],g[100010][20],tin[100010],tout[100010],b[100010];
vector<int> a[100010];


void dfs(int v,int p)
{
	int i;

	tin[v]=++m;
	b[v]=1;
    g[v][0]=p;

    for(i=1;i<=l;i++)
    	g[v][i]=g[g[v][i-1]][i-1];

    for(i=0;i<a[v].size();i++)
    	if(b[a[v][i]]==0)
    	{
    		kol[a[v][i]][1]+=kol[v][1]+1;
    		b[a[v][i]]=1;
    		dfs(a[v][i],v);
    	}                

	tout[v]=++m;
}

bool upper(int x,int y)
{
	return ((tin[x]<tin[y])&&(tout[x]>tout[y]));
}

int lca(int x,int y)
{
	if(upper(x,y))   return x;
	if(upper(y,x))   return y;

	int i;

	for(i=l;i>=0;i--)
		if(!upper(g[x][i],y))  x=g[x][i];

	return g[x][0];
}

int main()
{
	freopen("F.in","r",stdin);
	freopen("F.out","w",stdout);

	int i,j,u,v;

	cin>>n>>m;
	for(i=0;i<m;i++)
	{
		cin>>u>>vv[i][0];
		a[u].pb(vv[i][0]);
		vv[i][1]=1;
	}

	l=0;
	v=1;
	while(v<=n)
	{
		v*=2;
		l++;
	}

	m=0;
	dfs(1,1);

	q.push(1);
	b[1]=0;
	while(!q.empty())
	{
		v=q.front();
		q.pop();

		for(i=0;i<a[v].size();i++)
		{
			b[a[v][i]]=b[v]+1;
            q.push(a[v][i]);
		}
	}

	/*
	int k;
	for(i=1;i<=n;i++)
		for(j=0;j<a[i].size();j++)
		{
			v=a[i][j];
			kol[v][1]++;

    		q.push(v);
    		while(!q.empty())
    		{
    			v=q.front();
    			q.pop();

    			for(k=0;k<a[v].size();k++)
    			{
    				u=a[v][k];
    				kol[u][1]++;
    				q.push(u);
    			}
    		}
		}

	for(i=1;i<=n;i++)
		cout<<kol[i][1]<<" "<<kol[i][2]<<"\n";
	*/
    cin>>m;
    for(i=0;i<m;i++)
    {
    	cin>>c;

    	if(c=='q')
    	{
    		cin>>v>>u;

    		j=lca(v,u);

    		cin>>n;

    		cout<<kol[u][n]+kol[v][n]-2*kol[j][n]<<"\n";
    	}
    	else
    	{
    		cin>>n>>j;

    		v=vv[j-1][0];

    		if(n!=vv[j-1][1])
    		{
    		vv[j-1][1]=n;
    		kol[v][n]++;
    		kol[v][3-n]--;
    		q.push(v);
    		while(!q.empty())
    		{
    			v=q.front();
    			q.pop();

    			for(j=0;j<a[v].size();j++)
    			{
    				u=a[v][j];
    				kol[u][n]++;
    				kol[u][3-n]--;
    				q.push(u);
    			}
    		}
    		}
    	}
	}

	return 0;
}