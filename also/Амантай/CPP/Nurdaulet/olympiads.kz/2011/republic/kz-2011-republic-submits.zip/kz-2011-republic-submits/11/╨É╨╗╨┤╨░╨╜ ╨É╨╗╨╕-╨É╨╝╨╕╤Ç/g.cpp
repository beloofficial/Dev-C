#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <ctime>
#include <cmath>
#include "dist.h"

using namespace std;

int fx[] = {0, 0, 1, -1}, fy[] = {1, -1, 0, 0};
int curx, cury;
long long pace;
long long di[6];

int main ()
{
	start ();

	for (int best;;)
	{
		pace = dist (curx, cury);
		if (!pace) break;
		pace = (pace+1)>>1;

		for (int i = 0; i < 4; i++)
			di[i] = dist (pace*fx[i]+curx, pace*fy[i]+cury);

		best = 0;
		for (int i = 0; i < 4; i++)
			if (di[i] < di[best])
				best = i;
		curx += pace*fx[best]; cury += pace*fy[best];
	}

	finish (curx, cury);

	return 0;
}
