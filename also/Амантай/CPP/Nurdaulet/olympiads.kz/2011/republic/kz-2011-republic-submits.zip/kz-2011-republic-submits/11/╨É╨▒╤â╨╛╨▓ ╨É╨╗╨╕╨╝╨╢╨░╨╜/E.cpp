#include <iostream>
#include <cstdio>
#include <vector>
#include <string>
#include <cstring>
#include <cmath>
#include <map>
#include <algorithm>
#include <set>
#include <cctype>

using namespace std;

const double pi = acos((double) - 1);
const int maxn = 30;

int main() {
	
	freopen("E.in", "r", stdin);
	freopen("E.out", "w", stdout);

	long long a, b, c, l, r, p, s = 0, cur;

	cin >> a >> b >> c >> l >> r >> p;

	/*for (l; l <= r; l++) {
	 	cur = ((l - a) * (l - b)) % p;
	 	cur = (cur * (l - c)) % p;
	 	s = (s + cur) % p;
	}*/

	long long k1 = a + b + c;
	long long k2 = a * b + b * c + c * a;
	s = (0 - (r - l + 1) * (((a * b) % p) * c) % p) % p;
	for (int x = l; x <= r; x++) {
		cur = (x * x) % p;
		s += cur * x - cur * k1 + x * k2;
		//s %= p;
	}

	cout << s % p;

	return 0;
}
