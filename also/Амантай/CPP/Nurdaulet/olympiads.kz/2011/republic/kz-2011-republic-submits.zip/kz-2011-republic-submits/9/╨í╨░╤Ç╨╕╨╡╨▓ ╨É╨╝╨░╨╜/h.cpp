#include<iostream>
#include<fstream>
#include<set>
#include<utility>
#include<cstdio>
#include<cstdlib>
#define F first
#define S second
#define mp make_pair
#define in insert
#define er erase
using namespace std;
int n,m,i,j;
bool b[1005][1005];
long long a[1005][1005],c[1005][1005],s;
set<pair<int,pair<int,int> > > v;
set<pair<int,pair<int,int> > >::iterator it;
int main()
{
freopen("H.in","r",stdin);
freopen("H.out","w",stdout);
ios_base::sync_with_stdio(0);
cin>>n>>m;
for(i=1;i<=n;i++)
{
for(j=1;j<=m;j++)
{
cin>>a[i][j];
b[i][j]=c[i][j]=0;
}
}
cin>>s;
b[1][1]=c[1][1]=s;
v.in(mp(s,mp(1,1)));
while(v.size())
{
it=v.end();
it--;
s=(*it).F;
i=(*it).S.F;
j=(*it).S.S;
v.erase(*it);
if(j>1 && !b[i][j-1]) b[i][j-1]=1,c[i][j-1]=s-a[i][j-1],v.in(mp(c[i][j-1],mp(i,j-1)));
if(j>1 && b[i][j-1] && c[i][j-1]<s-a[i][j-1]) v.er(mp(c[i][j-1],mp(i,j-1))),c[i][j-1]=s-a[i][j-1],v.in(mp(c[i][j-1],mp(i,j-1)));
if(j<m && !b[i][j+1]) b[i][j+1]=1,c[i][j+1]=s-a[i][j+1],v.in(mp(c[i][j+1],mp(i,j+1)));
if(j<m && b[i][j+1] && c[i][j+1]<s-a[i][j+1]) v.er(mp(c[i][j+1],mp(i,j+1))),c[i][j+1]=s-a[i][j+1],v.in(mp(c[i][j+1],mp(i,j+1)));
if(i<n && !b[i+1][j]) b[i+1][j]=1,c[i+1][j]=s-a[i+1][j],v.in(mp(c[i+1][j],mp(i+1,j)));
if(i<n && b[i+1][j] && c[i+1][j]<s-a[i+1][j]) v.er(mp(c[i+1][j],mp(i+1,j))),c[i+1][j]=s-a[i+1][j],v.in(mp(c[i+1][j],mp(i+1,j)));
}
cout<<c[n][m];
return 0;
}