// Has done by Aybek Smagulov
// 17.04.2011 Astana KTL 
#include <iostream>
#include <algorithm>
#include <utility>
#include <iomanip>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <string.h>
#include <math.h>
#include <numeric>
#include <time.h>
#define ll long long
using namespace std;
const ll inf = 999999999; 
ll plsi[3] = {1, 0, 0}, plsj[3] = {0, -1, 1};
ll n, m, a[1001][1001], d[1001][1001];
ll iq[1000001], jq[1000001], q = 0;
ll  nastr;
bool check (ll i, ll j) {
	if (i >= 0 && i < n && j >= 0 && j < m) return 1;
	return 0;
}
int main () {
	freopen ("H.in", "r", stdin);
	freopen ("H.out", "w", stdout);
	scanf ("%I64d%I64d", &n, &m);
	for (ll i = 0; i < n; i++)
		for (ll j = 0; j < n; j++) {
			scanf ("%I64d", &a[i][j]);
			d[i][j] = inf;
		}
	scanf ("%I64d", &nastr);
        iq[q] = 0;
        jq[q] = 0;
        d[0][0] = 0;
        q++;
        for (ll v = 0; v < q; v++) {
        	ll i = iq[v], j = jq[v];
        	for (ll e = 0; e < 3; e++)
        		if (check (i + plsi[e], j + plsj[e]) && d[i + plsi[e]][j + plsj[e]] > a[i + plsi[e]][j + plsj[e]] + d[i][j]) {
				d[i + plsi[e]][j + plsj[e]] = d[i][j] + a[i + plsi[e]][j + plsj[e]];
 	      			iq[q] = i + plsi[e];
        			jq[q] = j + plsj[e];
        			q++;	
        		}	
        }
        printf ("%I64d", nastr - d[n - 1][m - 1]);
        return 0;
} 