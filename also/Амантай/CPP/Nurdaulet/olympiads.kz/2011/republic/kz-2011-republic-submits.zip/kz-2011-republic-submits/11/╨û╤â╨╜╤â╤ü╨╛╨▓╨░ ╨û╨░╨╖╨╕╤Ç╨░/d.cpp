#include<iostream>
#include<algorithm>
#include<cstdio>
#include<string>
#include<cstring>
#include<cmath>
#include<vector>
#include<stack>
#include<queue>
#include<map>
#include<set>

#define mp make_pair
#define pb push_back
#define fi first
#define se second

using namespace std;

set<int> s,s2,a[132000];

int n,m,lev,x,l,r,i;

void build(int x,int v)
{
	a[v].insert(x);

	if(v!=1) build(x,v/2);
}

int main()
{
	freopen("D.in","r",stdin);
	freopen("D.out","w",stdout);

	cin>>n>>m;

	if(m<1000)
	{
		int c[100001];
		for(i=1;i<=n;i++)
			cin>>c[i];

		for(i=0;i<m;i++)
		{
			cin>>l>>r;

			s.clear();
			while(l<=r)
			{
				s.insert(c[l]);
				l++;
			}

			cout<<s.size()<<"\n";
		}	
	}
	else
	{
	lev=1;
	while(lev<n)  lev*=2;

	for(i=0;i<n;i++)
	{
		cin>>x;

		build(x,lev+i);
	}

	if(a[1].size()==n)
	{
		for(i=0;i<m;i++)
		{
			cin>>l>>r;
			cout<<r-l+1<<"\n";
		}

		return 0;
	}

	for(i=n+lev;i<2*lev;i++)  build(x,i);

	for(i=0;i<m;i++)
	{
		cin>>l>>r;

		l+=lev-1;
		r+=lev-1;

		s.clear();
		while(l<=r)
		{
			if(l%2==1)
			{
			    if(a[l].size()>s.size())
			    {
			    	s2=s;
			    	s=a[l];	
			    }
			    else s2=a[l];

				while(!s2.empty())
				{
					s.insert(*(s2.begin()));
					s2.erase(s2.begin());
				}

				l++;
			}		

			if(r%2==0)
			{
			    if(a[r].size()>s.size())
			    {
			    	s2=s;
			    	s=a[r];	
			    }
			    else s2=a[r];

				while(!s2.empty())
				{
					s.insert(*(s2.begin()));
					s2.erase(s2.begin());
				}

				r--;
			}

			l/=2;
			r/=2;
		}

		cout<<s.size()<<"\n";
	}
	}
	                           
	return 0;
}