#include <iostream>
#include <fstream>
#include <utility>
#include <vector>
#include <set>

using namespace std;

int n, m, a[1005][1005];
long long s;
long long d[1005][1005];
set < pair < long long, pair < int, int > > > se;

int main(){
    freopen ("H.in", "r", stdin);
    freopen ("H.out", "w", stdout);
    cin >> n >> m;
    for (int i = 0;i < n;i++)
    	for (int j = 0;j < m;j++){
    		scanf("%d", &a[i][j]);
    		d[i][j] = 1000000000000000000;
    	}
    cin >> s;
    se.insert(make_pair(0, make_pair(0, 0)));
    d[0][0] = 0ll;
    while (!se.empty()){
    	pair < long long, pair < int, int > > p = *se.begin();
    	int x = p.second.first;
    	int y = p.second.second;
    	long long l = p.first;
    	se.erase(se.begin());
    	if (y > 0 && d[x][y - 1] > d[x][y] + a[x][y - 1]){
    		se.erase(make_pair(d[x][y - 1], make_pair(x, y - 1)));
    		d[x][y - 1] = d[x][y] + a[x][y - 1];
    		se.insert(make_pair(d[x][y - 1], make_pair(x, y - 1)));
    	}
    	if (y < m - 1 && d[x][y + 1] > d[x][y] + a[x][y + 1]){
    		se.erase(make_pair(d[x][y + 1], make_pair(x, y + 1)));
    		d[x][y + 1] = d[x][y] + a[x][y + 1];
    		se.insert(make_pair(d[x][y + 1], make_pair(x, y + 1)));
    	}
    	if (x < n - 1 && d[x + 1][y] > d[x][y] + a[x + 1][y]){
    		se.erase(make_pair(d[x + 1][y], make_pair(x + 1, y)));
    		d[x + 1][y] = d[x][y] + a[x + 1][y];
    		se.insert(make_pair(d[x + 1][y], make_pair(x + 1, y)));
    	}
    }
    cout << s - d[n - 1][m - 1];
}