//Solution by Balakshy Andrey 16.04.11

#include <cstdio>
#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>

using namespace std;

#define pb push_back
#define mp make_pair
#define For(i, p1, p2, st) for (int i = (int)p1; i < (int)p2; i += (int)st)
#define FoR(i, p1, p2, st) for (int j = (int)p1; i > (int)p2; i -= (int)st)  


int n, m, k, ch;
vector <int> w, p, s[26], kof; 
int v1, v2, mx = - 1 << 30;

int main()
{
  freopen("A.in", "r", stdin);
   freopen("A.out", "w", stdout); 

    cin >> n >> m >> k;
     For(i, 0, n, 1) scanf("%d", &ch), w.pb(ch);
      For(i, 0, m, 1) scanf("%d", &ch), p.pb(ch);


       For(i, 0, m, 1) {                
         scanf("%d", &ch);  
          s[i].pb(ch);
         scanf("%d", &ch);  
          s[i].pb(ch);

       }	
   
    For(i, 0, m, 1){
     if (p[i] > mx){
      mx = p[i];
      v1 = s[i][1]; v2 = s[i][0];

     }
   
    } 
   cout << v1 << " " << v2;

  return 0;
}
