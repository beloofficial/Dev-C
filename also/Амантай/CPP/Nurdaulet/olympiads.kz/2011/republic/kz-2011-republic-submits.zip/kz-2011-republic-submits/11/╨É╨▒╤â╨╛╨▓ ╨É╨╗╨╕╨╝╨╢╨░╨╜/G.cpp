#include <iostream>
#include <cstdio>
#include <vector>
#include <string>
#include <cstring>
#include <cmath>
#include <map>
#include <algorithm>
#include <set>
#include <cctype>
#include "dist.h"

using namespace std;

const double pi = acos((double) - 1);
/*
int ansx, ansy;

void start() {
	freopen("G.in", "r", stdin);
	freopen("G.out", "w", stdout);

	cin >> ansx >> ansy;
}

double dist (int x, int y) {
	return sqrt(1LL * (x - ansx) * (x - ansx) + 1LL * (y - ansy) * (y - ansy));
}

void finish (int x, int y) {
 	if (x == ansx && y == ansy)
 		cout << "OK";
 	else 
 		cout << "WA";
}
*/
int main () {
	
	double r, d = 360.0 / 9999;
	
	int x, y;

	start();

	r = dist(0, 0);

	double a = 0;

	for (int i = 1; i < 10000; i++) {
		x = round((r * cos(pi * a / 180)));
		y = round((r * sin(pi * a / 180)));
		if (dist(x, y) == 0) {
			finish(x, y);
			return 0;
		}
		a += d;
	}

	return 0;
}
