#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <vector>
#include <set>
#include <queue>
#include <deque>

#define pb			push_back
#define mp			make_pair
#define sqr(x)  	((x)*(x))
#define rep(i, x)   for(int i = 0; i < x; ++ i)
#define sz			size()
#define fi			first
#define se			second
#define name		"E"

using namespace std;
typedef long long LL;
typedef pair <int, int> Pair;
typedef unsigned long long ull;

ull l, r, a, b, c, p;

ull f(ull x) {
	return ((x-a)%p)*((x-b)%p)*((x-c)%p);
}

int main() {
    ios_base::sync_with_stdio(0);

	freopen(name".in", "r", stdin);
	freopen(name".out", "w", stdout);
	
	
	cin >> a >> b >> c
		>> l >> r >> p;
	
	ull s = 0;
	for (ull i = l; i <= r; ++ i) {		
		s += f(i)%p;	
	}

	cout << s;
	
	return 0;
}

