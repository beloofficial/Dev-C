#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <string.h>
#include <math.h>
#include <numeric>
#include <vector>
#include <time.h>
#define inf 999999999
#define f first
#define s second
using namespace std;
int n, m; bool a[500][500];
pair <int, int> vals [1000];
vector <int> fans, sans;
int main () {
	freopen ("C.in", "r", stdin);
	freopen ("C.out", "w", stdout);
	scanf ("%d%d", &n, &m);
	for (int i = 1; i <= n + m; i++)
		vals[i].f = inf;
	for (int i = 1; i <= n; i++) {
		int k;
		scanf ("%d", &k);
		if (!k)
			fans.push_back (i);
		for (int q = 1; q <= k; q++) {
			int j;
			scanf ("%d", &j);
		        j += n;	
			a[i][j] = 1;
		}
	}
	for (int i = 1; i <= m; i++) {
		int k;
		scanf ("%d", &k);
		if (!k)
			sans.push_back (i);
		for (int q = 1; q <= k; q++) {
			int j;
			scanf ("%d", &j);
			a[i + n][j] = 1;
		}
	}
	int maxv = m + n;
	for (int i = 1; i <= maxv; i++) {
		for (int j = 1; j <= maxv; j++) {
			if (a[i][j] && a[j][i] && j > n && i <= n || a[i][j] && a[j][i] && i > n && j <= n) {
				 if (vals[i].f == inf) vals[i].f = 0;
				 vals[i].f++;
		        	 vals[i].s = i;
		        }
		}
	}
	sort (vals + 1, vals + maxv + 1);
	for (int i = maxv; i >= 1; i--) {
//	printf ("%d %d\n", vals[i].f, vals[i].s);
		if (vals[i].f != inf && vals[i].f > 0) {
			  vals[i].f = inf;
			  int v = vals[i].s;
			  for (int j = 1; j <= maxv; j++) {
			  	if (a[v][j] && a[j][v] && j > n && v <= n || a[v][j] && a[j][v] && v > n && j <= n) {
			  		a[v][j] = 0;
			  		a[j][v] = 0;
			  		for (int q = 1; q <= maxv; q++) {
			  			if (vals[q].s == j) {
			  				vals[q].f--;
			  				break;
			  			}
			  		}
			  	}
			  }
		}
		if (!vals[i].f) {
			 if (vals[i].s <= n)
				fans.push_back (vals[i].s);
			else
				sans.push_back (vals[i].s - n);	
		}
	}
	printf ("%d %d %d\n", fans.size () + sans.size (), fans.size (), sans. size ());
	for (int i = 0; i < fans.size (); i++)
		printf ("%d ", fans[i]);
	printf ("\n");
	for (int i = 0; i < sans.size (); i++)
		printf ("%d ", sans[i]);
	return 0;
} 