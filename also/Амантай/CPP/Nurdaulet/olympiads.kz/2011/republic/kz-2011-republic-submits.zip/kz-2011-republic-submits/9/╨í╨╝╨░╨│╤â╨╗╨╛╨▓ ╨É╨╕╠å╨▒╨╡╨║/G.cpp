#include <iostream>
#include <algorithm>
#include <utility>
#include <iomanip>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <string.h>
#include <math.h>
#include <numeric>
#include <time.h>
#define base 1000000
using namespace std;
struct Large {
	int d[100001], len;
	Large () {
		memset (d, 0, sizeof (d));
		len = 0;
	} 
	void print () {
		printf ("%d", d[len - 1]);
		for (int i = len - 2; i >= 0; i--) 
			printf ("%06d", d[i]);
	}

} Ans;

Large Fact (int N, long long P) {
	Large res;
	res.d[res.len++] = 1;
	for (int i = 2; i <= N; i++) {
		int j = 0, h; long long carry = 0;
		for (; j < res.len || carry; j++) {
			long long cur = ( (j < res.len ? res.d[j] * i : 0) * 1ll + carry);
			carry = (cur / base) * 1ll; 
			res.d[j] = cur % base;
			h = j;
		}
//		res.print ();
//		printf ("\n");
		if (h >= res.len) res.len = h + 1;
		carry = 0;
		for (int i = res. len - 1; i >= 0; i--) {
			  long long cur = res.d[i] * 1ll + carry;
			  carry = cur % P;
	           	  if (i) carry = carry * base;
		}
		if (!carry) {
			printf ("0");
			exit (0);
		}
		res.len = 0;
		while (carry) {
			res.d[res.len++] = carry % base;
			carry /= base;
		}
		while (res.len > 1 && !res.d[res.len - 1])
			res.len--;
//		res.print ();
//		printf ("\n");
	}
	return res;
}
int main () {
	freopen ("G.in", "r", stdin);
	freopen ("G.out", "w", stdout);
	int n; long long p;
	scanf ("%d%I64d", &n, &p);
	Ans = Fact (n, p);
	Ans. print ();
	return 0;
} 