//Solution by Balakshy Andrey 16.04.11

#include <cstdio>
#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>
#include <memory.h>

using namespace std;

#define pb push_back
#define mp make_pair
#define For(i, p1, p2, st) for (int i = (int)p1; i < (int)p2; i += (int)st)
#define FoR(i, p1, p2, st) for (int j = (int)p1; i > (int)p2; i -= (int)st)  


const int num = 16;

int n, pole[num][num], res[num][num], vr[num][num], mx = -1, z, zz, zz2, z2;


void print()
{
 For(i, 0, n, 1){
   For(j, 0, n, 1) printf("%d ", res[i][j]);
  printf("\n");
 }
}

void tempprint()
{


 For(i, 0, n, 1){
   For(j, 0, n, 1) printf("%d ", vr[i][j]);
  printf("\n");
 }
  printf("\n");

}

void remember()
{
 For(i, 0, n, 1)
  For(j, 0, n, 1) 
   res[i][j] = vr[i][j];    
}

void clear()
{
 For(i, 0, n, 1)
  For(j, 0, n, 1) vr[i][j] = 0;

}

bool diag_vert(int a, int b)
{
  zz = b - 1, z = a - 1;  zz2 = b + 1;
   while(1){
     if (z >= 0 && zz >= 0)
    if (vr[z][zz]) return false;
      if (z >= 0 && zz2 < n) if (vr[z][zz2]) return false; 
     z--, zz--; zz2++;
  if (z < 0 && zz2 >= n && zz < 0) break;
   }
 
  zz = a - 1, z = a; 

  while(zz >= 0){
   if (vr[zz][b]) return false;
  zz--;
  }

  zz = a + 1; z = a;
   while(zz < n){
    if (vr[zz][b]) return false;
   zz++;
   }
   

  zz = b - 1; z = a; zz2 = b + 1;
  while(1){
   if (zz >= 0) if (vr[z][zz]) return false; 
   if (zz2 < n) if (vr[z][zz2]) return false;
 zz--; zz2++;
    if (zz < 0 && zz2 >= n) break;
  }
 
 return true;
}

void rec(int k, int i, int sum)
{
  if (i < n){  
   vr[i][k] = 1;  
    if (diag_vert(i, k)){
     if (i == n - 1) if (sum + pole[i][k] > mx) remember(), mx = sum + pole[i][k];  
       else; else 
      rec(0, i + 1, sum + pole[i][k]);     
    }
    else if (k < n) memset(vr[i], 0, sizeof(vr[i])), rec(k + 1, i, sum);   
  }
}

int main()
{
  freopen("B.in", "r", stdin);
   freopen("B.out", "w", stdout); 

    cin >> n;
  
    For (i, 0, n, 1)
     For(j, 0, n, 1)
      scanf("%d", &pole[i][j]), res[i][j] = 0, vr[i][j] = 0;


   //    For(i, 0, n, 1) vr[i][0] = 1;
       
      For(w, 0, n, 1) clear(), 
         rec(w, 0, 0);

    print();
 
  return 0;
}
