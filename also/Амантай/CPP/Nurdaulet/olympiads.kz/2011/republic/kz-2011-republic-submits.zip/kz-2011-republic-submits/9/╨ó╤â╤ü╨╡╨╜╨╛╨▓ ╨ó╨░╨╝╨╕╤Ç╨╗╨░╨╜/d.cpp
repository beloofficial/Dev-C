#include<iostream>
#include<set>
#include<cstdio>
using namespace std;

int n,m;
int a[100009];
set<int> b;
int l,r;
int main()
{

freopen("D.in","r",stdin);
freopen("D.out","w",stdout);
             
scanf("%d%d",&n,&m);

for(int i=1;i<=n;i++){
scanf("%d",&a[i]);}
for(int i=0;i<m;i++){
scanf("%d%d",&l,&r);
for(int j=l;j<=r;j++){
b.insert(a[j]);
}
printf("%d\n",b.size());  
while(!b.empty()){
b.erase(b.begin());
}
                  }
return 0;
}
