// O, velikiy System Judge!
// Posshadi menya! Plzplzplzplzplz
#include <cstdio>      
#include <vector>
#include <algorithm>

using namespace std;


void mymerge(vector<int> &a, int n, vector<int> &b, int m, vector<int> &c, int &sz)
{
	int i, j; sz = i = j = 0;
	for (; i < n && j < m; ){
		if (a[i] <= b[j]){
			if (!sz || c[sz - 1] != a[i])
				c[sz++] = a[i];
			i++;
		}
		else{
			if (!sz || c[sz - 1] != b[j])
				c[sz++] = b[j];
			j++;
		}
	}
	for (; i < n; i++)
		if (!sz || c[sz - 1] != a[i])
			c[sz++] = a[i];
	for (; j < m; j++)
		if (!sz || c[sz - 1] != b[j])
			c[sz++] = b[j];
}

vector<int> t[201000], tem[2];
int nu[201000], a[101000], n, m, ans[100], na, tn[2], c;

void build (int i, int l, int r)
{
	if(l == r)
	{
		t[i].resize(1);
		t[i][0] = a[l];
		nu[i] = 1;
	}
	else
	{
		int m = (l + r) / 2;
		build(i + i, l, m);
		build(i + i + 1, m + 1, r);
		t[i].resize(t[i + i].size() + t[i + i + 1].size());
		mymerge(t[i + i], nu[i + i],
			t[i + i + 1], nu[i + i + 1],
			t[i], nu[i]);
	}
//	printf("built for %d %d %d\n", i, l , r);
//	for (int j = 0; j < nu[i]; j++)
//		printf("%d ", t[i][j]);puts("");
}

void get (int l, int r, int i = 1, int tl = 0, int tr = n - 1){
	if (l == tl && r == tr){
//		printf("got %d %d %d\n", i, l, r);
		ans[na++] = i; return;
	}
	int m = (tl + tr) / 2;
	if (r <= m)
		get(l, r, i + i, tl, m);
	else if (l > m)
		get(l, r, i + i + 1, m + 1, tr);
	else {
		get(l, m, i + i, tl, m);get(m + 1, r, i + i + 1, m + 1, tr);
	}
}
                                                                         
int main(){
	freopen("D.in", "r", stdin);
	freopen("D.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for (int i = 0; i < n; i++)
		scanf("%d", a + i);
	build(1, 0, n - 1);
	tem[0].resize(n);tem[1].resize(n);
	for (int i = 0; i < m; i++)
	{
		int l, r, out = 0;
		scanf("%d%d", &l, &r);
		l--;r--;
		na = 0;
		get(l, r);
		tn[0] = tn[1] = 0;
		for (int k = 0; k < na; k++)
		{
			mymerge(tem[c], tn[c], t[ans[k]], nu[ans[k]], tem[c^1], tn[c^1]);
			c ^= 1;
		}
		printf("%d\n", tn[c]);
	}
	return 0;
}

