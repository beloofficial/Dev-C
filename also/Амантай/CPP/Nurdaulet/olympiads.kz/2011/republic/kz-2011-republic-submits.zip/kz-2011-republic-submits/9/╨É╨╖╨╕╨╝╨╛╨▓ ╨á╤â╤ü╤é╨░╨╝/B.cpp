#include<iostream>
#include<vector>
#include<fstream>
#include<cstdio>
#include<utility>
#include<map>
#include<string>
#include<set>
#include<stack>
using namespace std;
#define s second 
#define f first
   vector< pair <int ,int > > a(14);
  int n,maxi=0;
  int b[15][15];
  int d[15][15];
  int m,j;
  void calc (int x,int k){
     if (k>n){
          int sum=0;
             for(j=1;j<=k-1;j++){
              sum+=d[a[j].f][a[j].s];
              }
                if (sum>maxi)
                {
                maxi=sum;
                  for(int i=1;i<=n;i++)for(int j=1;j<=n;j++)b[i][j]=0;
                  for(int i=1;i<=k-1;i++)b[a[i].f][a[i].s]=1;
                }
 
     return;
    }
    if (x>n)return;
    a[k].s=x;
     for(int i=1;i<=n;i++)
       {
        a[k].f=i;
        for(j=1;j<=k;j++)
         {
          if (a[j].f==a[k].f || a[j].s+a[j].f==a[k].s+a[k].f || a[j].s-a[j].f==a[k].s-a[k].f)break;
         }
         if (j==k)calc(x+1,k+1);
       }
       calc(x+1,k);
  }

int main ()
 {
     freopen("B.in","r",stdin);
     freopen("B.out","w",stdout);
     scanf("%d", &n);
     for(int i=1;i<=n;i++)
      {
       for(int j=1;j<=n;j++)
        {
        cin>>d[i][j];
        }
      }
   calc(1,1);
      for(int i=1;i<=n;i++)
      {
       for(int j=1;j<=n;j++)
        {
        cout<<b[i][j]<<" ";
        }
        cout<<endl;
      }
  return 0;
 }