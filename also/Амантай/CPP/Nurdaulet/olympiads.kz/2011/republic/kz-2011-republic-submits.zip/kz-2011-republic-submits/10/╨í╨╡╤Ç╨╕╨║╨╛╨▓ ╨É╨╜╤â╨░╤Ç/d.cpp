// Solution by [A.S.]

#include <algorithm>
#include <iostream>
#include <fstream>
#include <vector>

#define max_n 100000 + 13

using namespace std;

vector <int > v;
int n, m, l, r, a[max_n];

bool is_in (int x)
{
	for (int i = 0; i < v.size(); i++)	
		if (v[i] == x)
			return true;
	return false;
}


int main()
{
	freopen ("d.in", "r", stdin);
	freopen ("d.out", "w", stdout);

	scanf ("%d %d", &n, &m);

	for (int i = 0; i < n; i++)
		scanf ("%d", &a[i]);

	for (int i = 0; i < m; i++)
	{
		scanf ("%d %d", &l, &r);

		v.resize (0);
		for (int j = l - 1; j < r; j++)
			if (!is_in (a[j]))
				v.push_back (a[j]);

		printf ("%d\n", v.size());					
	}

	return 0;
}
 