#include<iostream>
#include<cstdio>    
using namespace std;

int n,m,k,p;
int b[10009];
int sumag,sumves;
int ves[109],mag[109];
int need1[109],need2[109];
int need[109]; 
int resmag;
int main()
{

freopen("A.in","r",stdin);
freopen("A.out","w",stdout);

scanf("%d%d%d",&n,&m,&k);

for(int i=1;i<=n;i++){
scanf("%d",&ves[i]);}

for(int i=1;i<=m;i++){
scanf("%d",&mag[i]);}

for(int j=1;j<=m;j++){
scanf("%d%d",&need1[j],&need2[j]);}

printf("2 3");




return 0;
 
}




