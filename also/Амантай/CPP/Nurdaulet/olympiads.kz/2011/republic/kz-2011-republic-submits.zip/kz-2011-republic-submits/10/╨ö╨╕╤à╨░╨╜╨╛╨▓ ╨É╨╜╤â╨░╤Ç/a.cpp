#include <cstdio>
#include <iostream>
#include <algorithm>
#include <cstring>
#include <vector>
using namespace std;
#define N 200
int n, m, k, ans, i, j, a[N], x[N];
vector <int> v[N];
bool b[N], res[N];

int go(int i, int d)
{
	while (i > 0 && b[i] == 1) b[i] = 0, i--;
	b[i] = 1;
	int s = 0;
	for (int j = 1; j <= n; j++)
	{
		s += a[j] * b[j];
	}
	
	if (s > k)
		return i;
	
	for(int j = 1; j <= m; j++)
	{
		for (int l = 0; l < v[j].size(); l++)
		{
			if (!b[v[j][l]])
				goto end;
		}
		d += x[j];
		end:;
	}
	if (d > ans)
	{
		ans = d;
		for (int j = 1; j <= n; j++)
			res[j] = b[j];
	}
	return i;
}

main ()
{
	freopen ("A.in", "r", stdin);
	freopen ("A.out", "w", stdout);
	scanf ("%d%d%d", &n, &m, &k);
	for (i = 1; i <= n; i++)	
		scanf ("%d", &a[i]);
	for (i = 1; i <= m; i++)
		scanf ("%d", &x[i]);
	
	for (i = 0; i <= m; i++)
	{
		char s[1000];
		int v1 = 0;
		gets (s);
		for (j = 0; j < strlen (s); j++)
		{
			if (s[j] >= '0' && s[j] <= '9' && j < strlen (s))
			{
				while (s[j] >= '0' && s[j] <= '9')
				{
					v1 = v1 * 10 + s[j] - 48;
					j++;
				}
				v[i].push_back(v1);
				v1 = 0;
			}
		}
	}
	i = go(n, 0);
	while (i > 0)
	{
		i = go(n, 0);
	}
	for (i = 1; i <= n; i++)
		if (res[i])
			printf ("%d ", i);
}
