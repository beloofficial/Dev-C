#include<iostream>
#include<fstream>
#include<cstdio>
#include<vector>
#include<map>
#include<string>
using namespace std;
#define pb push_back
int main (){  
  
  freopen("C.in","r",stdin);
  freopen("C.out","w",stdout);
    cout<<"0 0 0";
   return 0;
  }