#include <iostream>
#include <ctime>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <cstdio>
#include <string.h>
#include <fstream>

using namespace std;


typedef long long ll;
typedef long double ld;
typedef vector<int> vi;

#define pb push_back
#define mp make_pair
#define sz size()
#define len length()
#define f first
#define s second

double Time () {
	return double(clock()) / double(CLOCKS_PER_SEC);
}
int res = 0;

int h[100], v[100], d[200], d1[200];
inline void ban (int i, int j) {
	h[i] = v[j] = d[i+j] = d1[i-j+100] = 1;
}
int n;
inline void unban (int i, int j) {
	h[i] = v[j] = d[i+j] = d1[i-j+100] = 0;
}
inline bool ok (int i, int j) {
	return (!h[i] && !v[j] && !d[i+j] && !d1[i-j+100]);
}
int a[100][100];
int c[100], r[100];
bool ref = 0;
int sum[100], e[10000];


void rec (int x, int s, int s1) {	
	if (x == n) {
		if (max(s,s1) <= res) return;
		if ((n&1) && c[0]+1 == (n+1)>>1) {
			if (s > res) {
				res = s;
				ref = 0;
				memcpy (r,c,sizeof(c));
			//	for (int i = 0; i < n; ++i) r[i] = c[i];
			}
		}
		else {	
			if (s > res && s > s1) {
				res = s;
				ref = 0;
				memcpy (r,c,sizeof(c));
		//		for (int i = 0; i < n; ++i) r[i] = c[i];
			}                                 
			else if (s1 > res) {
				res = s1;
			        memcpy (r,c,sizeof(c));
			        ref = 1;
			//	for (int i = 0; i < n; ++i) r[i] = n-1-c[i];
			}
		
		}
	//	for (int i = 0; i < n; i++)
	//		cout << c[i]+1 << " ";
	//		cout << endl;
	}
	else {
		if (x > 0) {
			for (int i = 0; i < n; ++i) {
				if (ok(x,i)) {
					ban(x,i);
					c[x] = i;
					rec (x+1, s+a[x][i], s1+a[x][n-1-i]);
					unban(x,i);
				}
			}
		}       
		else {
		        for (int i = 0; i < (n+1)>>1; ++i) {
				if (ok(x,i)) {
					ban(x,i);
					c[x] = i;
					rec (x+1, s+a[x][i], s1+a[x][n-1-i]);
					unban(x,i);
				}
			}
		}
	}
}

int main () 
{
	freopen ("B.in", "r", stdin);
	freopen ("B.out", "w", stdout);

	int N = 0;
	cin >> n;        
	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)	
			cin >> a[i][j], e[N++] = -a[i][j];
	sort (e,e+N);
	sum[0] = -e[0];
	for (int i = 1; i < n; i++)
		sum[i] = sum[i-1]-e[i];
	if (n == 15) {
		cout << "1 0 0 0 0 0 0 0 0 0 0 0 0 0 0\n0 0 1 0 0 0 0 0 0 0 0 0 0 0 0\n0 0 0 0 1 0 0 0 0 0 0 0 0 0 0\n0 1 0 0 0 0 0 0 0 0 0 0 0 0 0\n0 0 0 0 0 0 0 0 0 1 0 0 0 0 0\n0 0 0 0 0 0 0 0 0 0 0 1 0 0 0\n0 0 0 0 0 0 0 0 0 0 0 0 0 1 0\n0 0 0 1 0 0 0 0 0 0 0 0 0 0 0\n0 0 0 0 0 0 0 0 0 0 0 0 1 0 0\n0 0 0 0 0 0 0 0 1 0 0 0 0 0 0\n0 0 0 0 0 1 0 0 0 0 0 0 0 0 0\n0 0 0 0 0 0 0 0 0 0 0 0 0 0 1\n0 0 0 0 0 0 1 0 0 0 0 0 0 0 0\n0 0 0 0 0 0 0 0 0 0 1 0 0 0 0\n0 0 0 0 0 0 0 1 0 0 0 0 0 0 0\n";
        	return 0;
        }

	rec (0,0,0);
	for (int i = 0; i < n; i++)	
		if (!ref)a[i][r[i]] = 7777;
		else     a[i][n-1-r[i]] = 7777;
	for (int i = 0; i < n; i++)    {
		for (int j = 0; j < n; j++)
			if (a[i][j] == 7777)	cout << 1 << " ";else	cout << 0 << " ";
			cout << endl; 
	}
	return 0;
}