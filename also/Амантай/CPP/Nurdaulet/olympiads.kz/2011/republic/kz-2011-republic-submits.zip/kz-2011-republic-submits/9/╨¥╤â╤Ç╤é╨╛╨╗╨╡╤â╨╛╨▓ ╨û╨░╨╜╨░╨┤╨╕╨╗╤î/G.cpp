#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>

using namespace std;

#define pb push_back
#define fi first
#define se second

int main(){
	freopen ("G.in", "r", stdin);
	freopen ("G.out", "w", stdout);
	int f, p;
	cin >> f >> p;
	long long res = 1ll;
	for (int i = 2;i <= f;i++)
		res = (long long)(res * (long long)i) % p;
	cout << res;
}
