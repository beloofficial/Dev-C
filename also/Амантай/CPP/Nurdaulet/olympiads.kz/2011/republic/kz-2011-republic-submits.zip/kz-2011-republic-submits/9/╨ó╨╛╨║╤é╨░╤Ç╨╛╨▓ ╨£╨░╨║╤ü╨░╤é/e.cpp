//#include<brain.h>
#include<algorithm>
#include<iostream>
#include<utility>
#include<cstdlib>
#include<cstring>
#include<string>
#include<vector>
#include<cstdio>
#include<cmath>
#include<new>
#include<map>
#include<set>
using namespace std;
const int inf = 2147483647;
#define max(a,b) ((a<b)?(b):(a))
#define min(a,b) ((a<b)?(a):(b))
#define abs(a) ((a<0)?(-(a)):a)
#define pb push_back
#define mp make_pair
#define F first
#define S second
#define N (int) 1e6
int i,a,b,c,l,r,p;
long long sum;
int main () {
	freopen("E.in","r",stdin);
	freopen("E.out","w",stdout);
	scanf("%d%d%d%d%d%d",&a,&b,&c,&l,&r,&p);
	for (i = l; i<=r; i++) {
		if (i == a || i == b|| i == c) continue;
		else {
			sum = ((1ll*(sum % p) + (((1ll*((i-a)%p) * (i-b))%p) * (i-c)*1ll)%p)%p);
		}
	}
	cout<<sum;               

 return 0;
}