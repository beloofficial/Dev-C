#include<iostream>
#include<fstream>

using namespace std;

int a, b, c, l, r, p, i, rr = 0;

main(){

	ios_base::sync_with_stdio(0);

	ifstream in("e.in");
	ofstream out("e.out");	

	in >> a >> b >> c >> l >> r >> p;

	for(i = l; i <= r; ++i)
		rr = (((((((i - a) % p) * ((i - b) % p)) % p) * ((i - c) % p)) % p) + rr) % p;	

	out << rr;
}