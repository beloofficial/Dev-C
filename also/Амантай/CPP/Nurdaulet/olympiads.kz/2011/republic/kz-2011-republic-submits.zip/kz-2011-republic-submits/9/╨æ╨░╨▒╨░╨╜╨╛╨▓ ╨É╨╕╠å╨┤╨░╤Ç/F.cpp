#include<fstream>
#include<vector>
#include<algorithm>
using namespace std;
vector<vector<int> >v,t;
vector<int>ttt;
ifstream in("F.in");
	ofstream out("F.out");
int coun;
bool qwe=false;
bool check(int n){
for(int i=0;i<=ttt.size();i++){
              if(n==ttt[i])return false;
}
return true;
}
void find(int x,int y,bool&yy){	
	if(x==y){yy=true;return;}
          for(int i=0;i<v[x].size();i++){
		ttt.push_back(v[x][i]);
		v[x].erase(v[x].begin()+i);
		if(check(v[x][i])==false)continue;
		else find(v[x][i],y,qwe);
	       
	if(qwe==true)yy=true;
}
if(yy==true)coun++;
}                               
int main(){
	
         int n,m;
	in>>n>>m;
	v.resize(n+1);
	int a[1000][10];
	for(int i=0;i<=m;i++){
	for(int j=0;j<=3;j++){
	a[i][j]=0;
}
}

	for(int i=1;i<=m;i++){
	in>>a[i][1]>>a[i][2];
	a[i][3]=1;
	v[a[i][1]].push_back(a[i][2]);
	v[a[i][2]].push_back(a[i][1]);
}       
	int h;
	in>>h;
	char c;
        int x,y;
	int k;
	//  t=v;

	for(int i=0;i<h;i++){
	      in>>c>>x>>y;
	if(c=='+')a[y][3]=x;
	if(c=='q'){
	in>>k;
	//coun=0;
	//v=t;
	out<<n<<endl;
//	ttt.erase(ttt.begin(),ttt.end());
//find(x,y,qwe);
//		out<<coun<<endl;

}
	

}
/*
for(int i=1;i<=n;i++){
for(int j=0;j<v[i].size();j++){
out<<v[i][j]<<" ";
}                 out<<endl;
}
*/          
	
 
return 0; }