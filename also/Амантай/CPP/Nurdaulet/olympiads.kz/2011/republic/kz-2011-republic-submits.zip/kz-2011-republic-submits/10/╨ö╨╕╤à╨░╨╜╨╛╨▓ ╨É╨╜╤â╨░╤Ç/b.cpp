#include <cstdio>
#include <iostream>
#include <algorithm>
using namespace std;
#define N 1000                                        
int n, i, j, k, l, x[N], y[N], h[N], v[N], dl[N], dr[N], a[N][N], xx[N], yy[N];
int b[N][N], maxi = -1;
void go(int i = 1, int k = 0, int l = 0)
{
	if (l == n)
	{
		if (k > maxi)
		{
			maxi = k;
			for (int i = 0; i < l; i++)
			{
				x[i] = xx[i];
				y[i] = yy[i];
			}
		}
		return;
	}	

	for (; i <= n; i++)
	{
		for (int j = 1; j <= n; j++)
		{
			if (!h[j] && !v[i] && !dr[i + j - 1] && !dl[n - i + j])
			{
				v[i] = 1;
				h[j] = 1;
				dr[i + j - 1] = 1;
 		        dl[n - i + j] = 1;
 				xx[l] = i;
				yy[l] = j;
				go(i + 1, k + a[i][j], l + 1);
				v[i] = 0;
				h[j] = 0;
				dr[i + j - 1] = 0;
				dl[n - i + j] = 0;
			}
		}
	}
}

void go1 (int xx, int yy, int s)
{
	int p[N], q[N];
	for (int l = 0; l < n; l++)
	{
		p[l] = xx;
		q[l] = yy;
		s += a[xx][yy];
		v[yy] = 1;
		xx++;
		yy += 2;
		  
		if (n & 1)
		{
			if (yy > n)	
			yy %= n;
			if (yy == 0)
				yy = n;
		}
		else
 		{	
			if (yy > n)
				yy %= n,
				yy++;
		}
		
	}
	if (s > maxi)
	{
		maxi = s;
		for (int i = 0; i < n; i++)
			x[i] = p[i], y[i] = q[i];
	}
}
main ()
{
	freopen ("B.in", "r", stdin);
	freopen ("B.out", "w", stdout);
	scanf ("%d", &n);
	for (i = 1; i <= n; i++)
	{
		for (j = 1; j <= n; j++)
		{
			scanf ("%d", &a[i][j]);			
		}
	}
	if (n <= 10)
	{
		go();
		for (i = 0; i < n; i++)
			b[x[i]][y[i]] = 1;		
	}
	else
	{
		for (i = 1; i <= n; i++)
				go1 (1, i, 0);
		for (i = 0; i < n; i++)
			b[x[i]][y[i]] = 1;
	}
	for (i = 1; i <= n; i++)
	{
		for (j = 1; j <= n; j++)
		{
			printf ("%d ", b[i][j]);
		}
		printf ("\n");
	}
}
