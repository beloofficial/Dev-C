//Solution by Mukai Yersin
#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <ctime>
#include <cmath>
#include <map>
#include <set>

#define sz 2000000
#define nsz 2000
#define fname "A."
#define maxint (1<<30)

using namespace std;
struct st 
{
  	int flag[sz];
} ;
string asd[nsz];
char  s[nsz];
int  l,r,j,i,n,m,f[sz],w[sz],k,b[nsz][nsz],maxx,id,t[nsz];

void rec(int v)
{
	if (v>n)
		{
//			for (int i=1;i<=n;i++)
//				printf("%d ",t[i]);
			l++;
//			cout<<" - "<<l<<endl;
			int sum=0,ves=0;
			for (int i=1;i<=m;i++)
				{
					int o=0;
					for (int j=1;j<=b[i][0];j++)
						if (!t[b[i][j]]) 
							{
								o=1;
								break;
							}	
					if (!o)
						{
							sum+=f[i];
							ves+=w[i];
						}	
				}
		    	if (sum>maxx&&ves<=k)
		 		{
		 		 	maxx=sum;
		 		 	id=l;
		 		}
		}
		else
  			for (int i=0;i<2;i++)
  				{
  					t[v]=i;
  				 	rec(v+1);
  				}	
}

int main()
{
	freopen(fname"in","r",stdin);
	freopen(fname"out","w",stdout);
		scanf("%d %d %d",&n,&m,&k);
		for (i=1;i<=n;i++)
			scanf("%d ",&w[i]);
		for (i=1;i<=m;i++)
			scanf("%d ",&f[i]);
		for (i=1;i<=m;i++)
			{
			 	gets(s);
			 	l=strlen(s);
			 	r=1;asd[1]="";
			 	for (j=0;j<l;j++)
			 		if (s[j]==' ') r++,asd[r]=""; 
			 		else
			 		asd[r]=asd[r]+s[j];
			 	for (j=1;j<=r;j++)
			 		b[i][j]=atoi(asd[j].c_str());//,cout<<b[i][j]<<' ';
		//	 	cout<<endl;
			 	b[i][0]=r;
			}
		l=-1;
	  	rec(1);
	  	for (i=n-1;i>=0;i--)
	  		if ((id&(1<<i))&&1)
	  			printf("%d ",n-i);
	return 0;
}
