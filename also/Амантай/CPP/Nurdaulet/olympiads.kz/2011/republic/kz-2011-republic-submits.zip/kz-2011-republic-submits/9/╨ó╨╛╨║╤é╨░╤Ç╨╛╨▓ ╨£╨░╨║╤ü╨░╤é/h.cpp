//#include<brain.h>
#include<algorithm>
#include<iostream>
#include<utility>
#include<cstdlib>
#include<cstring>
#include<string>
#include<vector>
#include<cstdio>
#include<cmath>
#include<new>
#include<map>
#include<set>
using namespace std;
typedef long long ll;
const int inf = 2147483647;
#define max(a,b) ((a<b)?(b):(a))
#define min(a,b) ((a<b)?(a):(b))
#define abs(a)   ((a<0)?(-a) :a)
#define pb push_back
#define mp make_pair
#define F first
#define S second
#define N (int) 1e4
int a[N][N],n,m,i,j;
ll d[N][N],s;
int main () {
	freopen("H.in","r",stdin);
	freopen("H.out","w",stdout);
	scanf("%d%d\n",&n,&m);
	for (i = 1; i <= n; i++) {
		d[i][0] = inf;
		d[i][m+1] = inf;
		for (j = 1; j <= m; j++) {
			scanf("%d",&a[i][j]);
			d[i][j] = inf;
		}
	}
	for (i = 1; i<=m; i++) {
		d[0][i] = inf;
		d[n+1][i] = inf;
	}
	scanf("\n");   
	cin>>s;
	d[1][1] = 0;
	for (i = 1; i <= n; i++) {
		for (j = 1; j <= m; j++) {
			if (i == 1 && j == 1) continue;
			d[i][j] = a[i][j] + min(d[i-1][j],d[i][j-1]);
		}                                             
		for (j = m-1; j > 0; j--) {
			if (i == 1 && j == 1) continue;
			if (d[i][j] > (d[i][j+1]+a[i][j])) d[i][j] = d[i][j+1]+a[i][j];
		}
	}
	cout<<s-d[n][m];                             
 return 0;
}