#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <ctime>

using namespace std;

char s[2000];
#define base 1000000000

int n, m;
long long a[300][300];

struct bigi
{
	int a[10];
	int n, it, i, carry;
	bigi () {n = 1; a[0] = 0;}
   void operator = (const bigi &b)
   {
    	n = b.n;
    	for (i = 0; i < n; i++)
    		a[i] = b.a[i];
   }
   void operator += (const bigi &b)
   {
   	it = max (b.n, n);
   	for (i = 0, carry = 0; i < it || carry; i++)
   	{
   	 	if (i == n) a[n++] = 0;
   	 	a[i] += carry;
   	 	if (i < b.n) a[i] += b.a[i];
   	 	carry = a[i] >= base;
   	 	if (carry) a[i] -= base;
   	}
   }
	void read ()
	{
		n = 0;
		scanf ("%s", s);
		for (i = strlen (s); i>0; i-=9)
		{
			s[i] = 0;
			a[n++] = atoi (s+max (0, i-9));
		}
   }
   void write ()
   {
    	printf ("%d", a[n-1]);
    	for (i = n-2; i >= 0; i--)
    		printf ("%09d", a[i]);
   }
} c[203][203];

struct big
{
	int a[500];
	int c[500];
	int n, it, i, carry, j;
	long long cur, tmp, car;
	big () {n = 1; a[0] = 0;}
	void read ()
	{
		n = 0;
		scanf ("%s", s);
		for (i = strlen (s); i>0; i-=9)
		{
			s[i] = 0;
			a[n++] = atoi (s+max (0, i-9));
		}
   }
   void write ()
   {
    	printf ("%d", a[n-1]);
    	for (i = n-2; i >= 0; i--)
    		printf ("%09d", a[i]);
   }
   void operator = (const big &b)
   {
    	n = b.n;
    	for (i = 0; i < n; i++)
    		a[i] = b.a[i];
   }
   void operator += (const long long &v)
   {
   	for (i = 0, car = v; car; i++)
   	{
   	 	if (i == n) a[n++] = 0;
   	 	cur = a[i]+car;
   	 	a[i] = cur%base;
   	 	car = cur/base;
   	}
   }
   void operator -= (const big &b)
   {
		it = max (b.n, n);
		for (i = 0, carry = 0; i < it || carry; i++)
		{
			if (i == n) a[n++] = 0;
			a[i] -= carry;
			if (i < b.n) a[i] -= b.a[i];
			carry = a[i] < 0;
			if (carry) a[i] += base;
		}
		for (; n > 1 && a[n-1] == 0; n--);
   }
   bool operator < (const big &b)
	{
		if (b.n != n) return n < b.n;
		for (i = n-1; i >= 0; i--)
			if (a[i] < b.a[i]) return 1;
			else if (a[i] > b.a[i]) return 0;
		return 1;
   }
   void operator *= (const bigi &b)
   {
		for (i = 0; i < b.n+n+1; i++)
			c[i] = 0;
		for (i = 0; i < n; i++)
			for (j = 0, carry = 0; j < b.n || carry; j++)
			{
				if (j < b.n) tmp = a[i]*1ll*b.a[j];
				else tmp = 0;
				cur = c[i+j] + carry + tmp;
//				printf ("here cur=%I64d\n", cur);
				c[i+j] = cur%base;
				carry = cur/base;
			}
		n = b.n+n+1;
//		printf ("here n = %d\n", n);
		for (i = 0; i < n; i++)
			a[i] = c[i];
//		for (i = 0; i < n; i++)
//			printf ("%d", a[i]);
//		puts ("");
		for (; n > 1 && a[n-1] == 0; n--);
   }
} dp[500], x, source;

int main ()
{
	freopen ("H.in", "r", stdin);
	freopen ("H.out", "w", stdout);

	scanf ("%d%d", &n, &m);

	for (int i = 0; i < max (n, m); i++)
		for (int j = 0; j <= i; j++)
			if (!j)
				c[i][j].n = 1,
				c[i][j].a[0] = 1;
			else
				c[i][j] += c[i-1][j-1],
				c[i][j] += c[i-1][j];

	for (int i = 0; i <= max (n, m); i++)
		for (int j = i+1; j <= max (n, m); j++)
			c[i][j] = c[j][i];

	for (int i = 0; i < n; i++)
		for (int j = 0; j < m; j++)
			scanf ("%I64d", &a[i][j]);

	dp[0].n = 1;
	dp[0].a[0] = 0;

	for (int j = 1; j < m; j++)
	{
		dp[j] = dp[j-1];
		dp[j] *= c[0][j];
		dp[j] += a[0][j];
	}

	int iter = 10;

	if (n + m >= 100)
		iter = 3;

	for (int i = 0; i < n-1; i++)
	{
		for (int j = 0; j < m; j++)
		{
			dp[j] *= c[i+1][j];
			dp[j] += a[i+1][j];
		}


		for (int it = 0; it < iter; it++)
			for (int j = 0; j < m; j++)
			{
				if (j && (j == m-1 || dp[j-1] < dp[j+1]))
				{
					x = dp[j-1];
					x *= c[i+1][j];
					x += a[i+1][j];
					if (x < dp[j])
						dp[j] = x;
				}
				else
				if (j != m-1)
				{
					x = dp[j+1];
					x *= c[i+1][j];
					x += a[i+1][j];
					if (x < dp[j])
						dp[j] = x;
				}
			}
//		for (int j = 0; j < m; j++)
//		{
//		 	dp[j].write ();
//		 	printf (" ");
//		}
//		puts ("");
	}
//		for (int j = 0; j < m; j++)
//		{
//		 	dp[j].write ();
//		 	printf (" ");
//		}
//		puts ("");
//	dp[m-1].write ();

	source.read ();

	if (source < dp[m-1])
	{
		printf ("-");
	 	dp[m-1] -= source;
	 	dp[m-1].write ();
	}
	else
		source -= dp[m-1],
		source.write ();
	puts ("");

	return 0;
}
