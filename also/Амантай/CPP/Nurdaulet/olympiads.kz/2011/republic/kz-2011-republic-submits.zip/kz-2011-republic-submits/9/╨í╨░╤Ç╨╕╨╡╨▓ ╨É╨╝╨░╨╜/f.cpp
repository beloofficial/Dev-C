#include<iostream>
#include<fstream>
#include<vector>
#include<cstdio>
#include<cstdlib>
using namespace std;
vector<int> g[100005];
int n,a[100005],b[100005],p[100005],h[100005],l[100005];
void dfs(int v)
{
for(int i=0;i<g[v].size();i++)
{
if(h[g[v][i]]==0)
{
h[g[v][i]]=h[v]+1;
p[g[v][i]]=v;
dfs(g[v][i]);
}
}
}
int main()
{
freopen("F.in","r",stdin);
freopen("F.out","w",stdout);
ios_base::sync_with_stdio(0);
int m,i,j,k,x,y,z,t;
char c;
cin>>n>>m;
for(i=1;i<=n;i++)
{
p[i]=h[i]=l[i]=0;
}
for(i=1;i<=m;i++)
{
cin>>a[i]>>b[i];
g[a[i]].push_back(b[i]);
g[b[i]].push_back(a[i]);
}
h[1]=1;
dfs(1);
cin>>k;
for(i=1;i<=k;i++)
{
cin>>c;
if(c=='+')
{
cin>>t>>z;
x=a[z];
y=b[z];
t--;
if(x==p[y]) l[y]=t;
else l[x]=t;
}
else
{
t=0;
cin>>x>>y>>z;
z--;
while(x!=y)
{
if(h[x]>h[y])
{
t+=(l[x]==z);
x=p[x];
}
else
{
t+=(l[y]==z);
y=p[y];
}
}
cout<<t<<endl;
}
}
return 0;
}