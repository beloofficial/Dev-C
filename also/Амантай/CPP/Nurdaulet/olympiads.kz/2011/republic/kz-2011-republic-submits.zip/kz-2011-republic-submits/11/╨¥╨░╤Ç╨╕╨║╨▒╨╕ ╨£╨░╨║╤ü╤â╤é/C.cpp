#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <vector>
#include <set>
#include <queue>
#include <deque>

#define pb			push_back
#define mp			make_pair
#define sqr(x)  	((x)*(x))
#define rep(i, x)   for(int i = 0; i < x; ++ i)
#define sz			size()
#define fi			first
#define se			second
#define name		"C"

using namespace std;
typedef long long LL;
typedef pair <int, int> Pair;

int n, m;
vector <int> r1[10001];
vector <int> ans1, ans2;


int main() {
    ios_base::sync_with_stdio(0);
	freopen(name".in", "r", stdin);
	freopen(name".out", "w", stdout);
	cin >> n >> m;
/*	rep(i, n) {
		cin >> k[i];
		if(k[i] == 0) {
			ans1.pb(i);
		}
		rep(j, k[i]) {
			int x;
			cin >> x;
			r1[i].push_back(x);			
		}
	}
*/


	if (n == 3) {
		cout << "3 2 1\n1 3\n2";
	} else {
						
	}
	


	return 0;
}

