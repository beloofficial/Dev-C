#include <iostream>
#include <cmath>
#include <algorithm>
#include <cstdio>
#include <vector>
#include <cstring>
          
using namespace std;

int n,m,k,buf;
int ves[26];
int magic[26];
vector<int> v[26];
long long total=0,totalmagic=0;
bool a[26]={0},aa[26]={0};
string s;
bool kaka;

void rec(int z){
	if (z==n+1){
		if (total<=k){
        	long long tt=0;
        	
        	for (int f=1; f<=m; f++){
        		kaka=1;
        		for (int y=0; y<=v[f].size()-1; y++){
        			if(!a[v[f][y]])
        				kaka=0;
        		}
        		if (kaka){
        			tt+=magic[f];
        		}
        	}
        	if (tt>totalmagic){
        		totalmagic=tt;
        		for (int uu=1; uu<=n; uu++)
        			aa[uu]=a[uu];
        	}
		}
	} else {
    	a[z]=1;
        total+=ves[z];
        rec(z+1);
        a[z]=0;
        total-=ves[z];
        rec(z+1);
	}
}


int main(){

	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);

	cin>>n>>m>>k;

	for (int j=1; j<=n; j++)
		cin>>ves[j];
	
	for (int j=1; j<=m; j++)
		cin>>magic[j];
	
	getline(cin,s);
	for (int i=1; i<=m; i++){
		getline(cin,s);
		buf=0;
		for (int x=0; x<=s.length(); x++){
			if (isdigit(s[x])){
				buf*=10;
				buf+=s[x]-'0';
			} else {
				v[i].push_back(buf);
				buf=0;
			}
		}
	}

	rec(1);

	for (int i=1; i<=n; i++)
		if (aa[i])
			cout<<i<<" ";

	return 0;

}
