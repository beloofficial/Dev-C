#include<iostream>
#include<fstream>
using namespace std;
int a[15][15],b[15],c[15],n,bs=0;
void draw()
{
int i,j;
for(i=1;i<=n;i++)
{
for(j=1;j<=n;j++)
{
cout<<(i==c[j]?1:0)<<" ";
}
cout<<endl;
}
}
void check()
{
int i,t=0;
for(i=1;i<=n;i++)
{
t+=a[b[i]][i];
}
if(t>bs)
{
bs=t;
for(i=1;i<=n;i++) c[i]=b[i];
}
}
void rec(int x)
{
if(x>n)
{
check();
return;
}
int i,j;
for(i=1;i<=n;i++)
{
b[x]=i;
for(j=1;j<x;j++)
{
if(b[j]==b[x] || b[j]+j==b[x]+x || b[j]-j==b[x]-x) break;
}
if(x==j) rec(x+1);
}
}
int main()
{
freopen("B.in","r",stdin);
freopen("B.out","w",stdout);
cin>>n;
int i,j;
for(i=1;i<=n;i++)
{
c[i]=0;
for(j=1;j<=n;j++)
{
cin>>a[i][j];
}
}
rec(1);
draw();
return 0;
}