// O, velikiy System Judge!
// Posshadi menya! Plzplzplzplzplz
#include <cstdio>

#define int long long
#define i64 "%I64d"
int A, B, C, L, R, P, sum, a[10];

struct T{
	int a[10][10];
	T(){
		for (int i = 0; i < 10; i++)
			for (int j = 0; j < 10; j++)
				a[i][j] = 0;
	}
	void operator *= (T &b){
		T c;
		for (int i = 0; i < 9; i++)
			for (int j = 0; j < 9; j++)
				for (int k = 0; k < 9; k++)
					c.a[i][j] = (c.a[i][j] + ((a[i][k] * b.a[k][j]) % P)) % P;
		for (int i = 0; i < 9; i++)
			for (int j = 0; j < 9; j++)
				a[i][j] = c.a[i][j];
	}
}m;

T power (T a, int n){
	T res = a;
	for (n--; n; n >>= 1){
		if (n & 1)
			res *= a;
		a *= a;
	}
	return res;
}                                

main ()
{
	freopen ("E.in", "r", stdin);
	freopen ("E.out", "w", stdout);

	scanf(i64 i64 i64 i64 i64 i64, &A, &B, &C, &L, &R, &P);
	for (int i = 0; i < 9; i++)
		m.a[i][i] = m.a[8][i] = m.a[i][0] = 1;
	for (int i = 1; i < 9; i++)
		m.a[i][1] = 1;
	m.a[5][2] = m.a[5][3] = m.a[6][2] = m.a[6][4] = m.a[7][3] = m.a[7][4] = 1;
	A = L - A;
	B = L - B;
	C = L - C;
	a[0] = a[1] = (((A * B) % P) * C) % P;
	a[2] = (A * B) % P;
	a[3] = (A * C) % P;
	a[4] = (B * C) % P;
	a[5] = A;
	a[6] = B;
	a[7] = C;
	a[8] = 1;
//	for (int i = 0; i < 9; i++)
//		printf("%d ", a[i]);
	m = power(m, R - L);	
//	for (int i = 0; i < 9; i++)
//		for (int j = 0; j < 9; j++)
//			printf("%d%c", m.a[i][j], j == 8 ? '\n' : ' ');
	for (int i = 0; i < 9; i++)
		sum = ( sum + ((a[i] * m.a[i][0]) % P) ) % P;
	printf(i64, sum % P);
}

