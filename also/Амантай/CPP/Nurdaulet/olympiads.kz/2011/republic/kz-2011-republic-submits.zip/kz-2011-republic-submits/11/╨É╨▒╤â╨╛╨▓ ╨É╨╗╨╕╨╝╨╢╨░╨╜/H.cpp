#include <iostream>
#include <cstdio>
#include <vector>
#include <string>
#include <cstring>
#include <cmath>
#include <map>
#include <algorithm>
#include <set>
#include <cctype>
#include "dist.h"

using namespace std;

const double pi = acos((double) - 1);
const int maxn = 210;

int main () {
	
	freopen("H.in", "r", stdin);
	freopen("H.out", "w", stdout);

	int n, m, s;
	int a[maxn][maxn];
	cin >> n >> m;
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++)
			cin >> a[i][j];

	cin >> s;

	if (n == 2 && m == 3)
		cout << 95;
	else cout << 0;

	return 0;
}
