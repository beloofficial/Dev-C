//Solution by Mukai Yersin
#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <dist.h>
#include <ctime>
#include <cmath>
#include <map>
#include <set>

#define sz 2000000
#define inf 10000000
#define nsz 2000
#define eps 0.0001
#define fname "G."
#define sqr(w) ((w)*(w))
#define maxint (1<<30)

using namespace std;
struct st
{
 	double l;
 	int id;
 	bool operator < (const st &p) const
 		{
 		 	return l<p.l;
 		}
} a[12];

int X,Y,x[12],y[12],k,minn,t,i,r,doo,tx[sz][6],ty[sz][6];
set<pair<int,int> > se;
double b[12];
/*
// Alip tasta
void start()
{

}

double dist(int x,int  y)
{
 	return sqrt(1ll*(x-X)*(x-X)+1ll*(y-Y)*(y-Y));
}

void finish(int x,int y)
{
	if (x==X&&y==Y)
		printf("1");
	  	else
		printf("0");
    	exit(0);
}
//end
*/
long double S(int a,int b,int c)
{
 	double p=(a+b+c)*0.5;
 	return (sqrt(1ll*p*(p-a)*1ll*(p-b)*1ll*(p-c)));
}

double len(int i,int  j)
{
 	return sqrt(1ll*(x[i]-x[j])*(x[i]-x[j])+1ll*(y[i]-y[j])*(y[i]-y[j]));
}
                        	
int ishinde()
{
 	if (((S(len(1,2),b[1],b[2])+S(len(2,4),b[2],b[4])+S(len(3,4),b[3],b[4])+S(len(1,3),b[1],b[3]))-S(len(1,2),len(1,3),len(2,3))-S(len(2,3),len(2,4),len(3,4)))<=eps)
 		return 1;
 		else
 		return 0;						
}

int main()
{
	freopen(fname"in","r",stdin);
	freopen(fname"out","w",stdout);
	  	scanf("%d %d",&X,&Y);
//	 	srand(time(0));
	  //	X=rand()%10000000;
	  //	Y=rand()%10000000;
	  //	cout<<X<<' '<<Y<<endl;
	  	start();
	  	x[1]=-inf;y[1]=inf;
	  	x[2]=inf;y[2]=inf;
	  	x[3]=-inf;y[3]=-inf;
	  	x[4]=inf;y[4]=-inf;
	  	r=0;
	  	while (1)
	  		{    	
	  			
	  			doo=se.size();
	  			r++;
	  			for (i=1;i<=4;i++)
	  				{
	  					se.insert(make_pair<int,int>(x[i],y[i]));
	  					tx[r][i]=x[i];
	  					ty[r][i]=y[i];
	  				}
	  			if (doo==se.size())
	  				{
	  	//				cout<<"asd"<<endl;
	  				 	if ((tx[r-1][3]==x[1]&&tx[r-1][2]==x[4]&&ty[r-1][3]==y[1]&&ty[r-1][2]==y[4])||((tx[r-1][1]==x[3]&&tx[r-1][4]==x[2]&&ty[r-1][1]==y[3]&&ty[r-1][4]==y[2])))
	  				 		{
	  				 		 		y[i]+=3;
	  				 		}
	  				 		else
	  				    	if ((tx[r-1][2]==x[1]&&tx[r-1][4]==x[3]&&ty[r-1][2]==y[1]&&ty[r-1][4]==y[3])||((tx[r-1][1]==x[2]&&tx[r-1][3]==x[4]&&ty[r-1][1]==y[2]&&ty[r-1][3]==y[4])))
	  				 		{
	  				 		 	for (i=1;i<=4;i++)
	  				 		 		x[i]+=3;
	  				 		}
	  				}
	  				
	  	//		printf("---\n");
	  	//		for (i=1;i<=4;i++)
	  	//			printf("%d %d\n",x[i],y[i]);
	  			minn=inf;
	  			for (i=1;i<=4;i++)
	  				{
	  					a[i].l=dist(x[i],y[i]);
	  					a[i].id=i;
	  					b[i]=a[i].l;
	  	//				cout<<b[i]<<' ';
	  			 	}
	  	//		 	cout<<endl;
	  			sort(a+1,a+5);
	  			k=a[1].id;
	  			t=a[2].id;
	  			if (a[1].l==0)
	  				 finish(x[a[1].id],y[a[1].id]);
	  			if (ishinde())
	  				{
	  				//	cout<<"Yes";
	  				    	for (i=1;i<=4;i++)
	  				    		{
	  				    			x[i]=x[i]/2+x[i]%2;
	  				    			y[i]=y[i]/2+y[i]%2;
	  				    		}	
	  				}
	  				else
	  		    	if ((k==1&&t==3)||(k==3&&t==1))
	  		    		{
	  		    		 	x[2]=2*x[1]-x[2];
	  		    		 	swap(x[2],x[1]);
	  		    		 	swap(y[2],y[1]);			

	  		    		 	x[4]=2*x[3]-x[4];
	  		    		 	swap(x[4],x[3]);
	  		    		 	swap(y[4],y[3]);
	  		    		}
	  		    		else
	  		   	if ((k==2&&t==1)||(k==1&&t==2))
	  		   	     {
	  		   	         y[3]=2*y[1]-y[3];
	  		   	         swap(x[3],x[1]);
	  		   	         swap(y[3],y[1]);

	  		   	         y[4]=2*y[2]-y[4];
	  		   	         swap(x[4],x[2]);
	  		   	         swap(y[4],y[2]);
	  		   	     }
	  		   	     else
	  		  	if ((k==2&&t==4)||(k==4&&t==2))
	  		  		{
	  		  		   	x[1]=2*x[2]-x[1];
	  		  		   	swap(x[1],x[2]);
	  		  		   	swap(y[1],y[2]);

	  		  		   	x[3]=2*x[4]-x[3];
	  		  		   	swap(x[3],x[4]);
	  		  		   	swap(y[3],y[4]);
	  		  		}
	  		  		else
	  		  		{
	  		  		  	y[1]=2*y[3]-y[1];
	  		  		  	swap(x[1],x[3]);
	  		  		  	swap(y[1],y[3]);  	

	  		  		  	y[2]=2*y[4]-y[2];
	  		  		  	swap(x[2],x[4]);
	  		  		  	swap(y[2],y[4]);
	  		  		}
	  		}
	return 0;
}
