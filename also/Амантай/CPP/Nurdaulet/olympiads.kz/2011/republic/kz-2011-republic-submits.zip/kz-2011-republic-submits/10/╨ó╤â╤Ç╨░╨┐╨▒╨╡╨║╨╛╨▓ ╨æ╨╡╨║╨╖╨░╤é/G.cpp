#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstdlib>
#include<vector>
#include<utility>
#include<queue>
#include<ctime>
#include<list>
#include<set>
#include<map>
#include<cmath>
#include "dist.h"

using namespace std;

#define tr(Con,it) for(typeof(Con.begin()) it=Con.begin();it!=Con.end();it++)
#define pb push_back
#define mp make_pair

typedef int ll;

ll zero =-(1e7);
ll maxn =(1e7);  

ll n,m,l,r,m1,m2,ans,ansX,ansY,resX,resY;

//void start(){	ansX=5703; ansY=85499;}

//double dist(ll x,ll y){	return sqrt(1LL*(1LL*x-1LL*ansX)*1LL*(1LL*x-ansX)+(1LL*y-ansY)*1LL*(1LL*y-1LL*ansY));}

//void finish(ll x,ll y){printf("%d %d",x,y);}

double f(ll x){ return dist(x,zero);}
double g(ll y){ return dist(zero,y);}


int main(){
//	freopen("input.txt","r",stdin);
//	freopen("output.txt","w",stdout);
	start();
     	l=zero; r=maxn; 
	while((r-l)>1000){
		m1=l+((r-l+1)/3); m2=r-((r-l+1)/3);

		if(f(int(m1))> f(int(m2))) l=m1; else             r=m2;                     		

	}
	resX=l;
		for(ll i=l;i<=r;i++)
			if(f(int(resX))>f(i)) resX=i;
	
//--------------------------------------------------
     	l=zero; r=maxn; 
	while((r-l)>1000){
		m1=l+((r-l+1)/3); m2=r-((r-l+1)/3);
		if(g(m1)> g(m2)) l=m1;		 else             r=m2;                     		
	}
	resY=l;
	for(ll i=l;i<=r;i++)
		if(g(resY)>g(i)) resY=i;

	
//	printf("%lf\n",dist(resX,resY));
	finish(resX,resY);

return 0;
}