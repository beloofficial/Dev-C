#include<iostream>
#include<fstream>
#include<string>
#include<cstdio>
#include<cmath>
#include<set>
#include<vector>
#include<utility>
#include<map>
#include<stack>
#include<queue>
using namespace std;
int main ()
 {
   freopen ("G.in","r",stdin);
   freopen ("G.out","w",stdout);
    long long  n,p;
     cin>>n>>p;
    long long s=1;
    for(int i=1;i<=n;i++)
      {
       s*=i;
       s%=p;
      }
   cout<<s;
  return 0;      
 }