// Solution by [A.S.]

#include <algorithm>
#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

int p[100], n, c[100][100], ms, answer, a[100][100], sum;

int main()
{
	freopen ("B.in", "r", stdin);
	freopen ("B.out", "w", stdout);

	cin >> n;

	answer = ms = 0;

	for (int i = 1; i <= n; i++)
		p[i] = n - i + 1;

	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= n; j++)
			cin >> c[i][j];

	do
	{
		bool ok = true;

		for (int i = 1; i <= n; i++)
		{
			for (int j = 1; j <= n; j++)
			{
				if (i != j && abs (i - j) == abs (p[i] - p[j]))
				{
					ok = false;
					goto skip;
				}
			}
		}

		skip:;

		if (ok)
		{
			sum = 0;
                                
			for (int i = 1; i <= n; i++)
				sum += c[p[i]][i];

			if (sum > ms)
			{
		                ms = sum;
				for (int i = 1; i <= n; i++)
					for (int j = 1; j <= n; j++)
						a[i][j] = false;

				for (int i = 1; i <= n; i++)
					a[p[i]][i] = true;
			}	
			/*for (int i = 1; i <= n; i++)
			{
				for (int j = 1; j <= n; j++)
				{
					cout << a[i][j] << " ";
					a[i][j] = 0; 
				}
				cout << endl;
			}

	        	cout << "\n-----------------------\n\n";	
                        */        
		}

	}while (prev_permutation (p + 1, p + n + 1));

	for (int i = 1; i <= n; i++)
	{
		for (int j = 1; j <= n; j++)
		{
			cout << a[i][j] << " ";
		}
		cout << "\n";
	}

       	return 0;
}
