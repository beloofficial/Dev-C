#include<iostream>
#include<fstream>
#include<map>
#include<cstdlib>
#include<string>
#include<vector>
#include<deque>
#include<set>
#include<cstdio>
#include<cmath>
#include<algorithm>

#define INF (1 << 30)
#define pb push_back
#define mp make_pair
#define ll long long
#define VI vector <int>
#define VVI vector < VI >
#define fi first
#define se second

using namespace std;

int main(){

	freopen("h.in", "r", stdin);
	freopen("h.out", "w", stdout);

	int n, m;

	ll s, q;

	cin >> n >> m >> q >> s;

	if(n == 2 && m == 3) cout << 95;
	else if(n == 1 && m == 1) cout << s - q;
	else cout << 0;	

	return 0;
}