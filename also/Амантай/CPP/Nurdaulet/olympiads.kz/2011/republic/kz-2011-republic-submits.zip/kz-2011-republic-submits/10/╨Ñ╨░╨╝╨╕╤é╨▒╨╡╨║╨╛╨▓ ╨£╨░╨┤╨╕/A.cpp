#include <iostream>
#include <ctime>
#include <vector>
#include <cstdlib>
#include <string.h>
#include <cstdio>
#include <fstream>

using namespace std;


typedef long long ll;
typedef long double ld;
typedef vector<int> vi;

#define pb push_back
#define mp make_pair
#define sz size()
#define len length()
#define f first
#define s second
//#define debug

double Time () {
	return double(clock()) / double(CLOCKS_PER_SEC);
}

int n, m, k;
int c[50], p[50];
ll d[34000000];
int res=0, res1 = 0;
int M[50];
vector <int> a[50];

void out (int x) {
	for (int i = 0; i < n; i++)
		if (x & 1<<i)cout << i+1 << " ";
}
void rec (int x, ll s, int mask = 0) {
	if (s > k) return;
	if (x == n) d[mask] = s;
	else {                         
		rec (x+1, s, mask&((1<<x)-1));
		rec (x+1, s+c[x], mask|(1<<x));
	}
}

void rec1 (int x, ll s, int mask = 0) {
        if (d[mask] > k) return;
	if (x == m) {
		if (d[mask] == 0) return;
		if (s > res) res = s, res1 = mask;
	}
	else {                         
		rec1 (x+1, s, mask);
		rec1 (x+1, s+p[x], mask|M[x]);
	}
}


int main () 
{
	freopen ("A.in", "r", stdin);
	freopen ("A.out", "w", stdout);
	char s[10000];	
	cin >> n >> m >> k;
	gets(s);

	int r;
	char ch;
	for (int i = 0; i < n; i++)	cin >> c[i];
	gets(s);
	for (int i = 0; i < m; i++)	cin >> p[i];
	gets(s);
	for (int i = 0; i < m; i++) {
		gets(s);
		r = 0;
		for (int j = 0; j < strlen(s); j++){
			if (s[j] >= '1' && s[j] <= '9') r = r*10+s[j]-'0';
			else{
				r--;
		                M[i] |= 1<<r;
				a[i].pb (r);
				r = 0;
			}
		}
		r--;
		M[i] |= 1<<r;
		a[i].pb (r);
	}
	#ifdef debug
	cout << "Magics \n";
	for (int i = 0; i < m; i++) {
		cout << "Power " << p[i] << endl;
		for (int j = 0; j < a[i].sz; j++)	cout << a[i][j] << " ";
		cout << endl;
	}
	#endif
	rec (0,0LL);
	rec1 (0,0LL);
	out(res1);

	return 0;
}