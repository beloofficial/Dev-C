//Solution by Balakshy Andrey 16.04.11

#include <cstdio>
#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>
#include <memory.h>

using namespace std;

#define pb push_back
#define mp make_pair
#define For(i, p1, p2, st) for (int i = (int)p1; i < (int)p2; i += (int)st)
#define FoR(i, p1, p2, st) for (int j = (int)p1; i > (int)p2; i -= (int)st)  

vector <int> osta, ostb;
int n, m, k, ch, pra[510], prb[510];

void print()
{
 printf("%d %d %d\n", osta.size() + ostb.size(), osta.size(), ostb.size());
  For(i, 0, osta.size(), 1) printf("%d ", osta[i]); printf("\n");
   For(i, 0, ostb.size(), 1) printf("%d ", ostb[i]);

}

int main()
{
  freopen("C.in", "r", stdin);
   freopen("C.out", "w", stdout); 

   
    cin >> n >> m;  memset(pra, 0, sizeof(pra));
	  	     memset(prb, 0, sizeof(prb));

    For(i, 0, n, 1) {
     scanf("%d", &k);
      For(j, 0, k, 1)
       scanf("%d", &ch), prb[ch - 1]++;          
    }

    For(i, 0, m, 1) {
     scanf("%d", &k);
      For(j, 0, k, 1)
       scanf("%d", &ch), pra[ch - 1]++;          
    }
        

    For(i, 0, max(m, n) + 1, 1) {
     if (prb[i] >= pra[i] && i < n && i < m && (pra[i] || prb[i])) 
      osta.pb(i + 1);
       else 
        if (pra[i] == prb[i] && !pra[i]){
         if (i < n) osta.pb(i + 1);
          if (i < m) ostb.pb(i + 1);
        }
       else
        if (pra[i] > prb[i]  && i < n && i < m)
         ostb.pb(i + 1);
    }
 

    print();

  return 0;
}
