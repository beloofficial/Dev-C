#include<iostream>
#include<fstream>
using namespace std;
int main()
{
freopen("G.in","r",stdin);
freopen("G.out","w",stdout);
long long i,n,p,k=1;
cin>>n>>p;
for(i=1;i<=n;i++)
{
k=(k*(i%p))%p;
}
cout<<k;
return 0;
}