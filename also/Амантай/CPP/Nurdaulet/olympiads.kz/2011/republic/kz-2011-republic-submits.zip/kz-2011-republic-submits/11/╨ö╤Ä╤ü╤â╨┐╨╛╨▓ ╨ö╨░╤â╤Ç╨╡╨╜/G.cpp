// Dyussupov Dauren 11 class Atyrau
#include<cstdio>
#include<iostream>
#include<cmath>
#include<cstdlib>
#include<cstring>
#include<set>
#include<map>
#include<vector>
#include<algorithm>
#include<ctime>
#include "dist.h"

using namespace std;

#define F first
#define S second
#define sf scanf
#define pf printf
#define eps 1e-18
#define inf 1000000000

int main()
{
	int x, y;
	int l = -inf, r = inf, m1, m2;
	
	while (r - l >= 3)
	{
		m1 = l + (r - l) / 3;
		m2 = r - (r - l) / 3;
		if (dist(m1, 0) < dist(m2, 0) || dist(m1, inf) < dist(m2, inf) || dist(m1, -inf) < dist(m2, -inf)) r = m2; else l = m1;
	}

	if (dist(l + 1, 0) < dist(l, 0) || dist(l + 1, inf) < dist(l, inf) || dist(l + 1, -inf) < dist(l, -inf)) l++;
	if (dist(r, 0) < dist(l, 0) || dist(r, inf) < dist(l, inf) || dist(r, -inf) < dist(l, -inf)) l = r;

	x = l;

	l = -inf, r = inf;

	while (r - l >= 3)
	{
		m1 = l + (r - l) / 3;
		m2 = r - (r - l) / 3;

		if (dist(0, m1) < dist(0, m2) || dist(inf, m1) < dist(inf, m2) || dist(-inf, m1) < dist(-inf, m2)) r = m2; else l = m1;
	}

	if (dist(0, l + 1) < dist(0, l) || dist(inf, l + 1) < dist(inf, l) || dist(-inf, l + 1) < dist(-inf, l)) l++;
	if (dist(0, r) < dist(0, l) || dist(inf, r) < dist(inf, l) || dist(-inf, r) < dist(-inf, l)) l = r;

	y = l;

	finish(x, y);

	return 0;
}