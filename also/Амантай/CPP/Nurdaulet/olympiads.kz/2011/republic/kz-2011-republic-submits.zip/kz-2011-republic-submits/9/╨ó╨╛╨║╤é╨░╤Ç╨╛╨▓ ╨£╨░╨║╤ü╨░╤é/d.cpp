#include<algorithm>
#include<iostream>
#include<utility>
#include<cstdlib>
#include<cstring>
#include<string>
#include<cstdio>
#include<vector>
#include<ctime>
#include<cmath>
#include<new>
#include<map>
using namespace std;
#define max(a,b) (a<b?b:a)
#define min(a,b) (a<b?a:b)
#define cl(a,b) memset(a,b,sizeof(a));
#define pb push_back
#define mp make_pair
#define F first
#define S second 
#define N (int) 1e5 + 100
int n,m,i,l,r,j,a[10000];
bool was[N];
struct way{

	int x,y;

}; way b[N];
bool cmp(way l, way r)
{
	return l.x < r.x;
}
int main () {
	freopen("D.in","r",stdin);
	freopen("D.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (i = 0; i < n; i++) {
		scanf("%d",&b[i].x);
		b[i].y  = i;
	}
	sort(b,b+n,cmp);
	a[b[0].y] = 1;
	int u = 1;
	for (i = 1; i < n; i++) {
		if (b[i].x!=b[i-1].x) u++;
		a[b[i].y] = u;
	}
	for (i = 0; i < m; i++) {
		scanf("%d%d",&l,&r);l--; r--;
		int ans = 0;
		for (j = l; j<=r; j++) {
			if (!was[a[j]]) ans++;
			was[a[j]] = true;
		}
		cl(was,0);
		printf("%d\n",ans);
	}

 return 0;
}
