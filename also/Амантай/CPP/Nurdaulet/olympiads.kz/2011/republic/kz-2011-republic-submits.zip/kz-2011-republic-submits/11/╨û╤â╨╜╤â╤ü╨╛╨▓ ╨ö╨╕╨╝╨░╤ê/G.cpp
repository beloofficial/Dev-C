#include <iostream>
#include <vector>
#include "dist.h"
#include <algorithm>
#include <cmath>
#include <string>
#include <cstring>
#include <set>
#include <map>
#include <stdio.h>

#define pb push_back
#define mp make_pair
#define se second
#define fi first
#define all(a) a.begin(),a.end()

using namespace std;

double xx,yy;
double x=0,y=0,x1=0,y11=1000000000,x2=1000000000,y2=0;
double m,ans=1000000000;
int t = 0,ansx,ansy;

int main() {
	
	start();

    for(int i = 0; i <= 2490; ++ i) {
    	if(dist(0,i) < ans) {
    		ans = dist(0,i);
    		ansy = i;
    	}
    	if(dist(0,1000000000-i) < ans) {
    		ans = dist(0,i);
    		ansy = i;
    	}
    }

    ans = 1000000000;

    for(int i = 0; i <= 2490; ++ i) {
    	if(dist(i,0) < ans) {
    		ans = dist(i,0);
    		ansx = i;
    	}
    	if(dist(1000000000-i,0) < ans) {
    		ans = dist(i,0);
    		ansx = i;
    	}
    }

    finish(ansx,ansy);
//	cout << "\n" << ansx << ' ' << ansy;

	return 0;
}

