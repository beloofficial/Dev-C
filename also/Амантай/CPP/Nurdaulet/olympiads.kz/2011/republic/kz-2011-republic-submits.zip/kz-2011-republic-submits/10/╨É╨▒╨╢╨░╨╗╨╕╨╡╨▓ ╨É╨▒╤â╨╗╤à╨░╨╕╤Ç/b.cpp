#include <algorithm>
#include <iostream>
#include <cstring>
#include <cassert>
#include <cstdlib>
#include <string>
#include <vector>
#include <cstdio>
#include <cmath>
#include <ctime>
#include <set>
#include <map>

#define inf (int)1e9
#define EPS 1e-6
#define file "B"

typedef long long ll;
typedef long double ld;

using namespace std;

struct positions {

	int x, y;

	positions() {

		x = y = -1;

	}

} p[20];

int n, r[20], d1[40], d2[40], a[20][20], res[20][20], max_sum;

void rec(int v) {

	if (v == n) {
		
		int sum = 0;

		for (int i = 0; i < n; ++i)
			sum += a[p[i].x][p[i].y];

		if (sum > max_sum) {

			max_sum = sum;

			for (int i = 0; i < n; ++i)
				for (int j = 0; j < n; ++j)
					res[i][j] = 0;

			for (int i = 0; i < n; ++i)
				res[p[i].x][p[i].y] = 1;

		}
		
	}

	for (int i = 0; i < n; ++i)
		if (!r[i] && !d1[n - (v - i) - 1] && !d2[(n - v - 1) + (n - i - 1)]) {

			r[i] = d1[n - (v - i) - 1] = d2[(n - v - 1) + (n - i - 1)] = true;
			p[v].x = v;
			p[v].y = i;
			rec(v + 1);						
			r[i] = d1[n - (v - i) - 1] = d2[(n - v - 1) + (n - i - 1)] = false;
			p[v].x = -1;
			p[v].y = -1;

		}     						

}

int main() {

	freopen(file".in", "r", stdin);
	freopen(file".out", "w", stdout);

	scanf("%d", &n);

	for (int i = 0; i < n; ++i)
		for (int j = 0; j < n; ++j)
			scanf("%d", &a[i][j]);

  	rec(0);

  	for (int i = 0; i < n; ++i) {

  		for (int j = 0; j < n; ++j)
  			printf("%d ", res[i][j]);

  		printf("\n");

  	}

	return 0;

}