//Solution by Mukai Yersin
#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <ctime>
#include <cmath>
#include <map>
#include <set>

#define sz 2000000
#define nsz 2000
#define fname "D."
#define sqr(w) ((w)*(w))
#define maxint (1<<30)

using namespace std;

set<int> p;
int l,r,a[sz],d[5001][5001],k,i,j,n,m;

int main()
{
	freopen(fname"in","r",stdin);
	freopen(fname"out","w",stdout);
		scanf("%d %d",&n,&m);
		for (i=1;i<=n;i++)
			scanf("%d",&a[i]);
		for (i=1;i<=n;i++)
			for (j=1;j<=n;j++)	
				{
					p.clear();
					for (k=i;k<=j;k++)
						p.insert(a[k]);
					d[i][j]=p.size();
				}	
		for (i=1;i<=m;i++)
			{
			 	scanf("%d %d",&l,&r);
			 	printf("%d\n",d[l][r]);
			}	
	return 0;
}
