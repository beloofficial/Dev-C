#include <iostream>
#include <string>
#include <cmath>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
using namespace std;
int main()
{
	const int nmax = 1000*1000;
	freopen ("E.in","r",stdin);
	freopen ("E.out","w",stdout);

	__int64  sum,sum2,a,b,c,l,p,r,n,m,k;

	int  z[1000100],x[1000100],y[1000100]; 

	cin>>a>>b>>c>>l>>r>>p;    			// cout<<a; return 0;
	n=l-a-1; m=l-b-1; k=l-c-1;

	sum =0;  sum2=0;
						//sum = (n*m*k)%p;		
	
	int len = 0;				//  z[len]=;  x[len]=m%p;  y[len]=k%p; 
		
							//sz = min(r,l+2*nmax);  
	int inval=-1; int i,j;

	for (i=l; i<=r; i++)
	{
		n++; m++; k++;
		if (n<0 || m<0 || k<0)  { sum = (sum+((n*m)%p*k))%p; continue; }
		len ++;   z[len]=n%p;  x[len]=m%p;  y[len]=k%p; inval++; 
		if (len>1) {
			
			if (z[len]==z[1] && x[len]==x[1] && y[len]==y[1]) break;	
			sum2 = (sum2+( (z[len]*x[len])%p * y[len] )) % p;		

		}  else sum2 = (sum2+( (z[len]*x[len])%p * y[len] )) % p;		
		 
		//sum = (sum+((n*m)%p*k))%p;			
	}

	sum = (sum+sum2)%p;

	for (j=i; j<=r; j+=inval)  sum = (sum+sum2)%p;
	n=z[1]; m=x[1]; k=y[1];
	        
	for (i=j; i<=r; i++) {   sum = (sum+((n*m)%p*k))%p;  n++; m++; k++; }


	cout<<sum;




	return 0;
}