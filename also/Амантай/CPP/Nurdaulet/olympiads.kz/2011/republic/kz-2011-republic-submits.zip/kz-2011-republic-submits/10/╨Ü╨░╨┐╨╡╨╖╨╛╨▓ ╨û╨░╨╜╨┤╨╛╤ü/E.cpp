//������� ������ 
//������
#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#include<cmath>
#include<vector>
#include<string>
#include<string.h>
#include<utility>
#include<algorithm>

using namespace std;

#define sz size()
#define mp make_pair
#define pb push_back
#define sqr(x) ((x)*(x))

int a, b, c, l, r, p;
long long x, y, z, res = 0, pp, sum;

int main()
{
	freopen("E.in", "rt", stdin);
	freopen("E.out", "wt", stdout);
		scanf("%d%d%d%d%d%d", &a, &b, &c, &l, &r, &p);
		x = l - a;	y = l - b;	z = l - c;
		pp = x + y + 1; a = (x * y);

		for (int i = l; i <= r; i++)
		{			
			res = res + (a * z);
			res %= p;
			//while (res >= p)	res -= p;			
			a = a + pp;
			while (a >= p)	a -= p;
			x++; y++; z++;
			pp = x + y + 1;

            /*
			if (x >= p)	x -= p;
			if (z >= p)	z -= p;
			if (y >= p)	y -= p;
            */
		}
		cout<<res;
	return 0;
}
