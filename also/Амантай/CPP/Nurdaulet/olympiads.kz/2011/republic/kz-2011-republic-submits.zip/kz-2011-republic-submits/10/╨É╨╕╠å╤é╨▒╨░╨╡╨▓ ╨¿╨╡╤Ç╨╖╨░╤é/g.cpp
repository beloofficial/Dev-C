#include<iostream>
#include<fstream>
#include<map>
#include<cstdlib>
#include<string>
#include<vector>
#include<deque>
#include<set>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include "dist.h"

#define pb push_back
#define mp make_pair
#define VI vector <int>
#define VVI vector < VI >
#define fi first
#define se second

using namespace std;

int x, y, inf = (1000 * 1000 * 1000);

int ternaryx(){
	int l = -inf, r = inf, ll, rr;

	while(l < r){
		ll = (r - l) / 3 + l;
		rr = ll + ((r - l) / 3);

//		cout << l << " " << r << " " << ll << " " << rr << endl;

		if((double)dist(ll, 0) < (double)dist(rr, 0)) r = rr - 1;
		else l = ll + 1;
	}

	int q = l;

	for(int i = max(-inf, l - 5); i <= min(inf, l + 5); ++i)
		if((double)dist(i - 1, 0) > (double)dist(i, 0) && (double)dist(i + 1, 0) > (double)dist(i, 0))
			q = i;

	return q;
}

int ternaryy(){
	int l = -inf, r = inf, ll, rr;

	while(l < r){
		ll = (r - l) / 3 + l;
		rr = ll + ((r - l) / 3);

		if((double)dist(x, ll) < (double)dist(x, rr)) r = rr - 1;
		else l = ll + 1;
	}

	int q = l;

	for(int i = max(-inf, l - 5); i <= min(inf, l + 5); ++i)
		if((double)dist(x, i - 1) > (double)dist(x, i) && (double)dist(x, i + 1) > (double)dist(x, i))
			q = i;

	return q;
}


int main(){

	start();

	x = ternaryx();

	y = ternaryy();

	finish(x, y);

//	cout << x << " " << y << endl;

	return 0;
}