//Zhienbek Shyngys 9 Astana KTL
#include<iostream>
#include<utility>
#include<map>
#include<cmath>
#include<math.h>
#include<stdio.h>
#include<stdlib.h>
#include<algorithm>
#include<cstdio>
#include<cstdlib>
#include<fstream>
#include<string>
#include<string.h>
#include<sstream>
#include<limits>
#include<assert.h>
#define eps 1e-12
#define mp(x,y) make_pair(x,y)
#define inf numeric_limits<int> :: max()
#define For(i,a,b) for(int i=a;i<=b;i++)
#define FOR(i,a,b) for(int i=a;i>=b;i--)
using namespace std;

int n,ne[10001],he[10001],s[10001],m,c=0;
bool u1[10001],u2[10001];

int main()
{
 #ifndef ONLINE_JUDGE
  freopen("C.in","rt",stdin);
  freopen("C.out","wt",stdout);
 #endif
  
  scanf("%d%d",&n,&m);
  int c1=0,c2=0;
  For(i,1,n)
   {
    int x;
    scanf("%d",&x);
    For(j,1,x) 
     {
      c++;
      int y;
      scanf("%d",&y);
      s[c]=y+n;
      ne[c]=he[i];
      he[i]=c;
      s[c+n+m]=i;
      ne[c+n+m]=he[y];
      he[y]=c+n+m;
     }
   }
  For(i,1,m)
   {
    int x;
    scanf("%d",&x);
    For(j,1,x)
     {
      c++;
      int y;
      scanf("%d",&y);
      s[c]=y;
      ne[c]=he[i+n];
      he[i+n]=c;
      s[c+n+m]=i+n;
      ne[c+n+m]=he[y];
      he[y]=c+n+m;
     }
   }  
  For(i,1,n)
  for(int j=he[i];j!=0;j=ne[j]) u1[s[j]]=1;
  For(i,n+1,m+n)
  for(int j=he[i];j!=0;j=ne[j]) u2[s[j]]=1;
  For(i,1,n) if (!u2[i]) c2++;
  For(i,n+1,n+m) if (!u1[i]) c1++;
  int k1=n+c1;
  int k2=m+c2;
  if (k1>=k2)
   {
    printf("%d %d %d\n",c1+n,n,c1);
    For(i,1,n) printf("%d ",i);
    printf("\n");
    For(i,n+1,n+m)
    if (!u1[i]) printf("%d ",i-n);
   } else
   {
    printf("%d %d %d\n",c2+m,m,c2);
    For(i,1,n) 
    if (!u2[i]) printf("%d ",i);
    printf("\n");
    For(i,1,m) printf("%d ",i-n);
   }

 fclose(stdin);fclose(stdout);
 return 0;
}
