#include <iostream>
#include <string>
#include <cmath>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
using namespace std;
int main()
{
	freopen ("H.in","r",stdin);
	freopen ("H.out","w",stdout);
	int  n,m,i,j,k,l;

	
	return 0;
}