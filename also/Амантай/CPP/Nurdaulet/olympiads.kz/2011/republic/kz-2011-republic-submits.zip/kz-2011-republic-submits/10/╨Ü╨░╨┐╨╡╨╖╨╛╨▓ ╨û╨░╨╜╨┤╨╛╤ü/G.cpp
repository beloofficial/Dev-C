//������� ������ 
//������
#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#include<cmath>
#include<vector>
#include<string>
#include<string.h>
#include<utility>
#include<algorithm>
#include "dist.h"
using namespace std;

#define sz size()
#define mp make_pair
#define pb push_back
#define sqr(x) ((x)*(x))
const double INF = (1<<30) * 1.0;
int dx[9] = {0, 1, 2,  1,  0, -1, -2, 0};
int dy[9] = {2, 1, 0, -1, -2, -1,  0, 0};
int x, y, X, Y;
double r, mind;
double a[4];

int main()     
{
	start();
	x = 0; y = 0;
	r = dist(x, y);
	if (r - double(int(r)) > 0.0)
		r = (int(r) + 1) * 1.0;
	while (r > 2.0)
	{
		a[0] = dist(x - r, y);
		a[1] = dist(x, y + r); 
		a[2] = dist(x + r, y);
		a[3] = dist(x, y - r);
			mind = INF;
        if (a[0] < mind)
        {
        	mind = a[0];
        	x -= r;
        }
        if (a[1] < mind)
        {
        	mind = a[1];
        	y += r;
        }
        if (a[2] < mind)
        {
        	mind = a[2];
        	x += r;
        }
        if (a[3] < mind)
        {
        	mind = a[3];
        	y -= r;
        }
		r = dist(x, y);
		if (r - double(int(r)) > 0.0)
			r = (int(r) + 1) * 1.0;
	}
	
	for(int i = 0; i < 9; i++)
	{
		X = x + dx[i];
		Y = y + dy[i];
		mind = dist(X, Y);
		if (mind == 0.0)
			break;		
	}
	finish(X, Y);
	return 0;
}
