#include <set>
#include <map>
#include <vector>
#include <cstdio>
#include <cstdlib>
#include <string.h>
#include <iostream>
#include <algorithm>
using namespace std;

#define sz(a) (a).size()
#define pb push_back
#define mp make_pair

int a[100001], b[100001], n, m, l, r, d, i;

int main()
{
	freopen("D.in", "r", stdin);
	freopen("D.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for (i = 1; i <= n; i++)
		scanf("%d", a + i);
	while (m--)
	{
		scanf("%d%d", &l, &r);
		for (i = l; i <= r; i++)
			b[i-l] = a[i];
		sort(b,b+r-l+1);
		d = 1;
		for (i = 1; i <= r-l; i++)
			if (b[i] != b[i-1]) d++;
		printf("%d\n", d);
	}
	return 0;
}
