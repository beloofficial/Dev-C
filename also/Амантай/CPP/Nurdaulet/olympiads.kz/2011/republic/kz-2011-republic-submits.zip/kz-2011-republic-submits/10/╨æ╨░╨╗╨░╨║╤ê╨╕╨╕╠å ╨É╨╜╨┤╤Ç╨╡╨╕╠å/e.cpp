//Solution by Balakshy Andrey 17.04.11

#include <cstdio>
#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>

using namespace std;

#define pb push_back
#define mp make_pair
#define For(i, p1, p2, st) for (int i = (int)p1; i < (int)p2; i += (int)st)
#define FoR(i, p1, p2, st) for (int j = (int)p1; i > (int)p2; i -= (int)st)  


typedef long long LL;

LL a, b, c, l, r, mod, res = 0;
 

int main()
{
  freopen("E.in", "r", stdin);
   freopen("E.out", "w", stdout); 

    cin >> a >> b >> c >> l >> r >> mod;

       for (LL ch = l; ch <= r; ch++)
        res += (ch - a) * (ch - b) * (ch - c);;


    printf("%I64d", res % mod);

  return 0;
}
