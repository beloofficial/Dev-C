#include<iostream>
#include<fstream>
#include<map>
#include<cstdlib>
#include<string>
#include<vector>
#include<deque>
#include<set>
#include<cstdio>
#include<cmath>
#include<algorithm>

#define INF (1 << 30)
#define pb push_back
#define mp make_pair
#define VI vector <int>
#define VVI vector < VI >
#define fi first
#define se second

using namespace std;

int a[100010], n, m, q, w, b[5000][5000], r = 0;

map <int, int> mm;

int main(){

	freopen("d.in", "r", stdin);
	freopen("d.out", "w", stdout);
	
	cin >> n >> m;

	for(int i = 0; i < n; ++i) 
		scanf("%d", &a[i]);

	for(int i = 0; i < m; ++i){
		scanf("%d %d", &q, &w);
		--q, --w;
		r = 0;
		mm.clear();
		if(q < 5000 && w < 5000 && b[q][w]) { printf("%d\n", b[q][w]); continue;}		
		for(int j = q; j <= w; ++j){
			if(!mm[a[j]]) r++, mm[a[j]] = 1;
		}
		if(q < 5000 && w < 5000) b[q][w] = r;
		printf("%d\n", r);
	}

	return 0;
}