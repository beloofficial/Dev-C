#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstdlib>
#include<utility>
#include<vector>
#include<queue>
#include<ctime>
#include<list>
#include<set>
#include<map>

using namespace std;

int n,m,k,x;
vector<int> G[510],G_[510];
bool used[510],used_[510];

int main(){
	freopen("C.in","r",stdin);
	freopen("C.out","w",stdout);
	scanf("%d %d\n",&n,&m);
	for(int i=1;i<=n;i++){
		scanf("%d",&k);
		for(int j=1;j<=k;j++){
			scanf("%d",&x);
			G[i].push_back(x);
		}
	}

	for(int i=1;i<=m;i++){
		scanf("%d",&k);
		for(int j=1;j<=k;j++){
			scanf("%d",&x);
			G_[i].push_back(x);
		}
	}
	int ans1,ans2;
	if(n>=m){ ans1=n;ans2=0;}
	else   { ans1=0;ans2=m;  }
	
	printf("%d %d %d\n",max(n,m),ans1,ans2);
	for(int i=1;i<=ans1;i++)
		printf("%d ",i); printf("\n");
	
	for(int i=1;i<=ans2;i++)
		printf("%d ",i); printf("\n");
	
return 0;
}