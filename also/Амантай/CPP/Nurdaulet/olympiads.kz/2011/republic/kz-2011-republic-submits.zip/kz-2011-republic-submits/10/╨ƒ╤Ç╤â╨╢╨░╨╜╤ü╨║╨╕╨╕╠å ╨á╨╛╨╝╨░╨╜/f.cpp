#include <cstdio>
#include <iostream>
#include <vector>

using namespace std;

int street[100010];

struct st2{
	int to;
	int l;
} temp;

struct st1 {
 	int k;
 	int used;
} perk[100010];

vector <st2> per[100010];

vector <int> v;

int bfs(int x, int y, int z, int k){
	v.push_back(x);
	perk[x].k = 0;
	perk[x].used = k;

	int curr, next;
	while (true) {
	 	curr = v[0];
        
	 	v.erase(v.begin());

		for(int i = 0; i<per[curr].size(); i++){
			next = per[curr][i].to;
			if (next != y){
				if (perk[next].used != k){
					perk[next].used = k;
					v.push_back(next);
					if (street[per[curr][i].l] == z){
					    perk[next].k = perk[curr].k + 1;
					} else {
						perk[next].k = perk[curr].k;
					}
				}
			} else {
				if (street[per[curr][i].l] == z){
				    return perk[curr].k + 1;
				} else {
					return perk[curr].k;
				}	
			}
		}	
	}
}

int main() {

    freopen("f.in", "r", stdin);
    freopen("f.out", "w", stdout);

    char ch;

    int n, m, k;
    int a, b;
    int x, y, z;

    cin >> n >> m;

    for(int i = 1; i<=100001; i++){
     	perk[i].k = 0;
     	perk[i].used = 0;
    }

    for(int i = 1; i<=m; i++){
    	temp.l = i;
		cin >> a >> b;
		street[i] = 1;
		temp.to = a;
		per[b].push_back(temp);
		temp.to = b;
		per[a].push_back(temp);
	}

	cin >> k;

	for (int i = 1; i<=k; i++){
		cin >> ch;
		if (ch == 'q'){
			cin >> x >> y >> z;
			cout << bfs(x, y, z, i) << endl;
		} else {
		 	cin >> x >> y;
		 	street[y] = x;
		}
	}

   	fclose(stdout);

    return 0;
}
