#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <string.h>
#include <math.h>
#include <numeric>
#include <map>
#include <time.h>
using namespace std;
int n, m, a[100001];
map <int, bool> mp;
int main () {
	freopen ("D.in", "r", stdin);
	freopen ("D.out", "w", stdout);
	scanf ("%d%d", &n, &m);
	for (int i = 1; i <= n; i++) 
		scanf ("%d", &a[i]);
	for (int i = 1; i <= m; i++) {
		int lx, l, r, ans = 0;
		scanf ("%d%d", &l, &r);
		lx = l;
		for (l; l <= r; l++)
			if (!mp[a[l]]) {
				mp[a[l]] = 1;
				ans++;
			}
		for (lx; lx <= r; lx++)
				mp[a[lx]] = 0;
		printf ("%d\n", ans);
	}
	return 0;
} 