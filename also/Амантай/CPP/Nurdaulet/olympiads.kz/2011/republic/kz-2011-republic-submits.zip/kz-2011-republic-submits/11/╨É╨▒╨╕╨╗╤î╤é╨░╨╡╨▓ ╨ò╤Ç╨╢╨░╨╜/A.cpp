#include <iostream>
#include <string>
#include <cstdlib>
#include <cstdio>
using namespace std;

int a[50],b[50],c[30][30],sz[30],maxi=0,n,m,k;  bool f[30],r[30];  

void print()
{
int l,sum=0;
for (int i=1; i<=m; i++)
{
	l=0;
	for (int j=1; j<=sz[i]; j++)
	{
	if (f[c[i][j]]) l++;
	}
	if (l==sz[i]) sum+=b[i];
}
if (sum > maxi) 
{
	for (int i=1; i<=n; i++) r[i]=f[i]; maxi=sum;
}
}
void  rec(int p, int s)
{
	if (p>n) {
		print();
		return;
	}
	if (s-a[p]>=0)
	{
	f[p]=true;
	rec(p+1,s-a[p]); f[p]=false;
	}
	f[p]=false; rec(p+1,s);


}

int main()
{
	freopen ("A.in","r",stdin);
	freopen ("A.out","w",stdout);
string str;
cin>>n>>m>>k;
for (int i=1; i<=n; i++) cin>>a[i];
for (int i=1; i<=m; i++) cin>>b[i];  getline(cin,str);
for (int g=1; g<=m; g++)
{
getline(cin,str); int i,j=0; 
i=str.length()-1; 
while (i>=0)
{
	int l=0,p=1;
	while (str[i]!=' ') 
	{
		l+=((int)str[i]-48)*p; p=p*10;		
		i--;  if (i<0) break;


	}
	i--;
	j++; c[g][j]=l;
}	
sz[g] = j;
}
rec(1,k); 
for  (int i=1; i<=n; i++) if (r[i]) cout<<i<<" ";
	return 0;
}