#include <cstdio>
#include <iostream>

using namespace std;

#define LL long long
#define mod (LL)1e12

LL n, p;

int main() {
	freopen("G.in", "r", stdin);
	freopen("G.out", "w", stdout);

	scanf("%I64d %I64d", &n, &p);
	LL res = 1;
	for (int i = n; i >= 2; i--) {
		res = (res * i) % mod;
		if (res == 0) {
		    puts("0");
			return 0;
		}
	}
	printf("%I64d", res % p);

	return 0;
}