#include <iostream>
#include <dist.h>
#include <cstdio>
using namespace std;
int main()
{
	int x=0, y=0;
	start();
	bool bo = false;
	for (int x = -50; x<=50; x++)
	{
	if (bo) break;
		for (int y = -50; y<=50; y++)
			{
				if (dist(x, y) == 0)
				{
					bo = true;
					break;
				}
			}
	}
	finish(x, y);	
	return 0;
}