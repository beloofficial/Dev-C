//Mukhamejanov Azamat 2011y
#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <ctime>
#include <map>
#include <set>
using namespace std;
#define fname1 "H."
#define fname2 ""
#define inf 1<<30
#define eps 1e-5

int a[10001],n,m;
char s[10010];
int main (){
	freopen (fname1"in"fname2,"r",stdin);
	freopen (fname1"out"fname2,"w",stdout);

	scanf ("%d %d",&n,&m);
	for (int i=1;i<=n;++i)
		for (int j=1;j<=m;++j){
			scanf ("%s",s);
		}

	scanf ("%s",s);
	if (n==2&&m==3)printf ("95");else
		printf ("%s\n",s);

	return 0;
}
