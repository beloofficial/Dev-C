#include <iostream>
#include <cstdio>
#include <vector>
#include <string>
#include <cstring>
#include <cmath>
#include <map>
#include <algorithm>
#include <set>

using namespace std;

const double pi = acos((double) - 1);
const int maxn = 17;

int n, s = 0, ss;
int a[maxn][maxn];
bool d1[maxn * 2], d2[maxn * 2], dx[maxn], arr[maxn][maxn];
int ans[maxn], cur[maxn]; 

void p(int j) {
	if (j > n) {
		ss = 0;
		for (int i = 1; i <= n; i++)
			ss += a[cur[i]][i];
		if (ss > s) {
			s = ss;
			for (int i = 1; i <= n; i++)
				ans[i] = cur[i];
		}
	} else {
		for (int i = 1; i <= n; i++) {
			if (!dx[i] && !d1[n + j - i] && !d2[i + j - 1]) {
				dx[i] = d1[n + j - i] = d2[i + j - 1] = 1;

				cur[j] = i;
				p(j + 1);

				dx[i] = d1[n + j - i] = d2[i + j - 1] = 0;
			}
		}
	}
}

int main() {
	
	freopen("B.in", "r", stdin);
	freopen("B.out", "w", stdout);

	cin >> n;
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= n; j++) {
			cin >> a[i][j];
			arr[i][j] = 0;
		}
		dx[i] = 0;
	}
	for (int i = 1; i < maxn * 2; i++)
		d1[i] = d2[i] = 0;

	p(1);

	for (int i = 1; i <= n; i++)
		arr[ans[i]][i] = 1;

	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= n; j++) {
			cout << arr[i][j] << ' ';
		}
		cout << endl;
	}

	return 0;
}
