#include<algorithm>
#include<cstdio>
#include<iostream>
using namespace std;
int main () {
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	printf("2 3"); 
 return 0;
}