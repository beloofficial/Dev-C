#include<iostream>
#include<fstream>
#include<map>
#include<cstdlib>
#include<cstring>
#include<vector>
#include<deque>
#include<set>
#include<cstdio>
#include<cmath>
#include<algorithm>

#define INF (1 << 30)
#define pb push_back
#define mp make_pair
#define VI vector <int>
#define VVI vector < VI >
#define fi first
#define se second

using namespace std;

int i, j, n, m, k, a[30], b[30], bsz[30], nn[30][30], q[30], rsz = 0, r[30], mx = -1, ss;

bool bb;

char cc[100];

void rec(int p, int s){
	if(p == n){
		for(i = 0; i < m; ++i){
			bb = 0;
			ss = 0;
			for(j = 0; j < bsz[i]; ++j){
				if(!q[nn[i][j]]){
					bb = 1;
					break;
				}
				ss += b[nn[i][j]];
			}

			if(!bb && ss > mx){
				mx = ss;
				rsz = 0;
				for(j = 0; j < n; ++j)
					if(q[j])
						r[rsz++] = j;
			}
		}
		return;
	}
	else{
		if(s + a[p] <= k){
			q[p] = 1;
			rec(p + 1, s + a[p]);
		}
		q[p] = 0;
		rec(p + 1, s);
	}
}

int main(){

	freopen("a.in", "r", stdin);
	freopen("a.out", "w", stdout);		

	cin >> n >> m >> k;

	for(i = 0; i < n; ++i) 
		scanf("%d", &a[i]);

	for(i = 0; i < m; ++i)
		scanf("%d", &b[i]);

	gets(cc);

	for(i = 0; i < m; ++i){
		gets(cc);
		for(j = 0; j < strlen(cc); ++j){
			if(cc[j] == ' ') { --nn[i][bsz[i]], ++bsz[i]; continue; }
			nn[i][bsz[i]] = (nn[i][bsz[i]] * 10) + int(cc[j] - '0');
		}
		--nn[i][bsz[i]];
		++bsz[i];
	}

	rec(0, 0);

	if(!rsz) cout << 1;

        for(i = 0; i < rsz; ++i)
        	cout << r[i] + 1 << " ";
	
	return 0;
}