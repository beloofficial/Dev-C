#include <cstdio>
#include <iostream>
#include <algorithm>
using namespace std;
#define dd "%I64d"
__int64 n, m, a, b, c, x, l, r, ans, i, p;
main ()
{
	freopen ("E.in", "r", stdin);
	freopen ("E.out", "w", stdout);
	scanf (dd dd dd dd dd dd, &a, &b, &c , &l, &r, &p);
	
	for (i = l; i <= r; i++)
	{
		__int64 d = (i - a) * (i - b) * (i - c);
		x = ((i - a) * (i - b) % p) * (i - c) % p;
		ans = (ans + x) % p;
	}
	printf (dd, ans % p);
}
