        //������� ������ 
//������
#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#include<cmath>
#include<vector>
#include<string>
#include<string.h>
#include<utility>
#include<algorithm>
using namespace std;

#define sz size()
#define mp make_pair
#define pb push_back
#define sqr(x) ((x)*(x))

bool u[200000];
int a[200000], p[200000];
int n, m, l, r, res;

int main()
{
	freopen("D.in", "rt", stdin);
	freopen("D.out", "wt", stdout);
		scanf("%d%d", &n, &m);
		for (int i = 0; i < n; i++)
			scanf("%d", &p[i]), a[i] = p[i];
		sort(p, p + n);
		for (int i = 0; i < n; i++)
			a[i] = lower_bound(p, p + n, a[i]) - p;
		
		for (int i = 0; i < m; i++)
		{
			res = 0;
			memset(u, 0, sizeof(u));
			scanf("%d%d", &l, &r);
			for (int j = l - 1; j < r; j++)
				if (!u[a[j]])
				{
					res++;
					u[a[j]] = 1;
				}
			printf("%d\n", res);
		}
	return 0;
}
