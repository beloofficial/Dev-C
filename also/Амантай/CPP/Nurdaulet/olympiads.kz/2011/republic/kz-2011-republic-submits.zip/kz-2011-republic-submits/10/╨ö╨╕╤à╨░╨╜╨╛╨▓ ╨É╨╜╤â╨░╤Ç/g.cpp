#include <cstdio>
#include <iostream>
#include <math.h>
#include <algorithm>
#include <dist.h>

using namespace std;

#define inf 1000000000
double x, y, ansx, ansy;
double eps = 1e-6;

void start();
double dist(double x, double y);
void finish(double x, double y);

void start()
{
	printf ("%lf %lf\n", ansx, ansy);
	double xl = -inf, xr = inf, yl = -inf, yr = inf;
	while (xr - xl > eps)
	{
		double ll, rr;
		ll = (xr - xl) / 3 + xl;
		rr = (xr - xl) / 3 + ll;
	    printf ("%lf %lf\n%lf %lf\n", xl, xr, ll, rr);
		if (dist(ll, 0) < dist(rr, 0))
			xr = rr;
		else xl = ll;
	}
	while (yr - yl > eps)
	{
		double ll, rr;
		ll = (yr - yl) / 3 + yl;
		rr = (yr - yl) / 3 + ll;
		if (dist(xl, ll) < dist(xl, rr))
			yr = rr;
		else yl = ll;
	}
	finish(floor(xr), floor(yr));
}
	
main ()
{
	start();
}
