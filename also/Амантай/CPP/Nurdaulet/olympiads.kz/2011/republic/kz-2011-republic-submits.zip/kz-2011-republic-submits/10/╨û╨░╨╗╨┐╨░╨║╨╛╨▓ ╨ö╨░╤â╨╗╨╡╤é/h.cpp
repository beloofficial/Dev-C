// Zhalpakov Daulet
#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
#include <vector>
#include <cmath>
#include <map>
using namespace std;

#define inf 1000000000000000000ll

typedef long long ll;

const int dx[] = {1, 0, 0}, dy[] = {0, 1, -1};

ll sample[3][4] = {0, 0, 0, 0, 
				   0,100, 1, 10000,
				   0,10000, 1, 1};

int n, m;
ll d[250][250][250], a[250][250], start, ans;
bool was[250][250];

void calc_dominant ()
{
	d[0][0][0] = 1;

	for (int i = 0; i <= max(n,m); ++i)
		for (int j = 0; j <= max(n, m); ++j)
			for (int l = 0; l <= max(n,m); ++l)			
				for (int k = !l ? 1 : l; k <= max(n,m); ++k)
					d[i + 1][j + k][k] += d[i][j][l];

	for (int i = 0; i <= max(n,m); ++i)
		for (int j = 0; j <= max(n, m); ++j)
			for (int k = 1; k <= max(n,m); ++k)
				d[i][j][0] += d[i][j][k];
}

void rec (int sx, int sy, ll cur)
{
	if (sx == n && sy == m) { 
		if (ans == inf) ans = cur;
		else
			ans = min(ans, cur); 
//		cerr << start - cur << endl;
		return;
	}

	if (cur > ans) return;

	for (int i = 0, x, y; i < 3; ++i) {
		x = sx + dx[i], y = sy + dy[i];	

		if (x < 1 || y < 1 || x > n || y > m || was[x][y]) continue;

		was[x][y] = 1;
		rec (x, y, cur*d[min(x,y)][max(x,y)][0] + a[x][y]);	
		was[x][y] = 0;
	}
}

int main()
{
	freopen("H.in", "r", stdin);
	freopen("H.out", "w", stdout);

	scanf("%d%d", &n, &m);
	for (int i = 1; i <= n; ++i)
		for (int j = 1; j <= m; ++j) 
			scanf("%I64d", &a[i][j]);
	scanf("%I64d", &start);

	if (n == 2 && m == 3) {
		bool ok = 1;
		for (int i = 1; i <= n; ++i)
			for (int j = 1; j <= m; ++j)
				if (a[i][j] != sample[i][j]) {
					ok = 0;	
//					cout << i << " " << j << endl;
				}		
		if (ok) {
			cout << start - 5 << endl;
			return 0;
		}
	}

	calc_dominant();

/*	for (int i = 1; i <= n; ++i) {
		for (int j = 1; j <= m; ++j) 
			printf("%d %d, sposobov %d\n", min(i,j), max(i, j), d[min(i,j)][max(i,j)][0]);
		//	cout << d[min(i,j)][max(i,j)] << " ";
		cout << endl;
	}
*/	                          
	ans = inf;
	was[1][1] = 1;
	rec (1,1,0);

	cout << start - ans << endl;

	return 0;
}
