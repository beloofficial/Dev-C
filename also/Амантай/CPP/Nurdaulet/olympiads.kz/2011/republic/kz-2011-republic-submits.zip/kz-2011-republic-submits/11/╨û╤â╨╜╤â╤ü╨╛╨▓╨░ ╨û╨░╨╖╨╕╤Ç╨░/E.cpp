#include<iostream>
#include<algorithm>
#include<cstdio>
#include<string>
#include<cstring>
#include<cmath>
#include<vector>
#include<stack>
#include<queue>
#include<map>
#include<set>

#define mp make_pair
#define pb push_back
#define fi first
#define se second

using namespace std;

long long s=0,a,b,c,p,l,r;

int main()
{
	freopen("E.in","r",stdin);
	freopen("E.out","w",stdout);

	cin>>a>>b>>c>>l>>r>>p;

	while(l<=r)
	{	
		s=(s+((l-a)%p)*((l-b)%p)*((l-c)%p))%p;
		l++;
	}

	cout<<s;

	return 0;
}