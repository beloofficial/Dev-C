// Dyussupov Dauren 11 class Atyrau
#include<cstdio>
#include<iostream>
#include<cmath>
#include<cstdlib>
#include<cstring>
#include<set>
#include<map>
#include<vector>
#include<algorithm>
#include<ctime>

using namespace std;

#define F first
#define S second
#define sf scanf
#define pf printf

int main()
{
	freopen("E.in", "r", stdin);
	freopen("E.out", "w", stdout);

	long long A, B, C, l, r, P, i;
	long long ans = 0;

	cin >> A >> B >> C >> l >> r >> P;

	for (i = l; i <= r; i++)
	{
		//cur++;
		ans += ((i - A) * (i - B) % P) * (i - C) % P;
		//if (cur > 1000) ans %= P, cur = 0; 
	}			

	cout << ans % P; 

	return 0;
}