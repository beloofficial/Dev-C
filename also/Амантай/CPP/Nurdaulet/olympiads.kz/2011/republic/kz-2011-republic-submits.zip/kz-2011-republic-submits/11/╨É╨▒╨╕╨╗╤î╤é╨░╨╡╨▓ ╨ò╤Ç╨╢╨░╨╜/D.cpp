#include <iostream>
#include <string>
#include <cstdlib>
#include <cstdio>
using namespace std;
int main()
{
	freopen ("D.in","r",stdin);
	freopen ("D.out","w",stdout);
	int a[100100],n,m,l,r;
	cin>>n>>m;  //cout<<"ss"; return 0;
for (int i=1; i<=n; i++)  cin>>a[i];

for (int i=1; i<=m; i++)
{
	cin>>l>>r;  int s=0;  
	for (int j=l; j<=r; j++)
	{
		bool f=true;
		for (int k=l; k<j; k++)
		if (j!=k && a[j]==a[k]) f=false;   if (f==true) s++;
	}	
	cout<<s<<endl;
		

}	

	return 0;
}