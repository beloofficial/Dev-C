#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <string>
#include <vector>
#include <cstdio>
#include <deque>
#include <queue>
#include <set>
#include <map>


using namespace std;

int a,b,c,l,r,p;
map<long long ,long long>f;
long long sum;

int main(){
        freopen("E.in","r",stdin);
	freopen("E.out","w",stdout);
	 scanf("%d%d%d%d%d%d",&a,&b,&c,&l,&r,&p);
		
	for (int i=l; i<=r; i++){ 	
		f[i] = ( i - a ) * ( i - b ) * ( i - c ); 
	         sum += f[i];
	          }
	printf("%d",sum % p);

	fclose(stdout);
return 0;
}