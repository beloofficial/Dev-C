#include <dist.h>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <cstdio>
#include <cstdlib>
#include <math.h>
#include <string>
#include <string.h>
#include <vector>
#include <queue>
#include <deque>
#include <list>
#include <set>
#include <map>
#include <algorithm>
#include <limits>
#include <utility>

#define FOR(i,a,b) for (int i=a; i<=b; i++)
#define FORD(i,a,b) for (int i=a; i>=b; i--)
#define INF numeric_limits <int> :: max()
#define p_b push_back
#define m_p make_pair

using namespace std;
int lx,ly,rx,ry,d,d1,d2,midx,midy,dst;
int main()
{
printf("start\n");
lx=ly=0; 
rx=ry=100000000;
//rx=ry=5;
d=INF;
while (d!=0)
 {
  midx=(lx+rx)/2;
  midy=(ly+ry)/2;

  printf("dist(%d,%d)",midx,midy);
  cin>>dst;

  if (dst==0)  
  { 
   printf("finish(%d,%d)",midx,midy);
   exit(0);
  }


  printf("dist(%d,%d)",midx,ry);
  cin>>d1;

  if (d1==0)  
  { 
   printf("finish(%d,%d)",midx,ry);
   exit(0);
  }

  printf("dist(%d,%d)",rx,midy);
  cin>>d2;

  if (d2==0)  
  { 
   printf("finish(%d,%d)",rx,midy);
   exit(0);
  }


  if (d1==d2 && d1<=d) rx=midx,ry=midy; else
  if (d1==d2 && d1>d) lx=midx,ly=midy;

  if (d1<d2 && d1<d) rx=midx,d=d1;
  if (d2<d1 && d2<d) ry=midy,d=d2; 

  if (d1<d2 && d1>d) lx=midx,d=d1; 
  if (d2<d1 && d2>d) ly=midy,d=d2; 
 }

fclose(stdin); fclose(stdout);
return 0;
}    