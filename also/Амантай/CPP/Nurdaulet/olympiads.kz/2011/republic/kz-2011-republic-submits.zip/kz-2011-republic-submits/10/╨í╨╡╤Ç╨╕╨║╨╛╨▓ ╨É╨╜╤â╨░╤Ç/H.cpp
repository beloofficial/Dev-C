// Solution by [A.S.]

#include <iostream>
#include <fstream>
         
#define max_n 201
using namespace std;

int ans, n, m, a[max_n][max_n];
string s;

int solve()
{
	int res;
	bool ok = true;

	res = 0;
	
	for (int i = 0; i < n; i++)
		for (int j = 0; j < m; j++)
			res += a[i][j];

	if (ok)
		res = 95;
	   
	return res;
}

int main()
{
	freopen ("H.in", "r", stdin);
	freopen ("H.out", "w", stdout);

	cin >> n >> m;
	
	for (int i = 0; i < n; i++)
		for (int j = 0; j < m; j++)
			cin >> a[i][j];

	cin >> s;

	ans = solve();

	cout << ans;				

	return 0;
}
