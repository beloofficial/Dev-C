#include <cstdio>
#include <iostream>
#include <algorithm>
using namespace std;

int n, m, a[509][509], b[509][509], i, j, k, ans, v[509], c[509], p[509], r[509];
bool u[509];
int cv, cc;
main ()
{
	freopen ("C.in", "r", stdin);
	freopen ("C.out", "w", stdout);
	scanf ("%d%d", &n, &m);
	cv = n;
	cc = m;
	int nm = max(n, m);
	for (i = 1; i <= n; i++)
	{
		scanf ("%d", &k);
		for (j = 0; j < k; j++)
		{
			int x;
			scanf ("%d", &x);
			if (!a[i][x])
			{
				p[i]++;
				r[x]++;
				a[i][x] = b[x][i] = 1;
			}
		}
	}
	for (i = 1; i <= m; i++)
	{
		scanf ("%d", &k);
		for (j = 0; j < k; j++)
		{
			int x;
			scanf ("%d", &x);
			if (!b[i][x])
			{
				r[i]++;
				p[x]++;
				b[i][x] = a[x][i] = 1;
			}
		}
	}
	for (;;)
	{
		int max1 = 0, max2 = 0, v1, v2;
		for (j = 1; j <= nm; j++)
		{
			if (max1 < p[j])
			{
				max1 = p[j];
				v1 = j;
			}	
		}
		for (j = 1; j <= nm; j++)
		{
			if (max2 < r[j])
			{
				max2 = r[j];
				v2 = j;
			}
		}
		if(!max1 && !max2)
			break;
		if (max1 > max2)
		{
			ccv:;
		  	for (j = 1; j <= nm; j++)
		  	{
		  		if (a[v1][j])
		  			r[j]--;
		  		a[v1][j] = b[j][v1] = 0;
			}
		  	p[v1] = 0;
		  	v[v1] = -1;
		  	cv--;
		}
		else if (max1 < max2)
		{
			ccc:;
			for (j = 1; j <= nm; j++)
			{
				if (b[v2][j])
					p[j]--;
				b[v2][j] = a[j][v2] = 0;
			}
			r[v2] = 0;
			c[v2] = -1;
			cc--;
		}
		else
		{
			if (cv > cc)
				goto ccv;
			else goto ccc;
		}
	}
	printf ("%d %d %d\n", cv + cc, cv, cc);
	for (i = 1; i <= n; i++)
		if (!v[i])
			printf ("%d ", i);
	printf ("\n");
	for (i = 1; i <= m; i++)
		if (!c[i])
			printf ("%d ", i);	
}
