#include<fstream>
using namespace std;
ifstream in("E.in");
ofstream out("E.out");
unsigned long long int a,b,c,l,r,p;
 long long int f(int x){
	long long  int q= (((x-a)%p*(x-b)%p)%p*(x-c)%p)%p;
	return q;
}
int main(){
        long long int sum=0;
         in>>a>>b>>c>>l>>r>>p;
         for(int i=l;i<=r;i++){
	        sum+=f(i);
		sum=sum%p;
}
out<<sum%p;
return 0;}