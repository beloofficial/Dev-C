#include <cstdio>
#include <iostream>

using namespace std;

#define LL long long 
#define INF 1e17

int n, m;
LL a[1005][1005], d[1005][1005], health;

int main() {
	freopen("H.in", "r", stdin);
	freopen("H.out", "w", stdout);

	scanf("%d %d", &n, &m);
	for (int i = 1; i <= n; i++) {
	    LL k = 0;
		for (int j = 1; j <= m; j++) {
			scanf("%I64d", &a[i][j]);
		    k += a[i][j];
		    if (i == 1) d[i][j] = k;
		    else d[i][j] = INF;
		}
	}
	scanf("%I64d", &health);

	for (int i = 2; i <= n; i++) {
		for (int j = 1; j <= m; j++) 
			d[i][j] = d[i - 1][j] + a[i][j];
		for (int j = 2; j <= m; j++)
			if (d[i][j] > d[i][j - 1] + a[i][j]) d[i][j] = d[i][j - 1] + a[i][j];
		for (int j = m - 1; j >= 1; j--)			
			if (d[i][j] > d[i][j + 1] + a[i][j]) d[i][j] = d[i][j + 1] + a[i][j];
	}

	printf("%I64d", health - d[n][m] + d[1][1]);		

	return 0;
}