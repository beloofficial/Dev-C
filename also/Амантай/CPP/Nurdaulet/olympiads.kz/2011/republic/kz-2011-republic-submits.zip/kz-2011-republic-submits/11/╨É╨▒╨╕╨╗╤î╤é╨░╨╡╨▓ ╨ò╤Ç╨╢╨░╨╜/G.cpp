#include <iostream>
#include <string>
#include <dist.h>
#include <cmath>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#define  eps 1e-4
using namespace std;

double  abss(double a) { if (a<0) a=a*-1.0; }


int main()
{
const long long nmax = 1000*1000*1000;
	int  y,x,mid,xmin,xmax,ymin,ymax;     double n,m;
start();
xmax = nmax;  xmin = -nmax;  y=1;
while (true)
{
	mid = (xmax+xmin) / 2; 
	n = dist(xmin,y);  m = dist(xmax,y); 
	if (mid == xx)  {  xmax=mid; break; } 
	if (n<m) xmax=mid;  else xmin=mid; 	
	if (xmax==xmin)  break;
}	
x = xmax;
ymax = nmax;  ymin = -nmax; 
while (true)
{
	mid = (ymax+ymin) / 2; 
	n = dist(x,ymin);  m = dist(x,ymax); 
	if (mid == yy)  {  ymax=mid; break; } 
	if (n<m) ymax=mid;  else ymin=mid; 	
	if (ymax==ymin)  break;
}           
y = ymax;       
finish (x,y);	
	return 0;
}




