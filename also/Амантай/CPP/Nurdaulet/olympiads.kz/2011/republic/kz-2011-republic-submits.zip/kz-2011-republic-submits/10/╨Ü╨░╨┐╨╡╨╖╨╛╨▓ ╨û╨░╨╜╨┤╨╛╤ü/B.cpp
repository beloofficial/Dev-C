//������� ������ 
//������
#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#include<cmath>
#include<vector>
#include<string>
#include<string.h>
#include<utility>

using namespace std;

#define sz size()
#define mp make_pair
#define pb push_back
#define sqr(x) ((x)*(x))
int d[50][50], dx[50], dy[50], d1[50], d2[50];
int a[50], r[50];
int n, res = 0;

void go(int i, int k, int total)
{
	if (i == n)
	{
		if (k)	return;
		if (total > res)
		{
			res = total;
			for (int q = 0; q < n; q++)
				r[q] = a[q];
		}
		return;
	}
	for (int j = 0; j < n; j++)
	{
		if (!d1[j + i] && !d2[j - i] && !dx[j] && !dy[i])
		{
			a[i] = a[i] | (1 << j);
			d1[j + i] = 1;
			d2[j - i] = 1;
			dx[j] = 1;
			dy[i] = 1;
				go(i + 1, k - 1, total + d[j][i]);
			d1[j + i] = 0;
			d2[j - i] = 0;
			dx[j] = 0;
			dy[i] = 0;
			a[i] = a[i] ^ (1 << j);
		}
	}
}

int main()
{
	freopen("B.in", "rt", stdin);
	freopen("B.out", "wt", stdout);
		scanf("%d", &n);		
		for (int i = 0; i < n; i++)
		{
			a[i] = 0;
			for (int j = 0; j < n; j++)
				scanf("%d", &d[i][j]);
		}
		go(0, n, 0);
        
		for (int j = 0; j < n; j++)
		{
			for (int i = 0; i < n; i++)
				d[i][j] = (r[j] & (1 << i)) > 0 ? 1 : 0;
		}
		for (int i = 0; i < n; i++)
		{
		 	for (int j = 0; j < n; j++)
		 		printf("%d ", d[i][j]);
			printf("\n");
		}
        
//		#define debug
		#ifdef debug
			for (int i = 0; i < n; i++)
			{
	    		int j = 0;
	    		while((1 << j) < r[i])	j ++;
	    		if ((1<<j) == r[i])	cerr<<"ok "; else
	    		{
	    							cerr<<"er ";
	    							return 3;
	    		}
			}
			cerr<<endl;
			for (int i = 0; i < n; i++)
				cerr<<r[i]<<" ";
		#endif
	return 0;
}
