#include <cstdio>      
int main () {
	freopen("E.in", "r", stdin);
	freopen("E.out", "w", stdout);
	long long a, b, c, i;
	int l, r, p, sum = 0;
	scanf("%I64d%I64d%I64d%d%d%d", &a, &b, &c, &l, &r, &p);        
	for (i = l; i <= r; i++) {
	    sum = (sum + ((((i - a) * (i - b)) % p) * (i - c)) % p) % p;
		                     	
	}                                             
	printf("%d", sum);
	//for (i = l; i <= r; i++) 
	//	sum = (sum + ((((i - a) * (i - b)) % p) * (i - c)) % p) % p;
}	
