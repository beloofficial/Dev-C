#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstdlib>
#include<vector>
#include<utility>
#include<queue>
#include<ctime>
#include<list>
#include<set>
#include<map>

using namespace std;

#define tr(Con,it) for(typeof(Con.begin()) it=Con.begin();it!=Con.end();it++)
#define pb push_back
#define mp make_pair
int main(){
	freopen("H.in","r",stdin);
	freopen("H.out","w",stdout);

	printf("95\n");

return 0;
}