//Zhienbek Shyngys 9 Astana KTL
#include<iostream>
#include<utility>
#include<map>
#include<cmath>
#include<math.h>
#include<stdio.h>
#include<stdlib.h>
#include<algorithm>
#include<cstdio>
#include<cstdlib>
#include<fstream>
#include<string>
#include<string.h>
#include<sstream>
#include<limits>
#include<assert.h>
#define eps 1e-12
#define mp(x,y) make_pair(x,y)
#define inf numeric_limits<int> :: max()
#define For(i,a,b) for(int i=a;i<=b;i++)
#define FOR(i,a,b) for(int i=a;i>=b;i--)
using namespace std;

int n,a[100001],k=0,m;
map <int,bool> u;

int main()
{
 #ifndef ONLINE_JUDGE
  freopen("D.in","rt",stdin);
  freopen("D.out","wt",stdout);
 #endif
  
   scanf("%d%d",&n,&m);
   For(i,1,n) 
    {
     scanf("%d",&a[i]);
     if (!u[a[i]]) k++;
     u[a[i]]=1;
    }
   For(i,1,n) u[a[i]]=0;
   For(i,1,m)
    {
     int ans=0,x,y;
     scanf("%d%d",&x,&y);
     if (x==1 && y==n) { printf("%d\n",k); continue; }
     For(i,x,y)
      {
       if (!u[a[i]]) ans++;
       u[a[i]]=1;
      }
     For(i,x,y) u[a[i]]=0;
     printf("%d\n",ans);
    }
  
 fclose(stdin);fclose(stdout);
 return 0;
}
