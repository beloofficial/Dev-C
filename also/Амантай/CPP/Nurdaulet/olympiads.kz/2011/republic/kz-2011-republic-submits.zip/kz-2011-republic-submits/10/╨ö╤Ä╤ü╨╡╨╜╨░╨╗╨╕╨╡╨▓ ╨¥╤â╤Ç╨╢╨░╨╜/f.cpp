#include <set>
#include <map>
#include <vector>
#include <cstdio>
#include <cstdlib>
#include <string.h>
#include <iostream>
#include <algorithm>
using namespace std;

#define sz(a) (a).size()
#define pb push_back
#define mp make_pair

const int lg = 17;
const int x = 1<<17;
const int N = 1<<17;

char ch;
bool w[N];
int Sum[N<<1], add[N<<1], pr[N][lg+1], in[N], out[N], k, i, n, m, v, u, anc, a[N], b[N], h[N], l[N], r[N], cnt, T, what, who, ones;
vector<int> e[N];

void upd(int v, int l, int r, int L, int R, int k)
{
	if (r < L || R < l) return;
	if (L <= l && r <= R)
		add[v] += k;
	else
	{
		int m = (l + r) / 2;
		upd(v * 2, l, m, L, R, k);
		upd(v * 2 + 1, m + 1, r, L, R, k);
		Sum[v] = Sum[v * 2] + Sum[v * 2 + 1] + (r - l + 1) / 2 * (add[v * 2] + add[v * 2 + 1]);
	}
}

int get(int v, int l, int r, int L, int R, int k)
{
	if (r < L || R < l) return 0;
	if (L <= l && r <= R)
		return Sum[v] + (r - l + 1) * (add[v] + k);
	else
	{
		int m = (l + r) / 2;
		return get(v * 2, l, m, L, R, k + add[v]) + get(v * 2 + 1, m + 1, r, L, R, k + add[v]);
	}
}

void dfs(int v, int lvl)
{
	in[v] = ++T;
	l[v] = ++cnt;
	h[v] = lvl;
	w[v] = 1;
	for (int i = 0; i < sz(e[v]); i++)
	{
		int u = e[v][i];
		if (!w[u])
		{
			pr[u][0] = v;
			dfs(u, lvl + 1);
		}
	}
	r[v] = cnt;
	out[v] = ++T;
}

inline int sum(int v) { return get(1,1,x,l[v],l[v],0); }

void precalc_lca()
{
	in[0] = -1;
	out[0] = 1<<30;
	memset(pr, 0, sizeof(pr));
	for (int j = 1; j <= lg; j++)
	for (int i = 1; i <= n; i++)
		pr[i][j] = pr[pr[i][j-1]][j-1];
}

bool ancestor(int v, int u)
{
	return in[v] < out[u] && out[u] < out[v];
}

int lca(int v, int u)
{
	if (ancestor(v,u) || v == u) return v;
	if (ancestor(u,v)) return u;
	int j = lg;
	while (j >= 0)
	{
		if (!ancestor(pr[v][j], u))
			v = pr[v][j];
		j--;
	}
	return pr[v][0];
}

int main()
{
	freopen("F.in", "r", stdin);
	freopen("F.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for (i = 1; i <= m; i++)
	{
		scanf("%d%d", a+i, b+i);
		e[a[i]].pb(b[i]);
		e[b[i]].pb(a[i]);
	}
	dfs(1, 0);
	precalc_lca();
	scanf("%d\n", &k);
	for (i = 1; i <= m; i++)
	if (h[a[i]]>h[b[i]]) swap(a[i],b[i]);

	while (k--)
	{
		scanf("%c", &ch);
		if (ch == 'q')
		{
			scanf("%d%d%d\n", &v, &u, &who); who--;
			anc = lca(v,u);
			ones = sum(v)+sum(u)-2*sum(anc);
			if (who == 1)
				printf("%d\n", ones);
			else
				printf("%d\n", h[v]+h[u]-2*h[anc]-ones);
		}
		else
		{
			scanf("%d%d\n", &who, &i); who--; v = b[i];
			what = sum(v) - sum(pr[v][0]);
			if (who == what)
				continue;
			if (what == 1)
				upd(1,1,x,l[v],r[v],-1);
			else
				upd(1,1,x,l[v],r[v],1);
		}
	}
	return 0;
}
