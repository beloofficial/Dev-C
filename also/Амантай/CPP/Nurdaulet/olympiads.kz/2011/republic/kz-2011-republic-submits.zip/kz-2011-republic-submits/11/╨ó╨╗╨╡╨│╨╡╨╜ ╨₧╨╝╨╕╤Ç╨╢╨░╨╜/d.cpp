#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cmath>
#include <string>
#include <cstring>
#include <map>
#include <set>
#include <deque>
#include <queue>
#include <vector>

#include <ctime>

using namespace std;

#define name 	"D"
#define INF 	int(1e9)
#define EPS		1e-9
#define SZ(x)	int(x.size())
#define ALL(x)	x.begin(), x.end()

int n, m;
int a[100001];
int d[100001];
set<int> SET, ANS;
set<int> tree[400004];
set<int> :: iterator it;
map<pair<int,int>, int> make;
map<pair<int,int>, bool> use;

void build(int v, int l, int r) {
 	if (l == r) {
 	 	tree[v].insert(a[r]);
 	 	return;
 	}

 	int mid = (l+r)/2;

 	build(2*v, l, mid);
 	build(2*v+1, mid+1, r);

 	for (it = tree[2*v].begin(); it != tree[2*v].end(); ++ it ) {
 	 	tree[v].insert(*it);
 	}
 	for (it = tree[2*v+1].begin(); it != tree[2*v+1].end(); ++ it ) {
 	 	tree[v].insert(*it);
 	}
}

void sum(int v, int l, int r, int l1, int r1) {
	if (l == l1 && r == r1) {
	 	for (it = tree[v].begin(); it != tree[v].end(); ++ it) {
	 	 	ANS.insert(*it);
	 	}
	 	return;
	}

	int mid = (l1+r1)/2;

	if (l <= mid) 
		sum(2*v, l, min(r,mid), l1, mid);
	if (r > mid)
		sum(2*v+1, max(l, mid+1), r, mid+1, r1);
}

int main() {
	ios_base::sync_with_stdio(false);

	freopen(name".in","r",stdin);
	freopen(name".out","w",stdout);

	cin >> n >> m;

	for (int i = 0; i < n; ++ i) {
		cin >> a[i];
	}	

	if (n < 1000) {
		d[0] = 1;
		for (int i = 1; i < n; ++ i) {
			d[i] = 1;
			for (int j = i-1; j >= 0; -- j) {
			 	SET.insert(a[j]);
			}
			d[i] += SZ(SET);
			SET.clear();
		}

		int l, r;
		for (int i = 0; i < m; ++ i) {
		 	cin >> l >> r;
		 	r--;
		 	l-=2;
		 	if (l < 0) {
		 	 	cout << d[r] << endl;
		 	} else {
		 		cout << d[r]-d[l] << endl;
		 	}
		}
	} else {
	 	build(1, 0, n-1);

	 	int l, r;
	 	for (int i = 0; i < m; ++ i) {
	 		cin >> l >> r;
	 		l--, r--;
	 		if (use[make_pair(l,r)]) {
	 		 	cout << make[make_pair(l,r)] << endl;
	 		} else {
	 			sum(1, l, r, 0, n-1);
	 			cout << SZ(ANS) << endl;
	 			make[make_pair(l, r)] = SZ(ANS);
	 			use[make_pair(l, r)] = true;
	 			ANS.clear();
	 		}
	 	}
	}
	

	return 0;
}
