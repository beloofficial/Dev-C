// Zhalpakov Daulet
#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
#include <vector>
#include <cmath>
#include <map>
using namespace std;

int n, mask[100][100], res[100][100], c[100][100], bestcost, vert[100], diag[100], pdiag[100], T;

void rec (int v, int cost);

int main()
{
	freopen("B.in", "r", stdin);
	freopen("B.out", "w", stdout);

	scanf("%d", &n);
	for (int i = 0; i < n; ++i)
		for (int j = 0; j < n; ++j)
			scanf("%d", &c[i][j]);

	bestcost = -1;
	rec(0, 0);	
	
	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < n; ++j)
	    	printf("%d ", res[i][j]);
		cout << endl;
	}

	return 0;
}

void rec (int v, int cost)
{
	T++;
	if (T > 10000000) {
		for (int i = 0; i < n; ++i) {
			for (int j = 0; j < n; ++j)
		    	printf("%d ", res[i][j]);
			cout << endl;
		}
		exit(0);
	}

	if (v == n) {
/*		for (int i = 0; i < n; ++i) {
			for (int j = 0; j < n; ++j)
				printf("%d ", mask[i][j]);
			cout << endl;
		}
		cout << "------------" << endl; 
*/
		if (cost > bestcost) {
			for (int i = 0; i < n; ++i)
				for (int j = 0; j < n; ++j)
					res[i][j] = mask[i][j];
			bestcost = cost;
		}

		return;	
	}

	for (int i = 0; i < n; ++i) {
		if (!vert[i] && !diag[n - i + v - 1] && !pdiag[i + v]) {
			vert[i] = 1;
			diag[n - i + v - 1] = 1;
			pdiag[i + v] = 1;
			mask[v][i] = 1;
			rec(v + 1, cost + c[v][i]);

			mask[v][i] = 0;
			vert[i] = 0;
			diag[n - i + v - 1] = 0;
			pdiag[i + v] = 0;
		} 
	}
}
