//Solution by Balakshy Andrey 16.04.11

#include <cstdio>
#include <iostream>
#include <vector>
#include <map>
#include <cmath>
#include <algorithm>

using namespace std;

#define pb push_back
#define mp make_pair
#define For(i, p1, p2, st) for (int i = (int)p1; i < (int)p2; i += (int)st)
#define FoR(i, p1, p2, st) for (int j = (int)p1; i > (int)p2; i -= (int)st)  


vector <int> d;
map <int,int> k;
int n, m, ch, l, r, nach;

int main()
{
  freopen("D.in", "r", stdin);
   freopen("D.out", "w", stdout); 

    cin >> n >> m; 


     For(i, 0, n, 1) {
      scanf("%d", &ch), d.pb(ch);
       k[d[i]]++;
     }

       nach = k.size();  

   
   For(p, 0, m, 1){
    scanf("%d%d", &l, &r);   
    if (l == 0 && r == n - 1) printf("%d\n", nach);
     else{
        k.clear();
         For(q, l, r + 1, 1)
          k[d[q]]++;
           printf("%d\n", k.size());
     }    
   }

 
 
  
  return 0;
}
