//Kushibar Kaisar
#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include <cctype>
#include <cstdio>
#include <ctime>
#include <cmath>
#include <set>
#include <map>

#define fname "C"
using namespace std;

int n, m, k, nc[1000], mc[1000], a[1000][1000], b[1000][1000];
int n1, m1, ans, curn, curm, cur, anc[1000], amc[1000];

int main(){
	freopen(fname".in","r",stdin);
	freopen(fname".out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1; i<=n; i++){
		scanf("%d", &k);
		for(int j=1; j<=k; j++)scanf("%d", &a[i][j]);
		a[i][0]=k;
	}
	for(int i=1; i<=n; i++){
		scanf("%d", &k);
		for(int j=1; j<=k; j++)scanf("%d", &b[i][j]);
		b[i][0]=k;
	}
//	if(n>10){
	if(n>m){
		printf("%d %d %d\n", n, n, 0);
		for(int i=1; i<=n; i++)printf("%d ",i); printf("\n");
	} else {
		printf("%d %d %d\n", m, 0, m);printf("\n");
		for(int i=1; i<=m; i++)printf("%d ",i); printf("\n");
	}
/*	} else {
		for(int i=0; i<(1<<n); i++){
			curn=0; curm=m; cur=0;
			memset(nc, 0, sizeof(nc));
			memset(mc, 0, sizeof(mc));
			for(int j=0; j<n; j++)
				if((i>>j) & 1){
					curn++;
					curm-=a[j+1][0];
					nc[j]=1;
					for(int t=1; t<=a[j+1][0]; t++)
						mc[a[j+1][t]]=1;
				}
			cur=curn+curm;
			if(cur>ans){
				ans=cur; n1=curn; m1=curm;
				anc[0]=0; amc[0]=0;
				for(int j=1; j<=n; j++)
					if(nc[j]==1){anc[0]++; anc[anc[0]]=j;}
				for(int j=1; j<=m; j++)
					if(mc[j]==0){amc[0]++; amc[amc[0]]=j;}
			}
		}
		printf("%d %d %d\n", ans, n1, m1);
		for(int i=1; i<=anc[0]; i++)printf("%d ", anc[i]); printf("\n");
		for(int i=1; i<=amc[0]; i++)printf("%d ", amc[i]); printf("\n");
	}
*/	
	return 0;
}
