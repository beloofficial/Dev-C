// Dyussupov Dauren 11 class Atyrau
#include<cstdio>
#include<iostream>
#include<cmath>
#include<cstdlib>
#include<cstring>
#include<set>
#include<map>
#include<vector>
#include<algorithm>
#include<ctime>

using namespace std;

#define F first
#define S second
#define sf scanf
#define pf printf

long long a[300][300];

int main()
{
	freopen("H.in", "r", stdin);
	freopen("H.out", "w", stdout);

	int n, m, i, j;
	string s;

	scanf("%d%d", &n, &m);

	for (i = 1; i <= n; i++)
	for (j = 1; j <= m; j++)
		cin >> a[i][j];

	cin >> s;
			
	if (n == 1 && m == 1) cout << s; else
	if (n == 2 && m == 3) cout << "95"; else cout << 0;

	return 0;
}