#include <iostream>
#include <algorithm>
#include <queue>
#include <utility>
#include <iomanip>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <string.h>
#include <math.h>
#include <numeric>
#include <time.h>
#define MAXP 205432
using namespace std;
int n, m, g[MAXP], head[MAXP], next[MAXP], st[MAXP];
bool used[MAXP];
int ans = 0;
void dfs (int s, int f, int num) {
     used[s] = 1;
     if (s == f) {
     	if (st[s] == num) ++ans;
     	return;
     }
     for (int h = head[s]; h != 0; h = next[h])
     	  if (!used[g[h]]) {
     	         dfs (g[h], f, num);
     	         if (ans) {
     	          if (st[s] == num) ans++;
     	         	return;
     	         }
     	  }
}
int main () {
	freopen ("F.in", "r", stdin);
	freopen ("F.out", "w", stdout);
	scanf ("%d%d", &n, &m);
	for (int i = 1; i <= n; i++)
		st[i] = 1;
	for (int i = 1; i <= m; i++) {
		int x, y;
		scanf ("%d%d", &x, &y);
		g[i] = y;
		next[i] = head[x];
		head[x] = i;
		g[i + m] = x;
		next[i + m] = head[y];
		head[y] = i + m;
	}
	int k;
	char fig;
	scanf ("%d", &k);
	for (int i = 1; i <= k; i++) {
		char sy, pr;
		scanf ("%c%c%c", &fig, &sy, &pr);
		if (sy == 'q') {
			int x, y, num;
			ans = 0;
			memset (used, 0, sizeof (used));
			scanf ("%d%d%d", &x, &y, &num);
//			printf ("%d %d %d\n", x, y, num);
			dfs (x, y, num);
			printf ("%d\n", ans - 1);
		}
		else {
			int num, y;
			scanf ("%d%d", &num, &y);
			st[y] = num;
		}
	}
	return 0;
} 