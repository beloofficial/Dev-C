#include<iostream>
#include<fstream>
#include<map>
#include<cstdlib>
#include<string>
#include<vector>
#include<deque>
#include<set>
#include<cstdio>
#include<cmath>
#include<algorithm>

#define INF (1 << 30)
#define pb push_back
#define mp make_pair
#define VI vector <int>
#define VVI vector < VI >
#define fi first
#define se second

using namespace std;

int g[510][510], g1[510][510], gz[510], g1z[510], a[510], b[510], ne[510], g2[510][510], g2z[510], g3[510][510], g3z[510], rr1[510], rr2[510];
int n, m, q, w, e, r1, r2, mx = 0;
bool u[2][510];
int R1z = 0, R2z, R1[510], R2[510];
          
void dfs(int v, int d){
	u[d][v] = 1;
	if(!d){
		for(int i = 0; i < gz[v]; ++i)
			ne[g2[v][i]] = 1;

		for(int i = 0; i < gz[v]; ++i)
			if(!u[1][g[v][i]] && !ne[g[v][i]])
				dfs(g[v][i], 1);
	}

	else{
		for(int i = 0; i < g1z[v]; ++i)
			ne[g3[v][i]] = 1;

		for(int i = 0; i < g1z[v]; ++i)
			if(!u[0][g1[v][i]] && !ne[g1[v][i]])
				dfs(g1[v][i], 0);
					
	}
	if(!d) rr1[r1++] = v;
	else rr2[r2++] = v;
}

int main(){

	freopen("c.in", "r", stdin);
	freopen("c.out", "w", stdout);

	cin >> n >> m;

	for(int i = 0; i < n; ++i){
		scanf("%d", &q);
		for(int j = 0; j < 510; ++j) b[j] = 0;
		for(int j = 0; j < q; ++j){
			scanf("%d", &a[j]);
			--a[j];
			g2[i][g2z[i]++] = a[j];
			++b[a[j]];
		}
		for(int j = 0; j < m; ++j)
			if(!b[j])	
				g[i][gz[i]++] = j;
	}	

	for(int i = 0; i < m; ++i){
		scanf("%d", &q);
		for(int j = 0; j < 510; ++j) b[j] = 0;
		for(int j = 0; j < q; ++j){
			scanf("%d", &a[j]);
			--a[j];
			g3[i][g3z[i]++] = a[j];
			++b[a[j]];
		}
		for(int j = 0; j < n; ++j)
			if(!b[j])	
				g1[i][g1z[i]++] = j;
	}

	for(int i = 0; i < n; ++i)
		if(!u[0][i]){
			r1 = r2 = 0;
			for(int j = 0; j < max(n, m); ++j) ne[j] = 0;
			dfs(i, 0);
			if(r1 + r2 > mx){
				mx = r1 + r2;
				R1z = r1, R2z = r2;
				for(int j = 0; j < r1; ++j) R1[j] = rr1[j];
				for(int j = 0; j < r2; ++j) R2[j] = rr2[j];
			}
		}

	for(int i = 0; i < m; ++i)
		if(!u[1][i]){
			r1 = r2 = 0;
			for(int j = 0; j < max(n, m); ++j) ne[j] = 0;
			dfs(i, 1);
			if(r1 + r2 > mx){
				mx = r1 + r2;
				R1z = r1, R2z = r2;
				for(int j = 0; j < r1; ++j) R1[j] = rr1[j];
				for(int j = 0; j < r2; ++j) R2[j] = rr2[j];
			}
		}


	printf("%d %d %d\n", mx, R1z, R2z);

	for(int i = 0; i < R1z; ++i)
		printf("%d ", R1[i] + 1);

	printf("\n");

	for(int i = 0; i < R2z; ++i)
		printf("%d ", R2[i] + 1);
		                    
	return 0;
}