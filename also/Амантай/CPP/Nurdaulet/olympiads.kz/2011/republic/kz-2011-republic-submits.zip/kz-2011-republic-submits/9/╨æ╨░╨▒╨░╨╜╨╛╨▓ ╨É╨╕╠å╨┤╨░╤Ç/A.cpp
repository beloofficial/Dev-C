#include<fstream>
using namespace std;
int main(){
	ifstream in("A.in");
	ofstream out("A.out");
        int n;
in>>n;
out<<"2 3";
}