#include <iostream>
#include <cmath>
#include <algorithm>
#include <cstdio>
#include <set>
#include <vector>
#include <cstring>
          
using namespace std;

int n,m,k,a1,a2,x,y,which,nowcolor=1;
pair<int,int> roads[100002];
char c;
int condidat[10002][10002]={0};
bool mas[10002][10002]={0};
bool used[10002];
int colorize[10002]={0};
vector<int> component[1000002];
             
void colorisation(int a){
	if (colorize[a]!=0)
		return;
	else {
		colorize[a]=nowcolor;
		component[nowcolor].push_back(a);
		for (int i=1; i<=n; i++)
			if (mas[a][i])
				colorisation(i);
	}
}

int main(){

		freopen("f.in","r",stdin);
		freopen("f.out","w",stdout);

	cin>>n>>m;
	for (int i=1; i<=m; i++){
		cin>>a1>>a2;
        mas[a1][a2]=1;
        mas[a2][a1]=1;
        roads[i].first=a1;
        roads[i].second=a2;
        condidat[a1][a2]=condidat[a2][a1]=1;
	}
    
    for (int i=1; i<=n; i++){
    	if (colorize[i]==0){
    		colorisation(i);
			nowcolor++;
		}
    }

	                                
	cin>>k;

	
	for (int i=1; i<=k; i++){
		cin>>c;

		if (c=='q'){                                                 		
		
        	cin>>x>>y>>which;
		
			if (colorize[x]!=colorize[y])
				cout<<0<<endl;
		    
		    else {

		    	int compnumber=colorize[x];
		    
		    	int sizer=component[compnumber].size()-1,answer=0,noww=which;

		    	for (int xx=0; xx<=sizer-1; xx++){
		    		for (int j=xx+1; j<=sizer; j++)
		    			if (condidat[component[compnumber][xx]][component[compnumber][j]]==noww)
			    			answer++;
				}
				cout<<answer<<endl;                        		    					    
		    }



		}
		
		if (c=='+') {
			
			cin>>x>>y;

			condidat[roads[y].first][roads[y].second]=x;
			condidat[roads[y].second][roads[y].first]=x;

		}  
	}
/*
	for (int i=1; i<=nowcolor-1; i++){
		for (int j=0; j<=component[i].size()-1; j++)
			cout<<component[i][j]<<" ";
		cout<<endl;
	}
*/
	return 0;
}

