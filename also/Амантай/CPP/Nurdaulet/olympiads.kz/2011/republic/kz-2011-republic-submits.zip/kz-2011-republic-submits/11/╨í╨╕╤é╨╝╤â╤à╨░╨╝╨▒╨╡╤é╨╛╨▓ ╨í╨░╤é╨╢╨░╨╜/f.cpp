#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
const int N = 100009;
struct node;
typedef node *tnode;
struct node {
	tnode prev;
	int val;
	node () { val = 0; prev = 0; }
	node (int x) { val = x; prev = 0; }
};
struct list {
	tnode e;
	list () { e = 0; }
	void add(tnode t) {
		if (e != 0)
			t->prev = e;		
		e = t;
	}
} a[N];
int lvl[N], u[N], p[N], qx[N], qy[N];
void go(int v, int lv) {
	int g;
	tnode t;
	lvl[v] = lv;
	for (t = a[v].e; t != 0; t = t->prev) {
		g = t->val;
		if (u[g] == 0) {
			p[g] = v;
			u[g] = 1;
			go(g, lv + 1);
		}
	}
}
int main () {
	freopen("F.in", "r", stdin);
	freopen("F.out", "w", stdout);
	int n, m, i, x, y, sum ,cnt, l, r, k;
	char cmd;
	scanf("%d %d", &n, &m);
	//printf("%d %d\n", n, m);
	for (i = 1; i <= m; i++) {
		scanf("%d %d", &x, &y);
		//printf("%d %d\n", x, y);
		qx[i] = x;
		qy[i] = y;
		a[x].add(new node (y));
		a[y].add(new node (x));
	}
	u[1] = 1;        	
	go(1, 1);
	scanf("%d", &m);
	//printf("%d\n", m);
	for (i = 1; i <= m; i++) {
		scanf("\n");
		scanf("%c", &cmd);
		//printf("%c \n", cmd);
		if (cmd == 'q') {
			scanf("%d %d %d", &x, &y, &k);
		//	printf("%d %d %d\n", x, y, k);
			l = lvl[x];
			r = lvl[y];
			sum = cnt = 0;
			for ( ; r != l; sum++) {
				if (l > r) {
					cnt += u[x];
					x = p[x];
					l--;
				}
				else {
					cnt += u[y];
					y = p[y];
					r--;
				}
			}
			while (x != y) {
				sum += 2;
				cnt += u[x] + u[y];
				x = p[x];
				y = p[y];
			}
			if (k == 2) cnt = sum - cnt;
			
			printf("%d\n", cnt);
		}
		else {
			scanf("%d %d", &x, &y);
		//	printf("%d %d\n", x, y);
			k = x;
			x = qx[y];
			y = qy[y];
			if (lvl[x] > lvl[y]) 
				u[x] = k % 2;
			else       
				u[y] = k % 2;
		}		
	}	       		       
}	





















































