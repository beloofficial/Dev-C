#include <iostream>
#include <cstdio>
#include <vector>
#include <string>
#include <cstring>
#include <cmath>
#include <map>
#include <algorithm>
#include <set>

using namespace std;

const double pi = acos((double) - 1);
const int maxn = 100010;

int main() {
	
	freopen("D.in", "r", stdin);
	freopen("D.out", "w", stdout);
	
	int n, m, l, r;
	int a[maxn];
	cin >> n >> m;
	for (int i = 1; i <= n; i++)
		cin >> a[i];

	set <int> s;
	for (int i = 1; i <= m; i++) {
		s.clear();
		cin >> l >> r;
		for (l; l <= r; l++)
			s.insert(a[l]);
		cout << s.size() << endl;
	}

	return 0;
}
