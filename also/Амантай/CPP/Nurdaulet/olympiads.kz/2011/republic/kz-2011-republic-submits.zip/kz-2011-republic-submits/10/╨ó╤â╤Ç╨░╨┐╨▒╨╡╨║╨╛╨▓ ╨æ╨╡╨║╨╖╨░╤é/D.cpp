#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstdlib>
#include<utility>
#include<queue>
#include<ctime>
#include<list>
#include<set>
#include<map>

using namespace std;

int n,m,l,r,ans;
int a[100100];

int main(){
	freopen("D.in","r",stdin);
	freopen("D.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	
	for(int cnt=1;cnt<=m;cnt++) {
		ans=0;
		scanf("%d %d\n",&l,&r);
		set<int> S;
		for(int i=l;i<=r;i++)
			S.insert(a[i]);

		printf("%d\n",(int)S.size());
	}

return 0;
}