//Solution by Mukai Yersin
#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <ctime>
#include <cmath>
#include <map>
#include <set>

#ifdef Win32
	#define i64 "%I64d"
#else
	#define i64 "%lld"
#endif
#define sz 2000000
#define nsz 2000
#define fname "E."
#define sqr(w) ((w)*(w))
#define maxint (1<<30)
#define ll long long

using namespace std;

ll a,b,c,l,r,p,s,i;

ll f(ll x)
{
 	return ((((((x-a)%p)*((x-b)%p))%p)*((x-c)%p))%p)*1ll;
}

int main()
{
	freopen(fname"in","r",stdin);
	freopen(fname"out","w",stdout);
		scanf(i64" "i64" "i64" "i64" "i64" "i64,&a,&b,&c,&l,&r,&p);
		for (i=l;i<=r;i++)
			 s=((s*1ll)%p+(f(i)*1ll)%p)%p;
		printf(i64,s);
	return 0;
}
