#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <string>
#include <vector>
#include <cstdio>
#include <set>
#include <map>


using namespace std;

int n,p,kol;
long long prov;
          
struct vlong{
	int l,d[100000000];
};

vlong c;

void fact(int n, vlong &c){
	c.l = 1;
	c.d[1] = 1;

	for (int i=2; i<1000; i++)
	c.d[i] = 0 ;
	
	for (int i=1; i<=n; i++){
		for (int j=1; j<=c.l; j++)	
	c.d[j] *= i;
	  
	for (int k=1; k<=c.l; k++){
		if ( c.d[c.l] > 0  ) c.l++;
		c.d[k+1] += (c.d[k] / 10);
		c.d[k] %= 10;
	                   
}       }

	while (c.d[c.l] == 0 && c.l > 1 ) c.l--;
}	
	      

void mod(int p, long long prov, int i){	

        if ( i < 1 ) return;
              
	while ( prov < p ) {
		prov = prov * 10 + c.d[i];
		i--;			
		                         
       }

		
		prov -= p * (prov / p); 	
        	mod(p,prov,i);

        	if ( kol == 0 ) {  printf("%d",prov); kol++; }
	   


 }






int main(){
        freopen("G.in","r",stdin);
	freopen("G.out","w",stdout);
	
	scanf("%d%d",&n,&p);


	fact(n,c);

	mod(p,prov,c.l);
	
	int a = -23; 	fclose(stdout);
return 0;
}