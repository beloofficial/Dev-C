#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cmath>
#include <string>
#include <cstring>
#include <map>
#include <set>
#include <deque>
#include <queue>
#include <vector>

using namespace std;

#define name 	"H"
#define INF 	int(1e9)
#define EPS		1e-9
#define PB		push_back
#define MP		make_pair
#define fi		first
#define se		second
#define SZ(x)	int(x.size())
#define ALL(x)	x.begin(), x.end()

typedef long long LL;

int car;
vector<int> x (1,0);
vector<int> MAX (101,1);

class BigInteger{
	public:
		vector<int> v;

   	BigInteger(vector<int> a = x) : v(a) {}

   	friend ostream& operator << (ostream& stream, BigInteger a) {
   	 	for (int i = 0; i < SZ(a.v); ++ i) stream << a.v[i];
   	 	return stream;
   	}

	BigInteger operator + (BigInteger w) {
		vector<int> a, b, c;
	 	a = v, b = w.v;
	 	reverse(ALL(a));
	 	reverse(ALL(b));

	 	while (SZ(a) < SZ(b)) a.PB(0);
	 	while (SZ(a) > SZ(b)) b.PB(0);

	 	c.resize(SZ(a), 0);
	 	car = 0;

	 	for (int i = 0; i < SZ(a); ++ i) {
	 		c[i] = (a[i] + b[i] + car) % 10;
	 		car = (a[i] + b[i] + car) / 10;
	 	}

	 	if (car != 0) c.PB(car);

	 	while (!c.empty() && c.back() == 0) c.pop_back();
	 	reverse(c.begin(), c.end());

	 	return BigInteger(c);
	}	

	BigInteger operator * (BigInteger w) {
		vector<int> a, b, c;
	 	a = v, b = w.v;
	 	reverse(ALL(a));
	 	reverse(ALL(b));

	 	c.resize(SZ(a) + SZ(b), 0);
	 	car = 0;

	 	for (int i = 0; i < SZ(a); ++ i) {
	 		for (int j = 0; j < SZ(b); ++ j) {
	 			c[i+j] += a[i] * b[j];
	 		}
	 	}

	 	for (int i = 0; i < SZ(c); ++ i) {
	 	 	if (c[i] > 9) {
	 	 	 	if (i+1 < SZ(c)) {
	 	 	 	 	c[i+1] += c[i]/10;
	 	 	 	 	c[i] %= 10;
	 	 	 	} else {
	 	 	 	 	c.PB(c[i]/10);
	 	 	 	 	c[i] %= 10;
	 	 	 	}
	 	 	}
	 	}

	 	while (!c.empty() && c.back() == 0) c.pop_back();

	 	reverse(c.begin(), c.end());

	 	return BigInteger(c);
	}	

	BigInteger operator - (BigInteger w) {
		vector<int> a, b, c;
	 	a = v, b = w.v;
	 	reverse(ALL(a));
	 	reverse(ALL(b));

	 	while (SZ(a) < SZ(b)) a.PB(0);
	 	while (SZ(a) > SZ(b)) b.PB(0);

	 	c.resize(SZ(a), 0);
	 	car = 0;

	 	for (int i = 0; i < SZ(a); ++ i) {
	 		c[i] = a[i] - b[i];
	 	}

	 	for (int i = 0; i < SZ(a); ++ i) {
	 		if (c[i] < 0) {
	 		 	c[i+1] --;
	 		 	c[i] += 10;
	 		}
	 	}

	 	while (SZ(c) > 1 && c.back() == 0) c.pop_back();
	 	reverse(c.begin(), c.end());

	 	return BigInteger(c);
	}	

	bool operator < (BigInteger w) {
	 	vector<int> a, b;
	 	a = v, b = w.v;

	 	if (SZ(a) < SZ(b)) return true;
	 	if (SZ(a) > SZ(b)) return false;

	 	for (int i = 0; i < SZ(a); ++ i) {
	 		if (a[i] < b[i]) return true;
	 		if (a[i] > b[i]) return false;
	 	}

	 	return false;
	}

};

BigInteger Int_Big(int x) {
	vector<int> a;
 	if (!a.empty()) a.clear();

 	do {
		a.PB(x % 10);
		x /= 10;
 	} while (x > 0);

 	reverse(ALL(a));
 	return BigInteger(a);
}


int n, m, X, xx ,yy, xx1 ,yy1;
int N, M;
string S;
BigInteger a[201][201];
BigInteger k[201][201];
BigInteger mas[201][201];
BigInteger s;

int dx[] = {1, 0, 0};
int dy[] = {0, 1,-1};
deque<pair<int,int> > Q;

bool check(int i, int j) {
 	return (0 <= i && 0 <= j && i < n && i < m);
}

BigInteger min_(BigInteger a, BigInteger b) {
	return ( (a < b) ? (a) : (b));
}

int main() {
	freopen(name".in","r",stdin);
	freopen(name".out","w",stdout);


	cin >> n >> m;

	for (int i = 0; i < n; ++ i) {
	 	for (int j = 0; j < m; ++ j) {
	 	 	cin >> X;
	 	 	a[i][j] = Int_Big(X);
	 	 	mas[i][j] = BigInteger(MAX);
	 	}
	}
	cin >> S;


	N = 200;
	int uk = 1;
	for (int i = 0; i < N; ++ i) {
	 	k[i][i] = Int_Big(1);
	 	k[0][i] = Int_Big(1);
	 	if (i != 0) {
	 		k[i-1][i] = Int_Big(uk);
	 		uk ++;
	 	}
	}

	for (int l = 3; l <= N; ++ l) {
		for (int i = 1; i < N - l + 1; ++ i) {
			int j = i + l - 1;
			k[i][j] = k[i][j-1] + k[i-1][j-1];
	 	}	
	}

	mas[0][0] = BigInteger(x);

	for (int i = 0; i < n; ++ i) {
	 	for (int j = 0; j < m; ++ j) {
	 		if (i == 0 && j == 0) continue;
 	 		if (i-1 >= 0) {
 	 	 		mas[i][j] = min_(mas[i][j], mas[i-1][j]*k[min(i,j)][max(i,j)] + a[i][j]);
 	 	 	}
 	 	 	if (j-1 >= 0) {
 	 	 		mas[i][j] = min_(mas[i][j], mas[i][j-1]*k[min(i,j)][max(i,j)] + a[i][j]);
 	 	 	}
 	 	 	if (j+1 < m) {
 	 	 		mas[i][j] = min_(mas[i][j], mas[i][j+1]*k[min(i,j)][max(i,j)] + a[i][j]);
 	 	 	}
	 	}
	}

	vector<int> ss;
	for (int i = 0; i < SZ(S); ++ i) {
		ss.PB(S[i]-'0');
	}
	s = BigInteger(ss);

	if (mas[n-1][m-1] < s) {
		cout << s - mas[n-1][m-1];
	} else {
		cout <<"-"<< mas[n-1][m-1] - s;
	}

	return 0;
}
