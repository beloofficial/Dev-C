#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <cstdio>
#include <cstdlib>
#include <math.h>
#include <string>
#include <string.h>
#include <vector>
#include <queue>
#include <deque>
#include <list>
#include <set>
#include <map>
#include <algorithm>
#include <limits>
#include <utility>

#define FOR(i,a,b) for (int i=a; i<=b; i++)
#define FORD(i,a,b) for (int i=a; i>=b; i--)
#define INF numeric_limits <int> :: max()
#define p_b push_back
#define m_p make_pair

using namespace std;
map <int, bool> bo;
int a[100001],n,m,l,r;

  int dif(int l, int r)
   {
   int ans=0;
   bo.clear();
   FOR(i,l,r)
   if (!bo[a[i]]) ans++,bo[a[i]]=true;
   return ans;
   }

int main()
{
freopen("D.in","rt",stdin);
freopen("D.out","wt",stdout);
scanf("%d %d\n",&n,&m);
FOR(i,1,n) scanf("%d ",&a[i]);
scanf("\n");
FOR(i,1,m)
 {
  scanf("%d %d",&l,&r);
  printf("%d\n",dif(l,r));
 }

fclose(stdin); fclose(stdout);
return 0;
}    