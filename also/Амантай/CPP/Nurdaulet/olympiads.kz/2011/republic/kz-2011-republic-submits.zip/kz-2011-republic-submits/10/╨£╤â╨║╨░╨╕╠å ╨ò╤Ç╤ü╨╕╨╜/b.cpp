//Solution by Mukai Yersin
#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <ctime>
#include <cmath>
#include <map>
#include <set>

#define sz 2000000
#define nsz 2000
#define fname "B."
#define sqr(w) ((w)*(w))
#define maxint (1<<30)

using namespace std;
struct st
{
 	int t[100][100];
}d;

int n,a[100][100],i,j,maxx,ans[100],o[100][100];

void rec(int x,st d)
{
	/*
	for (int i=1;i<=n;i++,printf("\n"))
				for (j=1;j<=n;j++)
					printf("%d ",d.t[i][j]);
	cout<<endl;	     
	*/
	if (x>n)
		{
			/*
			for (int i=1;i<=n;i++,printf("\n"))
				for (j=1;j<=n;j++)
					printf("%d ",d.t[i][j]);
			cout<<endl;    
			*/
			int sum=0;
			for (int i=1;i<=n;i++)
				for (j=1;j<=n;j++)
					if (d.t[i][j]==-1)
						sum+=a[i][j];
			if (maxx<sum)
				{
					maxx=sum;
				 	for (int i=1;i<=n;i++)
				 		{
				 		 	for (j=1;j<=n;j++)
				 		 		if (d.t[i][j]==-1) break;
				 		 	ans[i]=j;
				 		}
				}
		 	return;
		}
	int ok=0;
 	for (int i=1;i<=n;i++)
 		if (d.t[i][x]==0)	
 			{
 				st c=d;
 				ok=1;
 			 	for (int j=1;j<=n;j++)
 			 		if (c.t[i][j]==0)
 			 		c.t[i][j]=1;
 			    	int j=x,i1=i;
 			 	while (i<n&&j<n)
 			 		{
 			 		 	i1++,j++;
 			 		 	if (c.t[i1][j]==0)
 			 		 	c.t[i1][j]=1;
 			 		}
 			 	j=x,i1=i;
 			   	while (i>1&&j<n)
 			   		{
 			   		 	i1--,j++;
 			   		 	if (c.t[i1][j]==0)
 			   		 	c.t[i1][j]=1;
 			   		}
 			   	c.t[i][x]=-1;
 			    	rec(x+1,c);
 			}
    	if (!ok) return;
}
int main()
{
	freopen(fname"in","r",stdin);
	freopen(fname"out","w",stdout);
	 	scanf("%d",&n);
	 	for (i=1;i<=n;i++)
	 		for (j=1;j<=n;j++)
	 			scanf("%d",&a[i][j]);
	 	maxx=-1;
	 	rec(1,d);
	 	for (i=1;i<=n;i++)
	 		o[i][ans[i]]=1;
		for (i=1;i<=n;i++,printf("\n"))
			for (j=1;j<=n;j++)
				printf("%d ",o[i][j]);	
	return 0;
}
