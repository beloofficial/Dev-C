#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <ctime>

using namespace std;

#define N 300000

int n, m, top, u, v;
int h[N], w[N], to[2*N], ne[2*N];
int x[N], y[N];

//Timing
int curtime;
int deep[N], lt[N], rt[N];

//LCA
int kol;
int ver[10*N], minpos[10*N], first[N];

//Queries
int predcol[N], pred[N];
int s[10*N], push[10*N];

void newedge (int u, int v) {to[top] = v; ne[top] = h[u]; h[u] = top++;}

void buildtree (int u)
{
	w[u] = 1;
	lt[u] = rt[u] = ++curtime;
	for (int i = h[u]; i != -1; i = ne[i])
		if (!w[to[i]])
		{
		 	pred[to[i]] = u;
		 	deep[to[i]] = deep[u]+1;

		 	ver[++kol] = u;
		 	if (!first[u]) first[u] = kol;

		 	buildtree (to[i]);

		 	rt[u] = rt[to[i]];
		}
	ver[++kol] = u;
 	if (!first[u]) first[u] = kol;
}

void buildmintree (int l, int r, int v)
{
	if (l == r) minpos[v] = ver[l];
	else
	{
		buildmintree (l, (l+r)>>1, v<<1);
		buildmintree (((l+r)>>1)+1, r, (v<<1)+1);
		if (deep[minpos[v<<1]] < deep[minpos[(v<<1)+1]])
			minpos[v] = minpos[v<<1];
		else
			minpos[v] = minpos[(v<<1)+1];
	}
}

int getmin (int l, int r, int ls, int rs, int v)
{
	if (r < ls || rs < l) return 0;
	if (ls <= l && r <= rs) return minpos[v];

	int v1 = getmin (l, (l+r)>>1, ls, rs, v<<1);
	int v2 = getmin (((l+r)>>1)+1, r, ls, rs, (v<<1)+1);

	if (deep[v1] <= deep[v2]) return v1;

	return v2;
}

void pushfrom (int u, int l, int r)
{
	s[u] += (r-l+1)*push[u];
	if (u+u < 10*N) push[u<<1] += push[u];
	if (u+u+1 < 10*N) push[(u<<1)+1] += push[u];
	push[u] = 0;
}

void upd (int l, int r, int ls, int rs, int v, int delta)
{
	if (push[v]) pushfrom (v, l, r);
	if (r < ls || rs < l) return;
	if (ls <= l && r <= rs)
	{
		push[v] = delta;
		pushfrom (v, l, r);
   }
   else
   	upd (l, (l+r)>>1, ls, rs, v<<1, delta),
   	upd (((l+r)>>1)+1, r, ls, rs, (v<<1)+1, delta);
}

int sum (int l, int r, int v, int P)
{
	if (push[v]) pushfrom (v, l, r);
	if (l > P || P > r) return 0;
	if (l == P && l == r) return s[v];
	return sum (l, (l+r)>>1, v<<1, P)+sum (((l+r)>>1)+1, r, (v<<1)+1, P);
}

int main ()
{
	freopen ("F.in", "r", stdin);
	freopen ("F.out", "w", stdout);

	scanf ("%d%d", &n, &m);

	memset (h, -1, sizeof (h));
	top = 0;
	for (int i = 0; i < m; i++)
	{
		scanf ("%d%d", &u, &v);
		x[i] = u; y[i] = v;

		newedge (u, v);
		newedge (v, u);
	}

	deep[0] = 1000000000;
	buildtree (1);

   buildmintree (1, kol, 1);

   scanf ("%d\n", &m);

   int ep, u, v, can, lca, ls, rs, val;
   for (char quer; m--;)
   {
		scanf ("%c", &quer);

		if (quer == 'q')
		{
			scanf ("%d%d%d\n", &u, &v, &can); can--;
			ls = first[u]; rs = first[v];
			if (ls > rs) swap (ls, rs);
			lca = getmin (1, kol, ls, rs, 1);
			val = sum (1, n, 1, lt[u])+sum (1, n, 1, lt[v])-2*sum (1, n, 1, lt[lca]);
			if (!can) val = deep[u]+deep[v]-2*deep[lca]-val;
			printf ("%d\n", val);
      }
      else
      {
      	scanf ("%d%d\n", &can, &ep); ep--; can--;
      	if (pred[x[ep]] != y[ep]) swap (x[ep], y[ep]);

			if (predcol[x[ep]] != can)
			{
				upd (1, n, lt[x[ep]], rt[x[ep]], 1, (can?1:-1));
				predcol[x[ep]] = can;
			}
      }
   }

	return 0;
}
