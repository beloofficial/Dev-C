//Kushibar Kaisar
#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include <cctype>
#include <cstdio>
#include <ctime>
#include <cmath>
#include <set>
#include <map>
#include "dist.h"

using namespace std;

int x, y, l;
double d, d1, d2, d3, d4;

int main(){
	start();
	x=0; y=0;
	d=dist(x, y);
	while((int)d>0){
		l=(int)d;
		d1=dist(x+l, y);
		d2=dist(x, y+l);
		d3=dist(x-l, y);
		d4=dist(x, y-l);
		if(d1<=d2 && d1<=d3 && d1<=d4)x+=l, d=d1; else 
		if(d2<=d1 && d2<=d3 && d2<=d4)y+=l, d=d2; else 
		if(d3<=d2 && d3<=d1 && d3<=d4)x-=l, d=d3; else 
		y-=l, d=d4;
	}
	finish(x, y);
	return 0;
}
