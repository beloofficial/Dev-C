#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include <set>

using namespace std;

#define pb push_back()
#define fi first
#define se second

int a[1000000];

int main(){
	freopen ("D.in", "r", stdin);
	freopen ("D.out", "w", stdout);
	int n, m;
	cin >> n >> m;
	for (int i = 0;i < n;i++)
		cin >> a[i];
	for (int i = 0;i < m;i++){
		int l, r;
		set < int > s;
		cin >> l >> r;
		for (int i = l - 1;i < r;i++)
			s.insert(a[i]);
		cout << s.size() << endl;
	}
}