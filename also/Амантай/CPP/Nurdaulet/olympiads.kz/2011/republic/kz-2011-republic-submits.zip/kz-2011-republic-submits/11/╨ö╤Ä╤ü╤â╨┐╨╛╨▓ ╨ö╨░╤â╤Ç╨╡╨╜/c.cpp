// Dyussupov Dauren 11 class Atyrau
#include<cstdio>
#include<iostream>
#include<cmath>
#include<cstdlib>
#include<cstring>
#include<set>
#include<map>
#include<vector>
#include<algorithm>

using namespace std;

#define F first
#define S second
#define sf scanf
#define pf printf

int N, M, v[600], vv[600], st[600], st2[600], a[600][600], len[600];
bool was[600];

void print()
{
	printf("%d %d %d\n", N + M, N, M);

	for (int i = 1; i <= N; i++) cout << v[i] << " "; cout << endl;
	for (int i = 1; i <= M; i++) cout << vv[i] << " "; cout << endl;
	exit(0);
}

int main()
{
	freopen("C.in", "r", stdin);
	freopen("C.out", "w", stdout);

	int n, m, x, i, j, k, cur, cur2;

	sf("%d%d", &n, &m);

	for (i = 1; i <= n; i++)
	{
		sf("%d", &len[i]);
		for (j = 1; j <= len[i]; j++) 
		{
		sf("%d", &x);
		a[i][x] = a[x][i] = 1;
		st[i]++;
		st2[x]++;
		}
	}

	if (n > m) 
	{
		N = n;

		for (i = 1; i <= m; i++) 
		if (!st2[i])
		{
			vv[++M] = i;
		}

		for (i = 1; i <= n; i++) v[i] = i;

		if (m > 20 || 1ll * (1 << m) * n * m > 300000000ll) print();

		x = (1 << m);

		for (i = 1; i < x; i++)
		{
			cur = cur2 = 0;
			for (j = 1; j <= n; j++) was[j] = 1;

			for (j = 1; j <= m; j++)
				if (i & (j - 1))	
				{
					cur++;
					for (k = 1; k <= n; k++) if (a[k][j]) was[k] = 0; 
                }

            for (j = 1; j <= n; j++) cur2 += was[j];

            if (N + M < cur + cur2)
            {
            	N = M = 0;
            	for (j = 1; j <= m; j++) if (i & (j - 1)) vv[++M] = j;
            	for (j = 1; j <= n; j++) if (was[j]) v[++N] = j;
            }
		}

		print();
	}  else
	{
		M = m;

		for (i = 1; i <= n; i++)
		if (!st[i])
		{
			v[++N] = i;
		}

		for (i = 1; i <= m; i++) vv[i] = i;

		if (n > 20 || 1ll * (1 << n) * n * m > 300000000ll) print();

		x = (1 << n);

		for (i = 1; i < x; i++)
		{
			cur = cur2 = 0;
			for (j = 1; j <= m; j++) was[j] = 1;

			for (j = 1; j <= n; j++)
				if (i & (j - 1))	
				{
					cur++;
					for (k = 1; k <= m; k++) if (a[k][j]) was[k] = 0; 
                }

            for (j = 1; j <= m; j++) cur2 += was[j];

            if (N + M < cur + cur2)
            {
            	N = M = 0;
            	for (j = 1; j <= n; j++) if (i & (j - 1)) v[++N] = j;
            	for (j = 1; j <= m; j++) if (was[j]) vv[++M] = j;
            }
		}

		print();
	}

	return 0;
}