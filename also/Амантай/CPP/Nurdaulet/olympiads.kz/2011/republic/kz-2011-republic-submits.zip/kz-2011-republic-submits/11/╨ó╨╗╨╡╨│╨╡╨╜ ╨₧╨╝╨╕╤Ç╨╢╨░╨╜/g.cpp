
#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cmath>
#include <string>
#include <cstring>
#include <map>
#include <set>
#include <deque>
#include <queue>
#include <vector>

#include "dist.h"

using namespace std;

#define name 	""
#define INF 	int(1e9)
#define EPS		1e-9
#define SZ(x)	int(x.size())
#define ALL(x)	x.begin(), x.end()

int main() {

	start();

	int x, y = 0, XX, YY;
	int l = -INF, r = INF, m1, m2;

	int kol = 0;
	while (l < r) {
	 	m1 = l + (r - l)/3;
	 	m2 = r - (r - l)/3;

	 	kol += 2;
	 	if (dist(m2, y) - dist(m1, y) > EPS) {
	 	 	r = m2 - 1;
	 	} else {
			l = m1 + 1;
	 	}
	}

	XX = r;

	l = -INF, r = INF;
	x = 0;

	while (l < r) {
	 	m1 = l + (r - l)/3;
	 	m2 = r - (r - l)/3;

	 	kol += 2;
	 	if (dist(x, m2) - dist(x, m1) > EPS) {
	 	 	r = m2 - 1;
	 	} else {
			l = m1 + 1;
	 	}
	}

	YY = r;

	for (int i = YY-100; i <= YY+100; ++ i) {
		for (int j = XX-100; j <= XX+100; ++ j) {
			if (dist(i, j) == 0) {
			 	x = i, y = j;
			 	finish(x, y);
			 	return 0;
			}
		}
	}

	return 0;
}
