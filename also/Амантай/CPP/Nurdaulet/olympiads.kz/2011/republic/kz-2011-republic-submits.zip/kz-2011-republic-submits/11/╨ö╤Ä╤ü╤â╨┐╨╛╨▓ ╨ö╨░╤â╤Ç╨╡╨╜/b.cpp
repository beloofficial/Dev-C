// Dyussupov Dauren 11 class Atyrau
#include<cstdio>
#include<iostream>
#include<cmath>
#include<cstdlib>
#include<cstring>
#include<set>
#include<map>
#include<vector>
#include<algorithm>
#include<ctime>

using namespace std;

#define F first
#define S second
#define sf scanf
#define pf printf

int ans, n, a[20][20], b[20], c[20], cur, Msum; 
bool row[200], D1[200], D2[200];
clock_t start;

void print()
{
	for (int i = 1; i <= n; i++)
	{
		for (int j = 1; j <= n; j++)
			if (c[i] == j) pf("1 "); else pf("0 ");
		pf("\n");
	}
	exit(0);
}

void go(int x, int sum)
{
	if (x > n)
	{
		if (sum > ans)
		{
			ans = sum;
			for (int i = 1; i <= n; i++) c[i] = b[i]; 
			if (ans == Msum) print();
		}
		if (double(clock() - start) / CLOCKS_PER_SEC >= 1.95) print();
		return;
	}

	for (int i = 1; i <= n; i++)
		if (!row[i] && !D1[x + i] && !D2[x - i + 100])
		{
			row[i] = D1[x + i] = D2[x - i + 100] = 1;
			b[x] = i;
			go(x + 1, sum + a[x][i]);
			b[x] = 0;
			row[i] = D1[x + i] = D2[x - i + 100] = 0;
		}
}

int main()
{
	freopen("B.in", "r", stdin);
	freopen("B.out", "w", stdout);

	start = clock();

	int i, j, cur;

	sf("%d", &n);

	for (i = 1; i <= n; i++)
	{
		cur = -1;
		for (j = 1; j <= n; j++)
		{	
			sf("%d", &a[i][j]);
			if (cur < a[i][j]) cur = a[i][j];
		}
		Msum += cur;
	}			

	go(1, 0);	
	print();

	return 0;
}