#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <ctime>

using namespace std;

#define N 30

int n;
int a[N][N], bestsum[N];
int x[N], xans[N];

int res, cur, iter;
bool w[N];
bool di1[N*N], di2[N*N];

void dfs (int u)
{
	if (bestsum[u]+cur <= res) return;

	if (u == n)
	{
		if (cur > res)
		{
			res = cur;
			for (iter = 0; iter < n; iter++)
				xans[iter] = x[iter];
		}
	}
	else
	{
		int i;
		for (i = 0; i < n; i++)
			if (!w[i] && !di1[u-i+n] && !di2[u+i])
			{
			 	w[i] = di1[u-i+n] = di2[u+i] = 1;
			 	x[u] = i;
			 	cur += a[u][i];
				dfs (u+1);
				cur -= a[u][i];
			 	w[i] = di1[u-i+n] = di2[u+i] = 0;
			}
	}
}

int main ()
{
	freopen ("B.in", "r", stdin);
	freopen ("B.out", "w", stdout);

	scanf ("%d", &n);

	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)
			scanf ("%d", &a[i][j]);

	for (int i = n-1; i >= 0; i--)
	{
		for (int j = 0; j < n; j++)
			bestsum[i] = max (bestsum[i], a[i][j]);
		bestsum[i] += bestsum[i+1];
	}
	dfs (0);

	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)
			printf ("%d%c", xans[i]==j?1:0, j+1==n?'\n':' ');

	return 0;
}
