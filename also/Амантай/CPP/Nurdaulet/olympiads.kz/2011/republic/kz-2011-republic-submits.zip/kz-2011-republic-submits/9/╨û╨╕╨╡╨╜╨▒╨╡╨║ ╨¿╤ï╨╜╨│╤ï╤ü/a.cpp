//Zhienbek Shyngys 9 Astana KTL
#include<iostream>
#include<utility>
#include<map>
#include<cmath>
#include<math.h>
#include<stdio.h>
#include<stdlib.h>
#include<algorithm>
#include<cstdio>
#include<cstdlib>
#include<fstream>
#include<string>
#include<string.h>
#include<sstream>
#include<limits>
#include<assert.h>
#define eps 1e-12
#define mp(x,y) make_pair(x,y)
#define inf numeric_limits<int> :: max()
#define For(i,a,b) for(int i=a;i<=b;i++)
#define FOR(i,a,b) for(int i=a;i>=b;i--)
using namespace std;

int n,m,k,s[101],a[101][101],b[101],p[101],c=0,summa=0,psum=0,co[21],w,ans=0,an1[101],an2[101];

int main()
{
 #ifndef ONLINE_JUDGE
  freopen("A.in","rt",stdin);
  freopen("A.out","wt",stdout);
 #endif
  
  scanf("%d%d%d\n",&n,&m,&k);
  For(i,1,n) 
   {
    scanf("%d",&p[i]);
    summa+=p[i];
   }
   p[n+1]=0;
  if (summa<=k)
   {
    For(i,1,n) printf("%d ",i);
    return 0;
   }
  scanf("\n");
  For(i,1,m) scanf("%d",&b[i]);
  scanf("\n");
  For(j,1,m)
   {
    string st;
    getline(cin,st);
    int i=0;
    while(i<st.length())
     {
    if (isdigit(st[i]))
     {
      if (isdigit(st[i+1]))
       {
        a[j][0]++;
        a[j][a[j][0]]=int(st[i]-48)*10+int(st[i+1]-48);
        i+=2;
        continue;
       }
      a[j][0]++;
      a[j][a[j][0]]=int(st[i]-48);
      i++;
      continue;
     }
    i++;
   } 
 } 
  int t,d=-1,ma=0;
  while (t!=0)
   {
    d++;
    w=d;
    memset(co,0,20);
    memset(an1,0,20);
    psum=0;
    ans=0;
    t=0;
    while (w!=n+1)
     {
    w++;
    t++;
    s[t]=w;
    psum+=p[w];
    if (psum>k) 
     {
      For(i,1,m)
       {
        For(j,1,a[i][0])
         {
          if (a[i][j]==s[t-1]) 
           {
            ans-=b[i];
            co[i]--;
            an1[a[i][j]]=0;
           }
         }
       }
      psum-=(p[w]+p[w]);
      t-=2;
      w--;
      continue;
     }
    For(i,1,m)
     {
      For(j,1,a[i][0])
       {
        if (a[i][j]==s[t]) co[i]++, an1[a[i][j]]=1;
       }
      if (co[i]==a[i][0]) co[i]=0,ans+=b[i];
     }
    if (ma<ans)
     {
      ma=ans;
      For(i,1,n) an2[i]=an1[i];
     }
    }
   }
  For(i,1,n)
  if (an2[i]) printf("%d ",i);

 fclose(stdin);fclose(stdout);
 return 0;
}
