//Kushibar Kaisar
#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include <cctype>
#include <cstdio>
#include <ctime>
#include <cmath>
#include <set>
#include <map>

#define fname "H"
using namespace std;

int n, m;

int main(){
	freopen(fname".in","r",stdin);
	freopen(fname".out","w",stdout);
	scanf("%d%d", &n, &m);
	cout << 95 << endl;
	return 0;
}
