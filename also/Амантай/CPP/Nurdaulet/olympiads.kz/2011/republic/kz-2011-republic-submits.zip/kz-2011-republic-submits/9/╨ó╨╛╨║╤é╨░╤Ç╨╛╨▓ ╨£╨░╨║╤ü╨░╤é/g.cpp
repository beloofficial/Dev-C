//#include<brain.h>
#include<algorithm>
#include<iostream>
#include<utility>
#include<cstdlib>
#include<cstring>
#include<string>
#include<vector>
#include<cstdio>
#include<cmath>
#include<new>
#include<map>
#include<set>
using namespace std;
typedef long long ll;
const int inf = 2147483647;
#define max(a,b) ((a<b)?(b):(a))
#define min(a,b) ((a<b)?(a):(b))
#define abs(a) ((a<0)?(-(a)):a)
#define pb push_back
#define mp make_pair
#define F first
#define S second
#define N (int) 1e6
int n,p,i;
ll fact;
int main () {
	freopen("G.in","r",stdin);
	freopen("G.out","w",stdout);
	scanf("%d%d",&n,&p);
	fact = 1;
	for (i = 2; i<=n; i++) fact = ((fact % p) * i) % p; 
		cout<<fact<<endl;               
 return 0;
}