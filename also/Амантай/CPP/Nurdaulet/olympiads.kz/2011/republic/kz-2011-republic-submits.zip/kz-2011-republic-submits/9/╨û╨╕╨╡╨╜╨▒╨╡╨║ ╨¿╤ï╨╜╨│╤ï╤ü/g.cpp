//Zhienbek Shyngys 9 Astana KTL
#include<iostream>
#include<utility>
#include<map>
#include<cmath>
#include<math.h>
#include<stdio.h>
#include<stdlib.h>
#include<algorithm>
#include<cstdio>
#include<cstdlib>
#include<fstream>
#include<string>
#include<string.h>
#include<sstream>
#include<limits>
#include<assert.h>
#define For(i,a,b) for(long long i=a;i<=b;i++)
using namespace std;

long long n,p,ans=1;

int main()
{
 #ifndef ONLINE_JUDGE
  freopen("G.in","rt",stdin);
  freopen("G.out","wt",stdout);
 #endif
  
  scanf("%I64d%I64d",&n,&p);
  For(i,1,n) ans=ans*i%p;
  printf("%I64d",ans%p);

 fclose(stdin);fclose(stdout);
 return 0;
}
