// Dyussupov Dauren 11 class Atyrau
#include<cstdio>
#include<iostream>
#include<cmath>
#include<ctime>
#include<cstdlib>
#include<cstring>
#include<set>
#include<map>
#include<vector>
#include<algorithm>

using namespace std;

#define F first
#define S second
#define sf scanf
#define pf printf

int need[30][30], a[30], power[30], len[30];
bool was[30];

int main()
{
	freopen("A.in", "r", stdin);
	freopen("A.out", "w", stdout);

	int n, m, k, j, i, cur, x, pos = 0, sum, q;
	long long now = 0, ans = 0;
	string s;

	clock_t start = clock();

	sf("%d%d%d", &n, &m, &k);

	for (i = 0; i < n; i++) 
	{
		sf("%d", &a[i]);
		now += a[i];
	}

	if (now <= k)
	{
		for (i = 1; i <= n; i++) pf("%d ", i);
		exit(0);
	}

	for (i = 1; i <= m; i++) sf("%d", &power[i]);

	sf("\n");

	for (i = 1; i <= m; i++)
	{
		cur = 0;
		getline(cin, s);

		for (j = 0; j < s.size(); j++)
			if (s[j] == ' ')
			{
				if (cur) need[i][++len[i]] = cur;
				cur = 0;
			} else
				cur = cur * 10 + (s[j] - '0');
	    if (cur) need[i][++len[i]] = cur;
	}

	for (i = 1; i <= m; i++)
	{
		sum = 0, cur = 0;
		for (j = 1; j <= len[i]; j++)
		{
			sum += a[need[i][j] - 1];
			cur |= 1 << (need[i][j] - 1);
			if (sum > k) break;
		}
		if (sum <= k && ans < power[i])
		{
			ans = power[i];
			pos = cur;
        }
	}

	x = (1 << n);
	
	for (i = x - 1; i > 0; i--)
	{
		sum = 0;
		for (j = 0; j < n; j++)
			if (i & (1 << j))
			{
				sum += a[j];
				if (sum > k) break;
				was[j + 1] = 1;
			} else 
				was[j + 1] = 0;

		if (j < n) continue;

		now = 0;

		for (q = 1; q <= m; q++)
		{
			for (j = 1; j <= len[q]; j++)
			if (!was[need[q][j]]) break;

			if (j > len[q]) now += power[q]; 
		}

		if (now > ans)
		{
			ans = now;
			pos = i;
		}
		if (double(clock() - start) / CLOCKS_PER_SEC >= 1.95) break;
	}

	for (i = 0; i < n; i++)
		if (pos & (1 << i)) pf("%d ", i + 1);

	return 0;
}