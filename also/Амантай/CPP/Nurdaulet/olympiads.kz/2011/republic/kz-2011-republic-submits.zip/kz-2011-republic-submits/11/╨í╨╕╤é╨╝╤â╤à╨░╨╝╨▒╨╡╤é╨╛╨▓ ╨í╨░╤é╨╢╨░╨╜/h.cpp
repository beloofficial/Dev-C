#include <cstdio>
#include <algorithm>
#include <cstring>
const int N = 209;
using namespace std;
int qx[199999], qy[199999], o[] = {0, 1, 0, -1, 1, 0};
struct Long {
	int a[N], l, p;
	Long () { int i; l = p = 1;  a[0] = 0; }
	void fill1()  {
		int i;
		for (i = 0; i < 20; i++)
			a[i] = 0;
	}
	void in() {                         
		int i;	        p = 1;
		char s[1009];
		scanf("%s", s);
		l = strlen(s);
		for (i = 0; i < l; i++)
			a[i] = s[l - 1 - i] - 48;
	}	
	void out2() {
		int i;
	//	if (p != 1) printf("-");
		for (i = l - 1; i >= 0; i--)
			printf("%d", a[i]);
		printf(" ");
	} 
	void out() {
		int i;
		if (p != 1) printf("-");
		for (i = l - 1; i >= 0; i--)
			printf("%d", a[i]);
		puts("");
	}
	Long operator = (int x) { p = 1;
		l = 1;
		Long res; 
		res.a[0] = a[0] = x; res.l = res. p = 1;
		return res;
	} 
	Long operator + (Long x) {
		Long res;
		int i, c = 0;
		res = x;     
		for (i = 0; i < l; i++) {
			c += a[i] + res.a[i];
			res.a[i] = c % 10;
			c /= 10;
		}
		if (l < x.l) {
			res.a[l] += c;
			for (i = l; a[i] > 9; i++)
				a[i] = 0, a[i + 1]++;
			if (res.l < i) res.l = i;
	    }
	    else {
	    	res.a[l] = c;
	    	res.l = l + c;
	    }
		return res;
	}
	Long operator * (Long x) {
		Long res;
		int k, i, j, c = 0;
		res = 0;
		res.l = l * x.l;
		for (i = 0; i < res.l + 3; i++)
			res.a[i] = 0;
		for (i = 0; i < l; i++) {
			for (j = 0; j < x.l; j++) {
				k = i + j;
				c = res.a[k] + a[i] * x.a[j] + c;
				res.a[k] = c % 10;
				c /= 10;
			}
			for (k++; c > 0; c /= 10) {
				c += res.a[k];
				res.a[k] = c % 10;
				k++;
			}
			res.l = k;
		}
		return res;
	}	
	bool operator > (Long x) {
		if (l > x.l) return 1;
		if (l < x.l) return 0;
		for (int i = l - 1; i >= 0; i--) {
			if (a[i] > x.a[i]) return 1;
			if (a[i] < x.a[i]) return 0;
		}
		return 0;
	}		
	void operator -= (Long x) {
		int i, c;
		for (i = 0; i < l; i++) {
			c = a[i] - x.a[i];
			if (c < 0) {
				c += 10;
				a[i + 1]--;
			}
			a[i] = c;
			if (a[l - 1] == 0) l--;
		}
		if (l == 0) l = 1;
	}	
};                 
Long b[N][N], c[N][N], a[N][N];

int n, m;
bool u[N][N];
bool ok1(int x, int y) {
	return (1 <= x && x <= n && 1 <= y && y <= m);
}          
int main () {
	freopen("H.in", "r", stdin);
	freopen("H.out", "w", stdout);
	int i, j, l, r, x, y, xx, yy;
	bool nn;
	Long t, ans;
	scanf("%d %d", &n, &m);
	for (i = 1; i <= n; i++)
		for (j = 1; j <= m; j++) 
			a[i][j].in();
		
//	printf("%d %d\n", n, m);
	ans.in();  // scanf("%I64d", &ans);
//	ans.out();
	x = max(200, m);
//	printf("x = %d\n", x);
	for (i = 1; i <= x; i++) b[i][1] = b[1][i] = b[i][i] = 1;
//	b[100][200].out();
//	for (i = 1; i <= 10; i++) {
//		for (j = 1; j <= 10; j++)
//			b[i][j].out2();
//		puts("");
//	} puts("");
	for (i = 2; i <= x; i++) 
		for (j = i + 1; j <= x; j++)  
			b[i][j] = b[j][i] = b[i - 1][j - 1] + b[i][j - 1];
	//for (i = 1; i <= 10; i++) {
	//	for (j = 1; j <= 10; j++)
//			b[i][j].out2();
//		puts("");
//	} puts("");
//	b[100][200].out();
		// bfs
		qx[1] = qy[1] = l = r = u[1][1] = 1;
		for ( ; l <= r; l++) {
			xx = qx[l]; yy = qy[l];
			for (i = 0; i < 6; i += 2) {
				x = xx + o[i]; y = yy + o[i + 1];
				if (ok1(x, y)) {
				//	printf("x = %d y = %d\n", x, y);
					nn = 0;
					t = c[xx][yy] * b[x][y] + a[x][y];
					if (u[x][y] == 0) {
						u[x][y] = 1;
						nn = 1;
						c[x][y] = t; 
					}
					else 
						if (c[x][y] > t) {
							nn = 1; 
							c[x][y] = t;
						}
					if (nn) {
					//	printf("x = %d y = %d\n", x, y);
					
						r++;
						qx[r] = x;
						qy[r] = y;
				    }
				}
	   		}
	   	}
	    //done

//	for (i = 1; i <= n; i++) {
	//	for (j = 1; j <= m; j++) 
   // 		c[i][j].out2();
   // 	puts("");
	//} puts("");
	t = c[n][m];
//	t.out();
	if (t > ans) {
		swap(t, ans);
		ans.p = 0;
	}
	ans -= t;
	ans.out();  //printf("%I64d", ans); */
}	


