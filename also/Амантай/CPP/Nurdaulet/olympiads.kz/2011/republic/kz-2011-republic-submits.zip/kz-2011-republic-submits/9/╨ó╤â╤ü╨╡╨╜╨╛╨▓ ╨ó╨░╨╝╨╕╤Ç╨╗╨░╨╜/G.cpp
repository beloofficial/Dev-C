#include<iostream>
#include<cstdio>
using namespace std;

int n,p;
long long int res=1;
int main()
{

freopen("G.in","r",stdin);
freopen("G.out","w",stdout);

scanf("%d%d",&n,&p);

for(int i=1;i<=n;i++){
res*=i;
res%=p;}

printf("%lld",res);






return 0;
}

