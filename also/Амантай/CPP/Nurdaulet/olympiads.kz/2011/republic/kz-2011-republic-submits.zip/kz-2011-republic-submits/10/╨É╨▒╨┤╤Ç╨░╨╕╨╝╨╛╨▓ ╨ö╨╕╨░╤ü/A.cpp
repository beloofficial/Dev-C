#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <cstdio>
#include <cstdlib>
#include <math.h>
#include <string>
#include <string.h>
#include <vector>
#include <queue>
#include <deque>
#include <list>
#include <set>
#include <map>
#include <algorithm>
#include <limits>
#include <utility>

#define FOR(i,a,b) for (int i=a; i<=b; i++)
#define FORD(i,a,b) for (int i=a; i>=b; i--)
#define INF numeric_limits <int> :: max()
#define p_b push_back
#define m_p make_pair

using namespace std;
int n,m,k,w[30],p[30],a[30][30],num,l,sz[30];
string st;
vector <int> ::iterator it;
vector <int> v,ans;
long long sum,mx=0,ss;
bool bo,used[30];

  bool bit(int x, int i)
   {
    if (i>m) return 0;
    if ( (x & (1<<i)) ==0) return 0; else return 1;
   }

int main()
{
freopen("A.in","rt",stdin);
freopen("A.out","wt",stdout);
 scanf("%d %d %d\n",&n,&m,&k);
 FOR(i,1,n) scanf("%d",&w[i]);
 scanf("\n");
 FOR(i,1,m) scanf("%d",&p[i]);
 scanf("\n");

 FOR(i,1,m)
  {
    getline(cin,st);
    l=0;
     for (int j=0; j<st.length(); j++)
     {
     num=0;
     for (; st[j]!=' ' && j<st.length(); j++)
      {
      num=num*10+st[j]-48;
      }
     a[i][++l]=num;
     }
     sz[i]=l;
  }

//  FOR(i,1,m) cout<<sz[i]<<" ";
 FOR(i,0,(1<<m)-1)
  {
  memset(used,false,sizeof(used));
  sum=ss=0; v.clear();
  bo=true;

   FOR(k,1,m) 
   {
   if (bit(i,k-1))
    {
     FOR(j,1,sz[k])
     if (!used[a [k] [j]]) 
     {
     used[a [k] [j] ] =true; 
     sum=sum+ ((long long) p[ a [k] [j] ]);
     ss+= ((long long )w[ a[k][j] ]);
     v.p_b( a[k] [j]); 
     } else { bo=false; break; }
    }

   
    if (bo && sum>mx && ss<=k) mx=sum,ans=v;
//   cout<<bit(i,k-1)<<" ";
   }
//   cout<<bo<<" "<<ss<<" "<<sum<<"\n";

//   for (it=v.begin(); it!=v.end(); it++) cout<<*it<<" ";
//   cout<<"\n";
//   cout<<endl<<"---- "<<bo<<"\n";
//     FOR(p,1,m) cout<<used[p]<<" ";
//     cout<<"\n\n";

  }


  for (it=ans.begin(); it!=ans.end(); it++) cout<<*it<<" ";
fclose(stdin); fclose(stdout);
return 0;
}    