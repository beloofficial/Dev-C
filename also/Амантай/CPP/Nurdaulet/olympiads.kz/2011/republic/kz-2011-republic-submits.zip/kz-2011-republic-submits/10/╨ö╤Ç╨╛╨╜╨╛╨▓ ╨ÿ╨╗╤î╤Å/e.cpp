#include <cstdio>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <algorithm>

using namespace std;

int main() {
    freopen("e.in", "r", stdin);
    freopen("e.out", "w", stdout);
    long long a, b, c, l, r, s, p, x;
    int i;
    cin >> a >> b >> c >> l >> r >> p;
    s = 0;
    for (int i = l; i <= r; i++){
    	x = i;
	s += (((((x - a) % p) * (x - b) % p) % p) * (x - c) % p) % p;
	s = s % p;
    }
    cout << s % p;
    return 0;
}
