//Solution by Mukai Yersin
#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <ctime>
#include <cmath>
#include <map>
#include <set>

#define sz 2000000
#define nsz 2000
#define fname "F."
#define sqr(w) ((w)*(w))
#define maxint (1<<30)

using namespace std;
struct graf
{
	int next,val,ves;
} a[sz];
int n,m,k,x,y,head[sz],c[sz],ans,t,i;
char ch;

void read(int x,int y,int i,int v)
{
	a[i].val=y;
	a[i].next=head[x];
	a[i].ves=v;
	head[x]=i;
}      

void dfs(int v,int s)
{
//	cout<<v<<' '<<s<<endl;
	if (v==y) 
		{
			ans=s;
			return;
		}	
   	c[v]=1;
   	for (int i=head[v];i!=-1;i=a[i].next)
   		{
   			int l=s;
   			if (a[i].ves==t) l++;
   			if (!c[a[i].val]) dfs(a[i].val,l);
   		}	
}

int main()
{
	freopen(fname"in","r",stdin);
	freopen(fname"out","w",stdout);
	   	scanf("%d %d\n",&n,&m);
	   	for (i=1;i<=n;i++)
	   		head[i]=-1;
	   	for (i=1;i<=m;i++)
	   		{
	   		 	scanf("%d %d\n",&x,&y);
	   		 	read(x,y,i,1);
	   		 	read(y,x,i+m,1);
	   		}
	   	scanf("%d\n",&k);
	   	for (i=1;i<=k;i++)
	   		{
	   		 	scanf("%c",&ch);
	   		 	if (ch=='q')
	   		 		{
	   		 			scanf("%d %d %d\n",&x,&y,&t);
	   		 			memset(c,0,sizeof(c));
	   		 			dfs(x,0); 		
	   		 			printf("%d\n",ans);
	   		 		}
	   		 		else
	   		 		{
	   		 		   	scanf("%d %d\n",&x,&y);
	   		 		   	a[y].ves=x;
	   		 		   	a[y+m].ves=x;
	   		 		}
	   		}
	return 0;
}
