#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <string>
#include <cstring>
#include <set>
#include <map>
#include <stdio.h>

#define pb push_back
#define mp make_pair
#define se second
#define fi first
#define all(a) a.begin(),a.end()
#define name "C"

using namespace std;

int n,m,k,y,id1,maxs,maxs1,id;
vector<int> a[1000],b[1000];
int aa[1000],bb[1000];

bool check() {
	for(int i = 1; i <= n; ++ i)
		if(a[i].size() != 0)
			return 0;

	for(int i = 1; i <= m; ++ i)
		if(b[i].size() != 0)
			return 0;
	return 1;
}

void find_max_a(int &maxs,int &id) {
	for(int i = 1; i <= n; ++ i)	
		if(a[i].size() > maxs) {
			maxs = a[i].size();
			id = i;
		}
}

void find_max_b(int &maxs1,int &id1) {
	for(int i = 1; i <= m; ++ i)	
		if(b[i].size() > maxs1) {
			maxs1 = a[i].size();
			id1 = i;
		}
}

int main() {

	freopen(name".in","r",stdin);
	freopen(name".out","w",stdout);	
    
    cin >> n >> m;
    
    for(int i = 0; i < n; ++ i) {
    	cin >> k;
    	for(int j = 0; j < k; ++ j) {
    		cin >> y;
    		a[i+1].pb(y);
    	}
    }
/*
    if(n == 3 && m == 2) {
    	cout << "3 2 1\n1 3\n2";
    	return 0;
    }
*/
    for(int i = 0; i < m; ++ i) {
    	cin >> k;
    	for(int j = 0; j < k; ++ j) {
    		cin >> y;
    		b[i+1].pb(y);
    	}
    }

    while(!check()) {
    	maxs = 0;
    	id = 0;
    	maxs1 = 0;
    	id1 = 0;
    	find_max_a(maxs,id);    	
    	find_max_b(maxs1,id1);
    	if(maxs > maxs1) {
    		for(int i = 1; i <= m; ++ i) {
    			for(int j = 0; j < b[i].size(); ++ j)
    				if(b[i][j] == id) {
                    	b[i].erase(b[i].begin()+j);
                    	break;
                    }
    		}
    		a[id].clear();
    		aa[id] = 1;
    	} else {
    		for(int i = 1; i <= n; ++ i) {
    			for(int j = 0; j < a[i].size(); ++ j)
    				if(a[i][j] == id1) {
                    	a[i].erase(a[i].begin()+j);
                    	break;
                    }
    		}
    		b[id1].clear();
    		bb[id1] = 1;
    	}
    }

    int sum1 = 0,sum2 = 0;

    for(int i = 0; i < n; ++ i)
    	sum1 += 1 - aa[i+1];

    for(int i = 0; i < m; ++ i)
    	sum2 += 1 - bb[i+1];

    cout << sum1 + sum2 << ' ' << sum1 << ' '  << sum2 << "\n";	    
    for(int i = 0; i < n; ++ i)
    	if(aa[i+1] == 0)
    		cout << i + 1 << ' ';
    cout << "\n";
    for(int i = 0; i < m; ++ i)
    	if(bb[i+1] == 0)
    		cout << i + 1 << ' ';

 /*   cout << "\n";

    for(int i = 0; i < n; ++ i) {
    	for(int j = 0; j < a[i].size(); ++ j) {
    		cout << a[i+1][j] << ' ';
    	}
    	cout << "\n";
    }
   	cout << "\n";

    for(int i = 0; i < m; ++ i) {
    	for(int j = 0; j < b[i].size(); ++ j) {
    		cout << b[i+1][j] << ' ';
    	}
    	cout << "\n";
    }
*/
	return 0;
}

