//Zhienbek Shyngys 9 Astana KTL
#include<iostream>
#include<utility>
#include<map>
#include<cmath>
#include<math.h>
#include<stdio.h>
#include<stdlib.h>
#include<algorithm>
#include<cstdio>
#include<cstdlib>
#include<fstream>
#include<string>
#include<string.h>
#include<sstream>
#include<limits>
#include<assert.h>
#define mp(x,y) make_pair(x,y)
#define inf numeric_limits<int> :: max()
#define For(i,a,b) for(int i=a;i<=b;i++)
#define FOR(i,a,b) for(int i=a;i>=b;i--)
using namespace std;

int m,n,w[200001],s[200001],he[200001],ne[200001],res;
bool u[100001],b=0;

void dfs(int v,int y,int z,int p)
 {
  if (v==y || b==1) { return; b=1; }
  u[v]=1;
  int j=he[v];
  while (j)
   {
    if (!u[s[j]] && w[j]==z) res++;
    if (!u[s[j]]) dfs(s[j],y,z,v);
    if (b==1) return;
    j=ne[j];
   }
 }

int main()
{
 #ifndef ONLINE_JUDGE
  freopen("F.in","rt",stdin);
  freopen("F.out","wt",stdout);
 #endif
  
  scanf("%d%d\n",&n,&m);
  For(i,1,m) 
   {
    int x,y;
    scanf("%d%d\n",&x,&y);
    w[i]=1;
    w[i+m]=1;
    s[i]=y;
    s[i+m]=x;
    ne[i]=he[x];
    he[x]=i;
    ne[i+m]=he[y];
    he[y]=i+m;
   }
  int q;
  scanf("%d\n",&q);
  For(i,1,q)
   {
    char ch=getchar();
    b=0;
    memset(u,0,n);
    res=0;
    if (ch=='+')
     {
      int x,y;
      scanf("%d%d\n",&x,&y);
      w[i]=x;
     }
    if (ch=='q')
     {
      int x,y,z;
      scanf("%d%d%d\n",&x,&y,&z);
      dfs(x,y,z,-1);
      printf("%d\n",res);
     }
   }

 fclose(stdin);fclose(stdout);
 return 0;
}
