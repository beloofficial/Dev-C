#include <cstdio>
#include <iostream>

using namespace std;

int main() {
    freopen("e.in", "r", stdin);
    freopen("e.out", "w", stdout);

    long long a, b, c, l, r, p;
    long long sum = 0;

    cin >> a >> b >> c >> l >> r >> p;

    for (long long i = l; i<=r; i++){
    	sum += 	( (((i - a) % p) * ((i - b) % p) ) * (( i - c) % p )) % p;
    	sum %= p;
    }

    cout << sum % p;

    return 0;
}
