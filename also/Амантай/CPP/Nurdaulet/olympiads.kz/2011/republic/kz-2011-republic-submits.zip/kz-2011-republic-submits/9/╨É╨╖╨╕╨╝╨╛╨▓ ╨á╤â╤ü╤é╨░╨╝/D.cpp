#include<iostream>
#include<fstream>
#include<cstdio>
#include<vector>
#include<map>
#include<string>
using namespace std;
#define pb push_back
int main (){  
  
  freopen("D.in","r",stdin);
  freopen("D.out","w",stdout);
    int a[100005],n,m,x,y;
    scanf("%d", &n);
    scanf("%d", &m);
     map<int,int> l;
     for(int i=1;i<=n;i++)
       scanf("%d", &a[i]);
        for(int i=1;i<=m;i++)
          {
           scanf("%d %d", &x, &y);
           int d=y-x+1;
           for(int j=x;j<=y;j++)
             {
              if (l[a[j]]==1)
                 d--;
              else
              l[a[j]]++;
             }
             l.clear();
            printf("%d\n", d);  
          }
   return 0;
  }