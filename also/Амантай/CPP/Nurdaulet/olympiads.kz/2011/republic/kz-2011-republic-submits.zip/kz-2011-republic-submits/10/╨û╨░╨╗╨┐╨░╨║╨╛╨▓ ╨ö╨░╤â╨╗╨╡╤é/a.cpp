// Zhalpakov Daulet
#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
#include <vector>
#include <cmath>
#include <map>
#include <set>
using namespace std;

typedef long long ll;

char s[100000];
vector <int> a[100], res;
int n, m, k, w[100], c[100], g[100][100];
bool mask[100], was[100];
ll bestsum;
set <int> ans;
map <int, bool> temp;

void getlist (char *s, int i)
{
	for (int uk = 0, len = strlen(s), t; uk < len;) {
	    t = 0;

		while (isspace(s[uk]) && uk < len) uk++;
	
	    while (isdigit(s[uk]) && uk < len) t = t*10 + (s[uk]-'0'), uk++;
	
		a[i].push_back(t);
	}
}

void rec (int v, ll sum, ll weight)
{
	if (weight > k) return;
	if (v == m) {
		temp.clear();
		for (int i = 0; i < m; ++i)
			if (mask[i])
				for (int j = 0; j < a[i].size(); ++j)
					temp[a[i][j]] = 1;
		sum = 0;
		for (int i = 0; i < m; ++i) {
			bool ok = 1;
			for (int j = 0; j < a[i].size() && ok; ++j)
				if (temp.find(a[i][j]) == temp.end()) ok = 0;		
			sum += 1ll*ok*c[i];
		}
				
		if (sum > bestsum) {
			res.clear();
			for (int i = 0; i < m; ++i)
				if (mask[i]) 
					res.push_back(i);
			bestsum = sum;
		}

	    return;
	}

	bool ok = 1;
   	
   	if (ok) {		
	    ll curw = 0;
		for (int i = 0; i < a[v].size(); ++i)
			curw += w[a[v][i]];

   		mask[v] = 1;
		rec(v + 1, sum + c[v], weight + curw);
   	 	
   	 	mask[v] = 0;
	}
	
    rec(v + 1, sum, weight);
}

int main()
{
	freopen("A.in", "r", stdin);
	freopen("A.out", "w", stdout);

	scanf("%d%d%d", &n, &m, &k);
	for (int i = 1; i <= n; ++i)
		scanf("%d", &w[i]);

	for (int i = 0; i < m; ++i)
		scanf("%d", &c[i]);	
	scanf("\n");	
	
	for (int i = 0; i < m; ++i) {
		gets(s);

		getlist(s, i);
	}

	bestsum = -1;
	rec(0, 0, 0);

	for (int i = 0; i < res.size(); ++i) {
	    for (int j = 0; j < a[res[i]].size(); ++j)
			ans.insert(a[res[i]][j]);
	}
	
//	cout << bestsum << endl;

	for (set <int>::iterator it = ans.begin(); it != ans.end(); ++it)
		printf("%d ", *it);

	cout << endl;

	return 0;
}
