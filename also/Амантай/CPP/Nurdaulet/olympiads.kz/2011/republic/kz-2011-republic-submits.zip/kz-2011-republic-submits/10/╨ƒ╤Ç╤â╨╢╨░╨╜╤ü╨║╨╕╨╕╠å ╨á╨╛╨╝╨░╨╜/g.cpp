#include <cstdio>
#include <iostream>
#include "dist.h"
#include <cmath>
#define MAX 1000000000

using namespace std;

long double sq(long double a, long double b, long double c){
 	long double  p = a + b + c, s;
 	p /= 2;
 	s = sqrt(p) * sqrt(fabs(p - a)) * sqrt(fabs(p - b)) * sqrt(fabs(p - c));
 	return s;
}

int main() {
	start();

    long double d1 = dist(0, 0), d2 = dist(MAX / 2, 0), h = 2 * sq(d1, d2, MAX / 2) / (MAX / 2);

    if ( dist(0, h) > dist(0, -h) )
     	 h = (-h);

    long double dx = sqrt(fabs(d1*d1 - h*h));
    if ( dist(dx, 0) > dist(-dx, 0) ) 
    	dx = (-dx);

    finish(round(dx), round(h));

    return 0;
}
