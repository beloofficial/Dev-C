#include <iostream>
#include <ctime>
#include <vector>
#include <cstdlib>
#include <cstdio>
#include <algorithm>
#include <fstream>

using namespace std;


typedef long long ll;
typedef long double ld;
typedef vector<int> vi;

#define pb push_back
#define mp make_pair
#define sz size()
#define len length()
#define f first
#define s second

double Time () {
	return double(clock()) / double(CLOCKS_PER_SEC);
}
int u[200000]={0};

int main () 
{
	freopen ("D.in", "r", stdin);
	freopen ("D.out", "w", stdout);
	
	int a[200000], b[200000], l, r;
	int n, m;
	scanf ("%d %d", &n, &m);
	
	for (int i = 0; i < n; i++) scanf ("%d", &a[i]), b[i] = a[i];
	sort (b, b+n);
	int N = unique(b, b+n)-b;
	for (int i = 0; i < n; i++)
		a[i] = lower_bound(b,b+N,a[i])-b;
	for (int i = 0; i < m; ++i) {
		scanf ("%d %d", &l, &r);
		l--,r--;
		int res = 0;
		for (int j = l; j <= r; ++j)
			if (u[a[j]] != i+1) res++, u[a[j]] = i+1;
		printf ("%d\n", res);
	}
	return 0;
}