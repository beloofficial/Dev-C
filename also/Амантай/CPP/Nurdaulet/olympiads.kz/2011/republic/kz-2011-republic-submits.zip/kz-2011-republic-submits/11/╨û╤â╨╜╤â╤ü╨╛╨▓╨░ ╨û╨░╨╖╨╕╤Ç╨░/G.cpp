#include<iostream>
#include<algorithm>
#include<cstdio>
#include<string>
#include<cstring>
#include<cmath>
#include"dist.h"

using namespace std;

int main()
{
	start();

	double eps=0.000000001,dl,dr;
	int l,r,x,m,k=0;

    l=-1000000000;
    r=1000000000;

    while(l<r)
    {
    	m=(l+r)/2;

    	dl=dist(l,0);
    	dr=dist(r,0);

    	k+=2;

    	if(dl-dr>eps)  l=m+1;
    	else r=m;
    }

    x=l;

    l=-1000000000;
    r=1000000000;

    while(l<r)
    {
    	m=(l+r)/2;

    	dl=dist(x,l);
    	dr=dist(x,r);

    	k+=2;

    	if(dl-dr>eps)  l=m+1;
    	else r=m;
    }

    dl=dist(x,l);
    k++;
    while(abs(dl)>eps)  
    {
        if(dist(x-1,l)-dl<eps) { x--;  k++;}
        else
        if(dist(x+1,l)-dl<eps)  {x++;  k++;}
        else
        if(dist(x,l-1)-dl<eps)  {l--;   k++;}
        else  {l++; k++;}

        if(k==10000)  break;
    }

    finish(x,l);
    
	return 0;
}