#include<iostream>
#include<algorithm>
#include<cstdio>
#include<string>
#include<cstring>
#include<cmath>
#include<vector>
#include<stack>
#include<queue>
#include<map>
#include<set>

using namespace std;

int u[26],ans=0,c[26][26],n,m,a[27],k,b[27];
bool rez[26],anss[26];

void f(int v,int s,int z)
{
	int i,l;

	if((v>n)||(s==k))
	{
		if(z>ans)
		{
			ans=z;
			for(i=1;i<=n;i++)
				anss[i]=rez[i];
		}
	}
	else
	{
		f(v+1,s,z);
		
		if(a[v]+s<=k)
		{
			rez[v]=1;

			l=0;
			for(i=1;i<=m;i++)
				if(c[i][v]==1)  { u[i]++;  if(u[i]==c[i][0])  l+=b[i];}

			f(v+1,s+a[v],z+l);

			for(i=1;i<=m;i++)
				if(c[i][v]==1)  u[i]--;

			rez[v]=0;
		}
	}                
}

int main()
{
	freopen("A.in","r",stdin);
	freopen("A.out","w",stdout);

	int i,j,t,tt=0;
	string s;

	cin>>n>>m>>k;
	for(i=1;i<=n;i++)
	{
		cin>>a[i];
		if(a[i]<=k)	tt+=a[i];
	}
	for(i=1;i<=m;i++)
		cin>>b[i];

	scanf("\n");
	for(i=1;i<=m;i++)
	{
		getline(cin,s);

		for(j=0;j<s.length();j++)
			if(s[j]!=' ')
			{
				t=0;
                while((j<s.length())&&(s[j]!=' ')) t=10*t+(int)s[j++]-48;

                c[i][t]=1;
                c[i][0]++;
			}
	}

	if(tt<=k)
	{
		for(i=1;i<=n;i++)
			if(a[i]<=k) cout<<i<<" ";

		return 0;
	}

    f(1,0,0);

    for(i=1;i<=n;i++)
    	if(anss[i]==1)  cout<<i<<" ";

	return 0;
}