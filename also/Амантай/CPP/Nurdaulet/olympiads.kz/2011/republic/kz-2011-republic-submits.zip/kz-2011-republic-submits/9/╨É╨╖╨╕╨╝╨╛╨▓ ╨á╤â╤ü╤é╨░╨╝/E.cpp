#include<iostream>
#include<fstream>
#include<vector>
#include<cstdio>
#include<string>
#include<cmath>
#include<set>
#include<stack>
#include<queue>
#include<map>
#include<utility>
#include<algorithm>
using namespace std;
#define ll long long 
int main ()
 {
   freopen ("E.in","r",stdin);
   freopen ("E.out","w",stdout);
   ll a,b,c,l,r,p;
   ll s=0;
    cin>>a>>b>>c>>l>>r>>p;
     ll x,y,z;
     x=l-a;
     y=l-b;
     z=l-c;
     while(true)
       {
        if (r-a<x)break;
        s+=((x*y*z)%p);
        x++;
        if (r-a<x)break;
        s+=(((x)*(y+1)*(z+1))%p);
        x++;
        y+=2;
        z+=2;
       }
       cout<<s;
  return 0;
 }
