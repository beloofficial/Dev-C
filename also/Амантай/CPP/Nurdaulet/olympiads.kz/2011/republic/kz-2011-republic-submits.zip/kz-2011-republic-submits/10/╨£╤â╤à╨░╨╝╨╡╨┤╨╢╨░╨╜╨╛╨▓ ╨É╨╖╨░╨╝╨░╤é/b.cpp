//Mukhamejanov Azamat 2011y
#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
#include <ctime>
#include <map>
#include <set>
using namespace std;
#define fname1 "B."
#define fname2 ""
#define inf 1<<30
#define eps 1e-5

int n,a[20][20];
bool p[20];
int t[20],ans,b[20];
int d1[20][20],d2[20][20],pd1[20],pd2[20];

void rec (int v,int sum=0){
	if (v>n){
		if (sum>ans){
			for (int i=1;i<=n;++i)b[i]=t[i];
			ans=sum;
		}
		return;
	}
	for (int i=1;i<=n;++i)
		if (!p[i]&&!pd1[d1[v][i]]&&!pd2[d2[v][i]]){
			p[i]=1;
			t[v]=i;
			pd1[d1[v][i]]=1;
			pd2[d2[v][i]]=1;
			rec (v+1,sum+a[v][i]);
			p[i]=0;
			t[v]=0;
			pd1[d1[v][i]]=0;
			pd2[d2[v][i]]=0;
		}
}
int main (){
	freopen (fname1"in"fname2,"r",stdin);
	freopen (fname1"out"fname2,"w",stdout);

	scanf ("%d",&n);
	for (int i=1;i<=n;++i)
		for (int j=1;j<=n;++j)scanf ("%d",&a[i][j]);

	for (int i=1;i<=n;++i){
		int k=i;
		for (int j=1;j<=n;++j)
			d2[i][j]=k++;
		k=i;
		for (int j=n;j>0;--j)
			d1[i][j]=k++;
	}
	rec (1);
	
	for (int i=1;i<=n;++i)
		for (int j=1;j<=n;++j)d1[i][j]=0;

	for (int i=1;i<=n;++i)d1[i][b[i]]=1;
	for (int i=1;i<=n;++i,printf ("\n"))
		for (int j=1;j<=n;++j)printf ("%d ",d1[i][j]);

	return 0;
}