//Mukhamejanov Azamat 2011y
#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include "dist.h"
#include <ctime>
#include <cmath>
#include <map>
#include <set>
using namespace std;
#define fname1 "G."
#define fname2 ""
#define inf 1<<30
#define eps 1e-5

int x,y,ansx,ansy;
int main (){
	start();

	double d1=dist(x,y);
	double d2=dist(x+1,y);
	double d3=dist(x,y+1);

	double x2=(d1*d1-d2*d2+1+2*x)/2;
	double y2=(d1*d1-d3*d3+1+2*y)/2;
	
	int x3=x2*1;
	int y3=y2*1;

	if (dist(x3,y3)-0==eps)finish(x3,y3);else{
		double d1=dist(x,y);
		double d2=dist(x-1,y);
		double d3=dist(x,y-1);

		double x2=(2*x-1+d2*d2-d1*d1)/2;
		double y2=(2*y-1+d3*d3-d1*d1)/2;

		int x3=x2*1;
		int y3=y2*1;

		finish(x3,y3);
	}

	return 0;
}
