// Zhalpakov Daulet
#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
#include <vector>
#include <cmath>
#include <map>
using namespace std;

int a[100100], n, m;
map <int, bool> num;

int main()
{
	freopen("D.in", "r", stdin);
	freopen("D.out", "w", stdout);

	scanf("%d%d", &n, &m);
	for (int i = 1; i <= n; ++i)
		scanf("%d", &a[i]);
	
	int l, r;
	while (m--) {
		scanf("%d%d", &l, &r);

		for (int i = l; i <= r; ++i)	
	    	num[a[i]] = 1;
		
		printf("%d\n", num.size());
		num.clear();
	}


	return 0;
}
