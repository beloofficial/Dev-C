//Solution by Mukai Yersin
#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <ctime>
#include <cmath>
#include <map>
#include <set>

#define sz 2000000
#define nsz 2000
#define fname "C."
#define sqr(w) ((w)*(w))
#define maxint (1<<30)

using namespace std;

int s[sz],f[sz],k,i,j,n,m,a[600][2][600][2],ok[600][2],flag,maxx,sum,x,l,r,o[600][2],q[sz],t[sz],len;

int main()
{
	freopen(fname"in","r",stdin);
	freopen(fname"out","w",stdout);
	  	scanf("%d %d",&n,&m);
	  	for (i=1;i<=n;i++)
	  		{
	  			scanf("%d",&k);
	  			for (j=1;j<=k;j++)
	  				{
	  					scanf("%d",&x);
	  					a[i][1][x][0]=1;
	  					a[x][0][i][1]=1;
	  				}	
	  		}
	 	for (i=1;i<=m;i++)
	  		{
	  			scanf("%d",&k);
	  			for (j=1;j<=k;j++)
	  				{
	  					scanf("%d",&x);
	  					a[i][0][x][1]=1;
	  					a[x][1][i][0]=1;
	  				}	
	  		}	
	  	for (i=1;i<=n;i++)
	  		{
	  			q[1]=i;l=0;r=1;t[1]=1;
	  			memset(ok,0,sizeof(ok));
	  			memset(o,0,sizeof(o));
	  			ok[i][1]=1;
	  			while (l<r)
	  				{
	  					l++;
	  					flag=0;
	  					len=n;
	  					if (t[l]==1) len=m;
	  		 			for (j=1;j<=len;j++)
	  		 				if (a[q[l]][t[l]][j][(t[l]+1)%2]==1&&ok[j][(t[l]+1)%2]==1)
	  		 					{
	  		 	    		    	     	o[q[l]][t[l]]=1;	   	
	  		 	    		    	     	flag=1;
	  		 	    		    	     	break;
	  		 					}
	  		 		    	if (flag) continue;
	  		 		    	for (j=1;j<=len;j++)
	  		 		    		if (a[q[l]][t[l]][j][(t[l]+1)%2]==0&&ok[j][(t[l]+1)%2]==0)
	  		 		    			{
	  		 		    				q[++r]=j;
	  		 		    				t[r]=(t[l]+1)%2;		 	
	  		 		    				ok[j][(t[l]+1)%2]=1;
	  		 		    			}
	  		 	  	}
	  		 	sum=0;
	  		 	for(j=1;j<=r;j++)
	  		 		if (!o[q[j]][t[j]])
	  		 			sum++;
	  		 	if (sum>maxx)
	  		 		{
	  		 			maxx=sum;
	  		 			s[0]=0;
	  		 			f[0]=0;
	  		 		 	for (j=1;j<=r;j++)
	  		 		 		if (!o[q[j]][t[j]])
	  		 		 			{
	  		 		 			 	if (t[j]==1)
	  		 		 			 		s[++s[0]]=q[j];
	  		 		 			 		else
	  		 		 			 		f[++f[0]]=q[j];
	  		 		 			}
	  				}	
	  		}
	  	for (i=1;i<=m;i++)
	  		{
	  			q[1]=i;l=0;r=1;t[1]=0;
	  			memset(ok,0,sizeof(ok));
	  			memset(o,0,sizeof(o));
	  			ok[i][0]=1;
	  			while (l<r)
	  				{
	  					l++;
	  					flag=0;
	  					len=n;
	  					if (t[l]==1) len=m;
	  		 			for (j=1;j<=len;j++)
	  		 				if (a[q[l]][t[l]][j][(t[l]+1)%2]==1&&ok[j][(t[l]+1)%2]==1)
	  		 					{
	  		 	    		    	     	o[q[l]][t[l]]=1;	   	
	  		 	    		    	     	flag=1;
	  		 	    		    	     	break;
	  		 					}
	  		 		    	if (flag) continue;
	  		 		    	for (j=1;j<=len;j++)
	  		 		    		if (a[q[l]][t[l]][j][(t[l]+1)%2]==0&&ok[j][(t[l]+1)%2]==0)
	  		 		    			{
	  		 		    				q[++r]=j;
	  		 		    				t[r]=(t[l]+1)%2;		 	
	  		 		    				ok[j][(t[l]+1)%2]=1;
	  		 		    			}
	  		 	  	}
	  		 	sum=0;
	  		 	for(j=1;j<=r;j++)
	  		 		if (!o[q[j]][t[j]])
	  		 			sum++;
	  		 	if (sum>maxx)
	  		 		{
	  		 			maxx=sum;
	  		 			s[0]=0;
	  		 			f[0]=0;
	  		 		 	for (j=1;j<=r;j++)
	  		 		 		if (!o[q[j]][t[j]])
	  		 		 			{
	  		 		 			 	if (t[j]==1)
	  		 		 			 		s[++s[0]]=q[j];
	  		 		 			 		else
	  		 		 			 		f[++f[0]]=q[j];
	  		 		 			}
	  				}	
	  		}

	  	printf("%d %d %d\n",maxx,s[0],f[0]);
	  	for (i=1;i<=s[0];i++)
	  		printf("%d ",s[i]);
	  	cout<<endl;
	  	for (i=1;i<=f[0];i++)
	  		printf("%d ",f[i]);
	return 0;
}
