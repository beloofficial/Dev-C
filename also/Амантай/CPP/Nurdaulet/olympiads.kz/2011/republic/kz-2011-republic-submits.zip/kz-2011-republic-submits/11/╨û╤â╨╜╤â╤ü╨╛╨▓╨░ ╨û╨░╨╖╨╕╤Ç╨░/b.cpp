#include<iostream>
#include<algorithm>
#include<cstdio>
#include<string>
#include<cstring>
#include<cmath>
#include<vector>
#include<stack>
#include<queue>
#include<map>
#include<set>

#define mp make_pair
#define pb push_back
#define fi first
#define se second

using namespace std;

int ans=-10000000,s=0,b[16],anss[16],rez[16],a[16][16],n;
bool gor[16],usd1[33],usd2[33];

void f(int v)
{
	int i,d1,d2;

	if(v>n)
	{
		if(s>ans)
		{
			ans=s;
			for(i=1;i<=n;i++)
				anss[i]=rez[i];
		}
	}
	else
	{
		for(i=1;i<=n;i++)
        	if(gor[i]==0)
        	{
        		d1=i+v-1;
        		if(usd1[d1]==0)
        		{
        			if(v>i)  d2=v-i+1;
        			else d2=n+i-v;

        			if(usd2[d2]==0)
        			{
        				usd1[d1]=usd2[d2]=gor[i]=1;
        			
        				rez[v]=i;
        				s+=a[i][v];
        				if(s+b[n]-b[v]>ans) f(v+1);
        				s-=a[i][v];

        				usd1[d1]=0; usd2[d2]=0; gor[i]=0;
        			}
        		}
        	}    
	}
}

int main()
{
	freopen("B.in","r",stdin);
	freopen("B.out","w",stdout);

	int i,j;

	cin>>n;
	for(i=1;i<=n;i++)
		for(j=1;j<=n;j++)
		{
			cin>>a[i][j];

			b[j]=max(b[j],a[i][j]);
		}

	for(i=2;i<=n;i++)    b[i]+=b[i-1];

	f(1);

	for(i=1;i<=n;i++)
		for(j=1;j<=n;j++)
			a[i][j]=0;

	for(i=1;i<=n;i++)
		a[anss[i]][i]=1;

	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
			cout<<a[i][j]<<" ";
		cout<<"\n";
	}

	return 0;
}