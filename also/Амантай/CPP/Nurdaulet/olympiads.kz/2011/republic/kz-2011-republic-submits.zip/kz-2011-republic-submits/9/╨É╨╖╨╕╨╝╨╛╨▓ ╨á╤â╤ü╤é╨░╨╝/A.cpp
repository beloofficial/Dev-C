#include<iostream>
#include<fstream>
#include<map>
#include<cstdio>
#include<vector>
#include<string>
using namespace std;
#define pb push_back
#define ll long long 
     ll  s[23],maxi=0;
    vector<int> cx;
     ll w[25],c[25];
   ll a[67][67];
      ll n,m,k;
   void rec(int x)
     {
      if (x==n)
        {
         int y=0;
         for(int i=0;i<n;i++)
           {
            if (s[i]==1)
             y+=w[i+1];
           }
           if (y<=k)
            {
            ll v=0;
              for(int i=1;i<=m;i++)
               {
                for(int j=1;j<=n;j++)
                 {
                  if (a[i][j]==1 && s[j-1]==0)
                  goto l;
                 }
                 v+=c[i];
                 l:;
               }
              // cout<<v<<endl;
             if (v>maxi){maxi=v;cx.clear();for(int o=0;o<n;o++){if (s[o]==1)cx.pb(o+1);}}
            }
        }
         else
          {
           s[x]=1;
           rec(x+1);
           s[x]=0;
           rec(x+1);
          }
     }

int main ()
 {
  freopen("A.in","r",stdin);
  freopen("A.out","w",stdout);
   cin>>n>>m>>k;
    for(int i=1;i<=n;i++)
      {
       cin>>w[i];
      }
       for(int i=1;i<=m;i++)
         {
         cin>>c[i];
         }
         string sd;
         int as=1,za,vv=m;
              for(int j=0;j<=m;j++) {
               getline(cin,sd);
             for(int i=0;i<sd.length();i++)
               {
                if (sd[i]!=' '){a[j][sd[i]-48]=1;}
               }
               }
           rec(0);
           for(int i=0;i<cx.size();i++)printf("%d " , cx[i]);
           return 0;
 }