//Mukhamejanov Azamat 2011y
#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <map>
#include <set>
using namespace std;
#define fname1 "A."
#define fname2 ""
#define inf 1<<30
#define eps 1e-5

int n,m,k,a[30],b[30],t[30][30];
string S;
int g[30];
bool p1[30];
int ans,Ans[30];
void rec (int v){
	if (v>n){
		int s=0,sum=0;memset (p1,0,sizeof (p1));
//		for (int i=1;i<=n;++i)printf ("%d ",g[i]);cout<<endl;
		for (int i=1;i<=n;++i)
			if (g[i]==1){
				for (int j=1;j<=t[i][0];++j)
					if (!p1[t[i][j]]){
						s+=a[t[i][j]];
						sum+=b[t[i][j]];
						p1[t[i][j]]=1;
					}
			}
		if (s<=k&&sum>ans){
			ans=sum;
			memset (Ans,0,sizeof (Ans));
			memset (p1,0,sizeof (p1));
			for (int i=1;i<=n;++i)
				if (g[i]==1){
					for (int j=1;j<=t[i][0];++j)
						if (!p1[t[i][j]]){
							Ans[t[i][j]]=1;
							p1[t[i][j]]=1;
						}
				}
		}
//		printf ("km:%d sm:%d\n",s,sum);
		return;
	}
	g[v]=1;
	rec (v+1);
	g[v]=0;
	rec (v+1);
}
int main (){
	freopen (fname1"in"fname2,"r",stdin);
	freopen (fname1"out"fname2,"w",stdout);

	scanf ("%d %d %d\n",&n,&m,&k);
	for (int i=1;i<=n;++i)scanf ("%d",&a[i]);
	for (int i=1;i<=m;++i)scanf ("%d",&b[i]);
	scanf ("\n");
	for (int i=1;i<=m;++i){
		getline (cin,S);
		scanf ("\n");
		int l=0;
		int len=S.length ();
		S[len++]=' ';
		for (int j=0;j<len;++j)
			if (S[j]==' '){
				if (S[j-2]>='1'&&S[j-2]<='9')t[i][++l]=(S[j-2]-'0')*10+(S[j-1]-'0');else
				t[i][++l]=S[j-1]-'0';
			}
		t[i][0]=l;
	}
	rec (1);
//	printf ("%d\n",ans);
	for (int i=1;i<=30;++i)
		if (Ans[i])printf ("%d ",i);
	return 0;                                   
}