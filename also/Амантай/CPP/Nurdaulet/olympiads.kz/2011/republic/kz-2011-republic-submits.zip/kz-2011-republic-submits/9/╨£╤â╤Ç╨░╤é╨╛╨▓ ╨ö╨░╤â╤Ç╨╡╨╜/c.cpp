#include <cstdio>
#include <vector>
#include <iostream>

using namespace std;

int n, m;
int ans;
vector <int> ww, answw;
int w[5000], w2[5000];
vector <int> g[5000], ans1, ans2;

void rec(int k, int item) {
	
	if (k == n + m) {
	    if (ans < item) {
	    	ans = item;
	    	answw = ww;
	    }
		return ;
	}

	if (w[k] == 0) {
	    int save = w[k];
        w[k] = 1; 
		ww.push_back(k);
		for (int i = 0; i < (int) g[k].size(); i++) {
			w2[g[k][i]] = w[g[k][i]];
			w[g[k][i]] = 2;
		}
		rec(k + 1, item + 1);

		w[k] = save;
		ww.pop_back();
		for (int i = 0; i < (int) g[k].size(); i++)
			w[g[k][i]] = w2[g[k][i]];
    
    	return ;	
	}

	w[k] = 2; 
	rec(k + 1, item);
}

int main() {
	freopen("C.in", "r", stdin);
	freopen("C.out", "w", stdout);
	
	scanf("%d %d\n", &n, &m);
	for (int i = 0; i < n; i++) {
	    int k; scanf("%d", &k);
	    for (int j = 0; j < k; j++) {
	    	int p; scanf("%d", &p);
	    	p += n - 1;
	    	g[i].push_back(p);
	    }
	}
	for (int i = 0; i < m; i++) {
		int k; scanf("%d", &k);
		for (int j = 0; j < k; j++) {
			int p; scanf("%d", &p);
			g[i + n].push_back(p - 1);
		}
	}
	
	rec(0, 0);	

	for (int i = 0; i < (int) answw.size(); i++) {
		if (answw[i] >= n) {
			ans2.push_back(answw[i] - n + 1);
		}
		else {
			ans1.push_back(answw[i] + 1);	
		}
	}	
	
	printf("%d %d %d\n", answw.size(), ans1.size(), ans2.size());
	for (int i = 0; i < (int) ans1.size(); i++)   
		printf("%d ", ans1[i]);
   	printf("\n");
   	for (int i = 0; i < (int) ans2.size(); i++)
   		printf("%d ", ans2[i]);
	printf("\n");
	
	return 0;
}