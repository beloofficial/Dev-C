#include <set>
#include <cstdio> 
#include <vector>
#include <cstring>
#include <iostream>

using namespace std;

#define LL long long

int n, m, KKK, u;
LL weight[45], force[45];
char ch, s[10000];
set <int> g[45];
vector <char> used(45), ansused(45);
LL ans;
        
void calc() {
	LL sum = 0;
	for (int i = 0; i < m; i++) {
		bool ok = true;
		for (set <int> :: iterator j = g[i].begin(); j != g[i].end(); j++) {
		    int val = *j;
			if (!used[val]) {
				ok = false;
				break;
			}
		}
	   	if (ok) sum += force[i];
	}
	if (ans < sum) {
		ans = sum;
		ansused = used;
	}
}

void rec(int k, LL w) {

	if (k == n) {
		if (w <= KKK) calc();
		return ;
	}
	
	if (w > KKK) return ;

	used[k] = true;
	u++;
	rec(k + 1, w + weight[k]);

	u--;
	used[k] = false;
	rec(k + 1, w);
}

int main() {
	freopen("A.in", "r", stdin);
	freopen("A.out", "w", stdout);

	scanf("%d %d %d\n", &n, &m, &KKK);
	for (int i = 0; i < n; i++) scanf("%I64d", &weight[i]);
	for (int i = 0; i < m; i++) scanf("%I64d", &force[i]);
	scanf("\n");

	for (int i = 0; i < m; i++) {
		do {	
			int k; scanf("%d", &k); --k;
			g[i].insert(k);
			ch = getchar();
		} while (ch != -1 && ch != '\n');
	}

	rec(0, 0);
	
	for (int i = 0; i < n; i++)
		if (ansused[i]) printf("%d ", i + 1);

	return 0;
}