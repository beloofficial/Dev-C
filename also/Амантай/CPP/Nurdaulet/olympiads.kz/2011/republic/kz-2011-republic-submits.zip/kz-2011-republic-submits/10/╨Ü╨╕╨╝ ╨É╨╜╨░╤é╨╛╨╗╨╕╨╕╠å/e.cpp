#include <iostream>
#include <cmath>
#include <algorithm>
#include <cstdio>
#include <vector>
#include <cstring>
          
using namespace std;

long long l,r,a,b,c,p,ans=0,abc1,abc2,abc3;

int main(){

	freopen("e.in","r",stdin);
	freopen("e.out","w",stdout);

cin>>a>>b>>c>>l>>r>>p;

	for (int i=l; i<=r; i++){
		ans=((ans%p)+((i-a)*(i-b)*(i-c))%p)%p;
	}
	cout<<ans<<endl;  

	return 0;
}