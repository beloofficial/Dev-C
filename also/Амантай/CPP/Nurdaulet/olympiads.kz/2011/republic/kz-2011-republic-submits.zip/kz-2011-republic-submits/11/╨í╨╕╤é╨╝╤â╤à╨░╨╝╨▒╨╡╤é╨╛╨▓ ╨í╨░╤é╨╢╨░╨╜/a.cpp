#include <cstdio>
#include <algorithm>
#include <cstring>
#include <iostream>
#include <string>
using namespace std;
int n, m, i, j, k, x, ss, t, r, l[99], a[99], c[99][99], ansi , h, g, ok, pr[99], u[99];
long long sum, ans, b[99];
char s[1000];
int main () 
{
	freopen("A.in", "r", stdin);
	freopen("A.out", "w", stdout);
	cin >> n >> m >> k;
	for (i = 1; i <= n; i++)
		cin >> a[i];
	for (i = 1; i <= m; i++) 
		cin >> b[i];
	scanf("\n");
	for (i = 1; i <= n; i++) {
		cin.getline(s, 1000); 
		r = strlen(s);
		t = 0;
		for (j = 1; ; j++) {
			for ( ; (s[t] < '0' || s[t] > '9') && t < r; t++);
			if (t == r) break;
			x = 0; 
			for ( ; '0' <= s[t] && s[t] <= '9'; t++)
				x = x * 10 + s[t] - 48;
	 		c[i][j] = x;
		}
		l[i] = j - 1;
	}   	h = (1 << n);
	g = (1 << m);
	//printf("h = %d\n", h);
	for (i = 1; i < h; i++) {
		//puts("ok");
		for (j = ss = 0; j < n; ) {
			j++;
			u[j] = (i & (1 << (j - 1)));
			if (u[j]) ss += a[j];
		}         
		if (ss <= k) {
			//printf("i = %d\n", i);
			sum = 0;
			for (j = 1; j <= m; j++) {
				ok = 1;
				for (t = 1; t <= l[j]; t++)
					if (u[c[j][t]] == 0)
						ok = 0;
				if (ok)	sum += b[j];
			}
			if (sum > ans) {
				ans = sum;
				ansi = i;
			}			
		}
	}                   
	for (i = 0; i < n; i++)
		if (ansi & (1 << i))
			printf("%d ", i + 1);
}

