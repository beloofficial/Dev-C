//Kushibar Kaisar
#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include <cctype>
#include <cstdio>
#include <ctime>
#include <cmath>
#include <set>
#include <map>

#define fname "E"
using namespace std;

typedef long long ll;

ll l, r, a, b, c, p, ans;

ll f(ll x){
ll res=1, a1, b1, c1;
a1=x-a;
b1=x-b;
c1=x-c;
	res=a1 % p;
	res=((res % p)*(b1 % p)) % p;
	res=((res % p)*(c1 % p)) % p;
	return res % p;
}

int main(){
	freopen(fname".in","r",stdin);
	freopen(fname".out","w",stdout);
	cin>>a>>b>>c>>l>>r>>p;
//	cout<<a<<" "<<b<<" "<<c<<" "<<l<<" "<<r<<" "<<p<<endl;
	ans=0;
	for(ll i=l; i<=r; i++)
		ans=((ans % p) + (f(i) % p)) % p;
	cout << ans%p << endl;
	return 0;
}
