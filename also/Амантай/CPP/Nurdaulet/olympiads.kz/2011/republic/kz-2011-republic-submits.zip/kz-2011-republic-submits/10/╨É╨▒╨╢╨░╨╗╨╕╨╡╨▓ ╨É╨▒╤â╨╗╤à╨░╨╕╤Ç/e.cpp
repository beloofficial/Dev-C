#include <algorithm>
#include <iostream>
#include <cassert>
#include <cstring>
#include <cstdlib>
#include <string>
#include <vector>
#include <cstdio>
#include <ctime>
#include <cmath>
#include <set>
#include <map>

#define inf (int)1e9
#define EPS 1e-6
#define file "E"

typedef long long ll;
typedef long double ld;

using namespace std;

int l, r;
ll a, b, c, p;

ll f(ll x) {

	return (((((x - a) % p) * ((x - b) % p)) % p) * ((x - c) % p)) % p;

}

int main() {

	freopen(file".in", "r", stdin);
	freopen(file".out", "w", stdout);

	scanf("%I64d%I64d%I64d%d%d%I64d", &a, &b, &c, &l, &r, &p);

	ll sum = 0;

	for (int i = l; i <= r; ++i) 
		sum = (sum + f(1ll * i)) % p;

  	printf("%I64d\n", sum);

	return 0;
		
}