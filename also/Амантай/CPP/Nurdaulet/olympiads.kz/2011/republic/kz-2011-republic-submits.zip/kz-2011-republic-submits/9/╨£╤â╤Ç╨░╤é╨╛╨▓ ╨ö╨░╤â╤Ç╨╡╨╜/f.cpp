#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>

using namespace std;

#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define maxn 100005

int n, m, ans;
vector <pair <int, int> > g[maxn], top;
vector <char> used(maxn);
pair <pair <int, int>, int > edge[maxn];

bool dfs(int v, int finish, int k) {
	used[v] = true;
	if (v == finish) return true;
	for (int i = 0; i < (int) g[v].size(); i++) {
		int to = g[v][i].fi;
		if (!used[to] && dfs(to, finish, k)) {
		    int kk = edge[g[v][i].se].se;
			if (k == kk) ans++;
			return true;
		}
	}
	return false;
}
 
int main() {
	freopen("F.in", "r", stdin);
	freopen("F.out", "w", stdout);

	scanf("%d %d\n", &n, &m);
	for (int i = 0; i < m; i++) {
		int v, u; scanf("%d %d\n", &v, &u); --v, --u;
		g[v].pb(mp(u, i));
		g[u].pb(mp(v, i));
		edge[i] = mp(mp(v, u), 0);
	}

	int task; scanf("%d\n", &task);
	while (task--) {
		char ch = getchar();
		if (ch == '+') {
        	int k, id; scanf("%d %d\n", &k, &id); --k, --id;
        	edge[id].se = k;
        }
        else {
		    used.assign(n, false);
		    ans = 0;
			int v, u, k; scanf("%d %d %d\n", &v, &u, &k); --v, --u, --k;
			dfs(v, u, k);
			printf("%d\n", ans);
        }
	}

	return 0;
}