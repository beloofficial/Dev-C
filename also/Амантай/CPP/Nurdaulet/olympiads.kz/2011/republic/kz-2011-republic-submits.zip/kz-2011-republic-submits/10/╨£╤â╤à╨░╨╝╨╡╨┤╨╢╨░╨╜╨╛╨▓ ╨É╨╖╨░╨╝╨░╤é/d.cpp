//Mukhamejanov Azamat 2011y
#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
#include <ctime>
#include <map>
#include <set>
using namespace std;
#define fname1 "D."
#define fname2 ""
#define inf 1<<30
#define eps 1e-5

int n,m,a[100010];
int b[100010],len;
int t[1000010];
void build (int i=1,int l=1,int r=n){
	if (l==r)t[i]=1;else{
		int x=(l+r)/2;
		build (i+i,l,x);
		build (i+i+1,x+1,r);
		t[i]=t[i+i]+t[i+i+1];
	}
}
int getsum (int l,int r,int i=1,int tl=1,int tr=n){
//	printf ("%d %d %d %d %d\n",l,r,i,tl,tr);
	if (tl==l&&tr==r)return t[i];
	int x=(tl+tr)/2;
	if (l>x){
		return getsum (l,r,i+i+1,x+1,tr);
	}else
	if (r<=x){
		return getsum (l,r,i+i,tl,x);
	}
	else
		return getsum (l,x,i+i,tl,x) + getsum (x+1,r,i+i+1,x+1,tr);
}
int main (){
	freopen (fname1"in"fname2,"r",stdin);
	freopen (fname1"out"fname2,"w",stdout);

	scanf ("%d %d",&n,&m);
	for (int i=1;i<=n;++i)scanf ("%d",&a[i]);
	
	if (n*m>1000000000){
		build ();
		for (int k=0;k<m;++k){
			int l,r;scanf ("%d %d",&l,&r);
			int s=getsum (l,r);
			printf ("%d\n",s);
		}
	}else{
		for (int k=0;k<m;++k){
			int l,r;scanf ("%d %d",&l,&r);
			len=0;
			memset (b,0,sizeof (b));
			for (int i=l;i<=r;++i){
				bool ok=0;
				for (int j=0;j<len;++j)
					if (a[i]==b[j]){ok=1;break;}
				if (!ok){
					b[len++]=a[i];
				}
			}
			printf ("%d\n",len);
		}
	}
	return 0;                              
}