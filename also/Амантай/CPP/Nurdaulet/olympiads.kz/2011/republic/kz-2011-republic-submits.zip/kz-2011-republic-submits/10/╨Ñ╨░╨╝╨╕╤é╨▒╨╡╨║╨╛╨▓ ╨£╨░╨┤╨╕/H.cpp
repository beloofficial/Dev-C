#include <iostream>
#include <ctime>
#include <vector>
#include <cstdlib>
#include <cstdio>
#include <fstream>

using namespace std;


typedef long long ll;
typedef long double ld;
typedef vector<int> vi;

#define pb push_back
#define mp make_pair
#define sz size()
#define len length()
#define f first
#define s second

double Time () {
	return double(clock()) / double(CLOCKS_PER_SEC);
}

ll sd[300][300];

class Long {
	public:
	ll n, a[50000];
	void in (){
		string s;
		cin >> s;
		n = s.len;
		for (int i = 0; i < n; i++)a[i] = s[n-i-1]-'0';
	}
	void operator += (const ll &x) {
		ll r = 0;
		a[0] += x;
		for (int i = 0 ;i < n; i++) {
                	a[i] += r;
                	if (a[i] > 9) r = a[i]/10, a[i] %= 10;
                }
                while (r) a[n++] = r%10, r /= 10;
	}
	void operator += (const Long &x) {
		int r = 0;
		for (int i = 0; i < max(n,x.n); i++) {
			a[i] = r + (i < n ? a[i] : 0) + (i < x.n ? x.a[i] : 0);
			if (a[i] > 9) a[i] -= 10, r = 1;
			else		r = 0;
		}	
		n = max(n,x.n);
		if (r) a[n++] = 1;
	}
	void operator -= (const Long &x) {
		int r = 0;
		for (int i = 0; i < n; i++){
			a[i] = a[i] - r - ( i < x.n ? x.a[i] : 0);
			if (a[i] < 0) a[i] += 10, r = 1;
			else	 r = 0;
		}
		while (a[n-1] == 0 && n > 1) n--;
	}
	void operator = (const Long &x) {
		n = x.n;
		for (int i = 0; i < n; i++)	a[i] = x.a[i];
	}
	void out () {
		while (a[n-1] == 0 && n > 1) n--;
		for (int i = n-1; i >= 0; i--)	cout << a[i];
	}
	bool operator < (const Long &x) {
		if (n < x.n) return 1;
		if (n > x.n) return 0;
		for (int i = n-1; i >= 0; i--)
			if (a[i] < x.a[i]) return 1;
			else 	if (a[i] > x.a[i]) return 0;
		return 0;
	}
}S, T, A, R;

int main () 
{
	freopen ("h.in", "r", stdin);
	freopen ("h.out", "w", stdout);
	
	ll a[300][300];
	int n, m;
	cin >> n >> m;
	for (int i = 0; i < n; i++)
		for (int j = 0; j < m; j++)
			cin >> a[i][j];
	S.in();
	T.n = 1, T.a[0] = 0;
	A.n = 1, A.a[0] = 0;

	for (int i = 0; i < n; i++) {
		int j;
		if (i%2 == 0) j = i+1;
		else	      j = i; 
		int x = i+1, y = j+1;

	//	cout << i << " " << j << endl;
	
		A += a[i][j];
		if (x == 1 || y == 1 || x == y);
		else				A += T;
	//			A.out(), cout << " 0  ", T.out(), cout << endl;

		T = A;		
	}
	if (m > n) {
		int i = n-1;
		for (int j = n; j < m; j++) {
			int x = i+1, y = j+1;
			A += a[i][j];
			if (x == 1 || y == 1 || x == y);
			else				A += T;
			T = A;		
		
		}
	}
	R = A;
	T.n = 1, T.a[0] = 0;
	A.n = 1, A.a[0] = 0;

	for (int i = 1; i < n; i++) {
		int j;
		if (i%2 == 0) j = i-1;
		else	      j = i; 
		int x = i+1, y = j+1;

	//	cout << i << " " << j << endl;
	
		A += a[i][j];
		if (x == 1 || y == 1 || x == y);
		else				A += T;
	//			A.out(), cout << " 0  ", T.out(), cout << endl;

		T = A;		
	}
	if (m > n) {
		int i = n-1;
		for (int j = n-1; j < m; j++) {
			int x = i+1, y = j+1;
			A += a[i][j];
			if (x == 1 || y == 1 || x == y);
			else				A += T;
			T = A;		
		
		}
	}
	if (R < A)A = R;

	if (S < A) A -= S, cout << "-", A.out();
	else	   S -= A, S.out();

	return 0;
}