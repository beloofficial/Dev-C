#include<iostream>
#include<fstream>
#include<set>
#include<algorithm>
using namespace std;
int n,b[100005];
set<int> s;
struct line
{
int x,y,it,ans;
bool operator < (const line q) const
{
return (x!=q.x?x<q.x:(y!=q.y?y<q.y:it<q.it));
}
} a[100005];
bool q(line a,line b)
{
return (a.it<b.it);
}
int main()
{
freopen("D.in","r",stdin);
freopen("D.out","w",stdout);
int m,l,r,i;
cin>>n>>m;
for(i=1;i<=n;i++) cin>>b[i];
for(i=1;i<=m;i++)
{
cin>>l>>r;
a[i].x=l;
a[i].y=r;
a[i].it=i;
}
sort(a+1,a+n+1);
a[0].x=0;
for(i=1;i<=n;i++)
{
if(a[i].x!=a[i-1].x)
{
s.clear();
s.insert(b+a[i].x,b+a[i].y+1);
}
else
{
s.insert(b+a[i-1].y+1,b+a[i].y+1);
}
a[i].ans=s.size();
}
sort(a+1,a+n+1,&q);
for(i=1;i<=n;i++)
{
cout<<a[i].ans<<endl;
}
return 0;
}