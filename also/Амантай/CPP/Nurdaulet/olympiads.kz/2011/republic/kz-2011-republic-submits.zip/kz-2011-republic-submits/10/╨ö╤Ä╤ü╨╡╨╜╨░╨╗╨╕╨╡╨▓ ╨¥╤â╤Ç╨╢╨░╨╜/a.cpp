#include <cstdio>

int main()
{
	freopen("A.in", "r", stdin);
	freopen("A.out", "w", stdout);
	int n;
	scanf("%d", &n);
	if (n>1)
	printf("%d %d", n-1, n);
	else
	puts("1");
	return 0;
}
