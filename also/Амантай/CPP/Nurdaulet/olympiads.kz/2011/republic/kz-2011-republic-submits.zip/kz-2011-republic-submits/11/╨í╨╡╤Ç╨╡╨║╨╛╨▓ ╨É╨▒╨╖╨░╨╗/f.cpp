#include <iostream>
#include <fstream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <map>
#include <set>
#include <queue>
using namespace std;
int n,m;         
int mn = 131072;
vector < vector <pair <int, int> > >  a;
vector < map <int, int> > mm;
//vector <int> tree1, tree2;
vector <pair <int, int> > q;
int sum = 0, t = 0;
vector <bool> b;
vector <int> prev;
void prepare(int n)
{
	b.resize(1);
	b[0]=false;
	b.resize(n);
	sum = 0;
	t = 0;
	prev.resize(1);
	prev[0] = 0;
}
void dfs(int v, int u)
{
	b[v] = true;
	if (v == u) return;
	for (int i = 0; i < a[v].size(); i++)
	if (!b[a[v][i].first])
	{
		    t++;	
		    sum+=a[v][i].second;
	            dfs(a[v][i].first, u);
	}
}
void bfs(int v, int u)
{
	queue <int> QQ;
	QQ.push(v);
	prev.resize(n);
	prev[v] = v;
	while (!QQ.empty())
	{                         
		int vv = QQ.front();
		QQ.pop();
		b[vv] = true;
		//if (vv == u) return;
		for (int i = 0; i < a[vv].size(); i++)
			{
				if (!b[a[vv][i].first])
				{
					prev[a[vv][i].first] = vv;
					QQ.push(a[vv][i].first);
					if (a[vv][i].first == u) return;
				}
			}
	}
}
int main()
{               

    //freopen("F.in", "rt", stdin); 
    //freopen("F.out", "wt", stdout);
        ifstream fin("f.in");
	ofstream fout("f.out");
//	scanf("%d%d", &n, &m);
fin>>n>>m;
a.resize(n);
q.resize(m);
mm.resize(n);
	for (int i = 0; i<m; i++)
		{
			int u, v;
			//scanf("%d%d", &u, &v);
			fin>>u>>v;
			u--;
			v--;
			a[u].push_back(make_pair(v,1));
			a[v].push_back(make_pair(u,1));
			mm[u][v] = a[u].size()-1;
			mm[v][u] = a[v].size()-1;
			q[i] = make_pair(u, v);
		}
	int k;
//	scanf("%d", &k);
	fin>>k;
	for (int i = 0; i<k; i++)
	{
		int x, y, p;
		char c;
		//scanf("%c%d%d", &c, &x, &y);
		fin>>c>>x>>y;
		if (c == 'q')  	//scanf("%d\n", &p);                      
		fin>>p;	       
		if (c == '+')
		{
					y--;
					int u, v;
					u = q[y].first;
					v = q[y].second;                           
				
			if (x == 1)
				{                                  
					a[u][mm[u][v]].second = 1;
					a[v][mm[v][u]].second = 1;
				}
			else                                        
				{	

					a[u][mm[u][v]].second = 0;
					a[v][mm[v][u]].second = 0;
                                }                           		
					

		}
		else
		{
					prepare(n);
					x--; y--;
					bfs(x, y);
					int r = y;
					do
					{
						if (prev[r] == r) break;
						sum+=a[r][mm[r][prev[r]]].second;
						r = prev[r];
						t++;
					}
					while (prev[r]!=x);
					if (prev[r] == x) 
					{
					sum+=a[r][mm[r][prev[r]]].second;
					t++;
					}
					if (p == 1)
					{
						fout<<sum<<"\n";
					}
					else
					{
						fout<<t - sum<<"\n";
					}					
		}    
	}
fin.close();
fout.close();
return 0;
}