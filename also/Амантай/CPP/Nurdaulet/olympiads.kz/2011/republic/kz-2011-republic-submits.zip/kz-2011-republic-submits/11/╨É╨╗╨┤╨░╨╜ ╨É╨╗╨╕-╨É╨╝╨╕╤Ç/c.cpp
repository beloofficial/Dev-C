#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <ctime>

using namespace std;

#define N 1100

int n, m, col;
int w[N], p[N], used[N], cused[N];
int a[N][N];

bool fndpair (int u)
{
	if (w[u] == col) return 0;
	w[u] = col;

	for (int i = n+1; i <= n+m; i++)
		if (a[u][i] && (!p[i] || fndpair (p[i])))
		{
			p[i] = u; p[u] = i;
			return 1;
		}

	return 0;
}

bool dfs (int u)
{
//	cerr << "HERE\n";
	if (!u || w[u] == col) return 1;
	w[u] = col;
	for (int i = 1; i <= n+m; i++)
		if (a[u][i] && used[i] == 2)
			return 0;

	for (int i = 1; i <= n+m; i++)
		if (a[u][i] && !dfs (p[i]))
			return 0;
	used[u] = 2;
	for (int i = 1; i <= n+m; i++)
		if (a[u][i])
			used[i] = 1;

	return 1;
}

int main ()
{
	freopen ("C.in", "r", stdin);
	freopen ("C.out", "w", stdout);

	scanf ("%d%d", &n, &m);

	for (int i = 1, kk, v; i <= n; i++)
	{
	 	scanf ("%d", &kk);

	 	for (; kk--;)
	 	{
			scanf ("%d", &v);
			a[i][v+n] = a[v+n][i] = 1;
	 	}
	}
	for (int i = 1, kk, v; i <= m; i++)
	{
	 	scanf ("%d", &kk);

	 	for (; kk--;)
	 	{
	 	 	scanf ("%d", &v);
	 	 	a[v][i+n] = a[i+n][v] = 1;
	 	}
	}

	for (int i = 1; i <= n; i++)
	{
	 	col++;
	 	fndpair (i);
	}

	for (int i = 1; i <= n+m; i++)
		if (!p[i])
			used[i] = 2;

	for (int i = 1; i <= n+m; i++)
		if (!used[i] && p[i])
		{
	 		for (int j = 1; j <= n+m; j++)
	 			cused[j] = used[j];
	 		col++;
			if (!dfs (i))
			{
				for (int j = 1; j <= n+m; j++)
					used[j] = cused[j];
				col++;
				if (!dfs (p[i]))
				{
				 	puts ("BAD");
				 	return 0;
				}
			}
		}

	int tot=0, to1=0, to2=0;
	for (int i = 1; i <= n+m; i++)
	{
	 	tot += used[i] == 2;
	 	if (i <= n)
	 		to1 += used[i] == 2;
	 	else
	 		to2 += used[i] == 2;
	}

	printf ("%d %d %d\n", tot, to1, to2);

	for (int i = 1; i <= n; i++)
		if (used[i] == 2)
			printf ("%d ", i);
	puts ("");
	for (int i = n+1; i <= n+m; i++)
		if (used[i] == 2)
			printf ("%d ", i-n);
	puts ("");

	return 0;
}
