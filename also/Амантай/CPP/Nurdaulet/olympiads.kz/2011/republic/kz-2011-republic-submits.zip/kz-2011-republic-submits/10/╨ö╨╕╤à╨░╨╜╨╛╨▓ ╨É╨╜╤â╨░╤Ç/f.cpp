#include <cstdio>
#include <iostream>
#include <algorithm>
#include <vector>
#include <cstring>
#define N 200009
#define mp make_pair
#define f first
#define s second
using namespace std;

int n, m, p[N], a[N], r[N], w[N], i, j, k, l, le[N];
pair <int, int> ul[N];
vector <int> g[N];
bool u[N];
int vo[N];
int FindSet(int x)
{
	if (x != w[x])
		x = FindSet(w[x]);
	return x;	
}
void Union(int x, int y)
{
	int xx = FindSet(x), yy = FindSet(y);
	if(r[xx] > r[yy])
	{
		p[y] = x;
		g[x].push_back(y);
		r[xx] += r[yy];
		w[yy] = xx;	
	}
	else
	{
		p[x] = y;
		g[y].push_back(x);
		r[yy] += r[xx];
		w[xx] = yy;
	}
}

void dfs(int v, int l = 0)
{

	le[v] = l;
	u[v] = 1;
	for (int i = 0; i < g[v].size(); i++)
	{
		int to = g[v][i];

		if (!u[to])
			dfs(to, l + 1);
	}
}

int lca(int x, int y, int z)
{
	int res = 0;
	if (le[x] > le[y]) swap(x, y);
	while(le[x] != le[y])
	{
		if (vo[y] == z)
			res++;
		y = p[y];
	}	        
	while(x != y)
	{
		res += vo[x] == z;
		res += vo[y] == z;
		x = p[x];
		y = p[y];
	}
	return res;
}
main ()
{
	freopen ("F.in", "r", stdin);
	freopen ("F.out", "w", stdout);
	scanf ("%d%d", &n, &m);
	for (i = 0; i <= n; i++)
		w[i] = i, r[i] = 1, vo[i] = 1;	
	for (i = 1; i <= m; i++)
	{
		scanf ("%d%d", &k, &l);
		ul[i] = mp(k, l);
		Union(k, l);
	}

	dfs(FindSet(1));
	scanf("%d", &k);
	for (i = 0; i <= k; i++)
	{
		char c[101];			
	   	gets(c);
		if (c[0] == '+')
		{
			int v1 = 0, x, y, a, b;
			x = y = -1;
			for (j = 1; j <= strlen (c); j++)
			{
				if (c[j] >= '0' && c[j] <= '9')
				{
					while (c[j] >= '0' && c[j] <= '9')
						v1 = v1 * 10 + (c[j] - 48), j++;
					if (x == -1)
						x = v1;
					else y = v1;
					v1 = 0;
				}	
			}
			a = ul[y].f, b = ul[y].s;
			if (p[a] == b)
		    	vo[a] = x;
		    else vo[b] = x;
		}
		else if (c[0] == 'q')
		{
			int v1 = 0;
			int x, y, z, ans;
			x = y = z = -1;
			for (j = 1; j <= strlen (c); j++)
			{
				if (c[j] >= '0' && c[j] <= '9')
				{
					while (c[j] >= '0' && c[j] <= '9')
						v1 = v1 * 10 + (c[j] - 48), j++;
			    	if (x == -1)
						x = v1;
					else if (y == -1) y = v1;
					else z = v1;
					v1 = 0;
				}
					
			}
			
			ans = lca(x, y, z);
			printf ("%d\n", ans);
		}
	}
}