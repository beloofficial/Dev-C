#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <string>
#include <cstring>
#include <set>
#include <map>
#include <stdio.h>

#define pb push_back
#define mp make_pair
#define se second
#define fi first
#define all(a) a.begin(),a.end()
#define name "F"

using namespace std;

int n,m,x,y,z,k,xx,yy;
vector<pair<int,int> > dor;
char ch;
vector<int> use,used;
vector<pair<int,int> > a[100010];
int ans,ans1;

void way(int x,int y,int z) {
//    cout << x << ' ' << y << ' ' << z << ' ' << ans << ' ' << endl;
	if(x == y)	{
		ans1 = min(ans1,ans);
		return;
	}

	for(int i = 0; i < a[x].size(); ++ i) {
		if(!use[a[x][i].fi]) {
			use[a[x][i].fi] = 1;
			if(a[x][i].se == z)	{
				++ ans;
				way(a[x][i].fi,y,z);
                -- ans;
			}
			else
				way(a[x][i].fi,y,z);
			use[a[x][i].fi] = 0;
		}
	}

}

void add() {
	
    for(int i = 0; i < m; ++ i) {
    	cin >> x >> y;
    }

    ans = m;

    cin >> k;
    for(int i = 0; i < k; ++ i) {
    	cin >> ch;
    	if(ch == 'q') {
    		cin >> x >> y >> z;
    		cout << ans << "\n";
    	} else {
    		cin >> x >> y;
    		if(x == 2)
    			-- ans;
    		else
    			++ ans;
    	}
    }

}

int main() {

	ios_base::sync_with_stdio(0);

	freopen(name".in","r",stdin);
	freopen(name".out","w",stdout);	
    
    cin >> n >> m;

    if(n > 77) {
    	add();
    	return 0;
    }

    for(int i = 0; i <= n; ++ i) {
    	 use.pb(0);
    	used.pb(0);
    }

    for(int i = 0; i < m; ++ i) {
    	cin >> x >> y;
    	a[x].pb(mp(y,1));
    	a[y].pb(mp(x,1));
    	dor.pb(mp(x,y));
    }

    cin >> k;
    for(int i = 0; i < k; ++ i) {
    	cin >> ch;
    	if(ch == 'q') {
//    		use = used;
    		cin >> x >> y >> z;
    		use[x] = 1;
    		ans = 0;
    		ans1 = 1000000000;
    		way(x,y,z);
    		use[x] = 0;
    		cout << ans1 << "\n";
    	} else {

    		cin >> x >> y;

            -- y;

            xx = dor[y].fi;
            yy = dor[y].se;

            for(int j = 0; j < a[xx].size(); ++ j) 
            	if(a[xx][j].fi == yy) {
            		a[xx][j].se = 3 - a[xx][j].se;
	            }

            for(int j = 0; j < a[yy].size(); ++ j) 
            	if(a[yy][j].fi == xx) {
            		a[yy][j].se = 3 - a[yy][j].se;
	            }
    	}
    }
    
	return 0;
}

