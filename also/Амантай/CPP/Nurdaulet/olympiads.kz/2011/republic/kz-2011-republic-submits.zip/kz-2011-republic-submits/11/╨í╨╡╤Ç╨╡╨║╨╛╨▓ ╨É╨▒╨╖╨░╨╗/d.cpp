#include <iostream>
#include <fstream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <map>
#include <set>
using namespace std;
int n,m;         
int main()
{               
//ifstream fin("d.in");
//ofstream fout("dset.out");      
    freopen("d.in", "rt", stdin); 
    freopen("d.out", "wt", stdout);
      scanf("%d%d", &n, &m);
	int a[n];
	for (int i =1; i<=n; i++)
	{
		scanf("%d", &a[i]);
	}
	for (int i = 0; i < m; i++)
	{
		int l, r;
		scanf("%d%d", &l, &r);
		int ans = 0;
		set <int> q;
		for (int j = l; j<=r; j++)
			{
				q.insert(a[j]);      
			}
		
		printf("%d\n", q.size());
	}
//fin.close();
//fout.close();    
return 0;
}