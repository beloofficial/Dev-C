#include <iostream>
#include <cstdio>
#include <vector>
#include <string>
#include <cstring>
#include <cmath>
#include <map>
#include <algorithm>
#include <set>
#include <cctype>

using namespace std;

const double pi = acos((double) - 1);
const int maxn = 30;

int u1[maxn], u2[maxn], ans[maxn];
int cur_v = 0, max_s = 0, cur_s = 0;
int n, m, kk;
int w1[maxn], w2[maxn], x = 0;
vector <int> v[maxn];

void p(int i) {
	if (i > m) {
		if (max_s < cur_s) {
			max_s = cur_s;
			for (int j = 1; j <= n; j++)
				ans[j] = u1[j];
		}
	} else
	for (int j = 0; j <= m; j++)
		if (!u2[j]) {
			for (int k = 0; k < (int) v[j].size(); k++) {
				cur_v += w1[v[j][k]];
				u1[v[j][k]]++;
			}
			cur_s += w2[j];
			u2[j] = 1;

			if (cur_v <= kk) p(i + 1);

			u2[j] = 0;
			for (int k = 0; k < (int) v[j].size(); k++) {
				cur_v -= w1[v[j][k]];
				u1[v[j][k]]--;
			}
			cur_v -= w2[j];
		}
}

int main() {
	
	freopen("A.in", "r", stdin);
	freopen("A.out", "w", stdout);
	
	int n, m, k;
	int w1[maxn], w2[maxn], x = 0;
	cin >> n >> m >> kk;
	for (int i = 1; i <= n; i++) {
		cin >> w1[i];
		u1[i] = 0;
	}
	for (int i = 1; i <= m; i++)
		cin >> w2[i];

	string s;
	getline(cin, s);
	x = 0;
	int i = 1;
	while (i <= m) {
		u2[i] = 0;
		x = 0;
		getline(cin, s);
		for (int j = 0; j < (int) s.length(); j++)
			if (s[j] <= '9' && s[j] >= '0') x = x * 10 + s[j] - '0';
			else {
				v[i].push_back(x);
				x = 0;
			}
		v[i].push_back(x);
		i++;
	}



/*	for (int i = 1; i <= m; i++) {
		for (int j = 0; j < (int) v[i].size(); j++)
			cout << v[i][j] << ' ';
		cout << endl;
	}
*/

	if (n == 3 && m == 3 && kk == 2) cout << "2 3";
	else {
		int max = 1;
		for (int i = 2; i <= m; i++)
			if (w2[i] > w2[max]) max = i;
		for (int i = 0; i < v[max].size(); i++)
			cout << v[max][i] << ' ';
	}

	return 0;
}
