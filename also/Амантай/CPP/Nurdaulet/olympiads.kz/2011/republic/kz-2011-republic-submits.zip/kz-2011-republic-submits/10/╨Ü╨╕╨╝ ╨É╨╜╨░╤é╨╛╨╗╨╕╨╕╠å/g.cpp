#include <iostream>
#include <cmath>
#include <algorithm>
#include <cstdio>
#include <vector>
#include <cstring>
#include <dist.h>
          
using namespace std;

const int maxn=1000000000,minn=-1000000000;
int l=minn,r=maxn,u=maxn,d=minn,x,y;

int main(){

start();

while (dist(l,0)!=dist(r,0)){
	if (dist(l,0)>dist(r,0))
		l=(l+r)/2;
	
	else

		r=(l+r)/2;	

	if (dist(r-1,0)==dist(r+1,0)){
		l=r;
		break;
	}

	if (dist(l-1,0)==dist(l+1,0)){
		r=l;
		break;
	}      

}

while (dist(0,d)!=dist(0,u)){
	if (dist(0,d)>dist(0,u))
		d=(u+d)/2;

	else

		u=(u+d)/2;	

	if (dist(0,u-1)==dist(0,u+1)){
		d=u;
		break;
	}

	if (dist(0,d-1)==dist(0,d+1)){
		u=d;
		break;
	}      

}

l=(l+r)/2; u=(u+d)/2;

finish(l,u);

	return 0;
}