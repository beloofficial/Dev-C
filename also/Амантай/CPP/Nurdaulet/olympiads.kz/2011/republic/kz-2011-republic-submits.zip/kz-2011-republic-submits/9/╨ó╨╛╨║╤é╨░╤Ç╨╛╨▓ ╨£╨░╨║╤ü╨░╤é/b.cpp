#include<algorithm>
#include<iostream>
#include<utility>
#include<cstdlib>
#include<cstring>
#include<string>
#include<cstdio>
#include<vector>
#include<ctime>
#include<cmath>
#include<new>
#include<map>
using namespace std;
const int inf = 10000;
#define max(a,b) (a<b?b:a)
#define min(a,b) (a<b?a:b)
#define cl(a,b) memset(a,b,sizeof(a));
#define pb push_back
#define mp make_pair
#define F first
#define S second 
int n,m,a[12][12],best[12][12],c[12][12],cur = -inf;
bool w1[100],w4[100],w3[100];

void calc(int p) {
	if (p <= cur) return;
	for (int i = 1; i <= n; i++){
	for (int j = 1; j <= n; j++) {
		best[i][j] = c[i][j];

	} 
	}
	cur = p;
}
void go(int x,int sum) {
	int i,j;
	if (x > n) { calc(sum); return; }
	for ( j = 1; j <= n; j++) {
		int mx = -inf,q=0;
		for (i = 1; i <= n; i++) 
		if (mx < a[x][i] && !w1[i] && !w3[x+i] && !w4[(x-i)+10]) {
			mx = a[x][i];
			q = i;	
		}
		c[x][q] = 1;
		w1[q] = true;
		w3[x+q] = true;
		w4[(x-q)+10] = true;
		a[x][q]= -1;
		go(x+1,sum+mx);
		w1[q] = false;
		w3[x+q] = false;
		w4[(x-q)+10] = false;
		c[x][q] = 0;
	}
}
int main () {
	freopen("B.in","r",stdin);
	freopen("B.out","w",stdout);
	scanf("%d",&n);
	for (int i = 1; i <= n; i++) { 
	for (int j = 1; j <= n; j++) 
		scanf("%d",&a[i][j]);
	
		scanf("\n");
	}
	go(1,0);
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= n; j++) printf("%d ",best[i][j]);
		printf("\n");
	}

 return 0;
}
