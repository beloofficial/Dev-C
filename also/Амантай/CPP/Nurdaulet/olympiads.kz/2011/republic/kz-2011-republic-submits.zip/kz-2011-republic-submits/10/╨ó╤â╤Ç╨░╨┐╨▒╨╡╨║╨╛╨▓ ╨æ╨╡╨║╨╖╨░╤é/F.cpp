#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstdlib>
#include<vector>
#include<utility>
#include<queue>
#include<ctime>
#include<list>
#include<set>
#include<map>

using namespace std;

#define tr(Con,it) for(typeof(Con.begin()) it=Con.begin();it!=Con.end();it++)
#define pb push_back
#define mp make_pair
int n,m,k,x,y,cnr,K;
int G[1100][1100],path[10000],Q[10000],l,r,v;
bool used[10000];
pair<int,int> E[100100];
int a,b;
char ch;
	
int Count(int k){
	int cnt=0;
	used[x]=true;
	Q[r++]=x;
	path[x]=-1;
	while(l<r){
		v=Q[l++];
		for(int i=1;i<=n;i++)
			if(!used[i] && G[v][i]){	
				used[i]=true;
				path[i]=v;
				Q[r++]=i;
			}
	}

//	for(int i=1;i<=n;i++)
//		printf("%d ",path[i]);
	v=y;
	while(path[v]!=-1){
		if(G[path[v]][v]==k) cnt++;
		v=path[v];
	}
	return cnt;
		
}
int main(){
	freopen("F.in","r",stdin);
	freopen("F.out","w",stdout);
	scanf("%d %d\n",&n,&m); 
	for(int i=1;i<=m;i++){
		scanf("%d %d\n",&a,&b);
		G[a][b]=1; 
		G[b][a]=1; 
		E[i]=mp(a,b);
	}

	scanf("%d\n",&K);
	for(int i=1;i<=K;i++) {
		scanf("%c ",&ch);
		if(ch=='+'){
			scanf("%d %d\n",&x,&y);
			G[E[y].first][E[y].second]=x;
			G[E[y].second][E[y].first]=x;
		}
		else if(ch=='q'){
			scanf("%d %d %d\n",&x,&y,&k);
	//		printf("%c %d %d %d\n",ch,x,y,k);
			printf("%d\n",Count(k));
		}
	}

return 0;
}