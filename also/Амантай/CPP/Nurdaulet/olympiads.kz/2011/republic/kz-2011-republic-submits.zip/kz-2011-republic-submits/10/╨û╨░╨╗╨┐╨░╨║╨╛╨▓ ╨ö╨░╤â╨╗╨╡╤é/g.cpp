// Zhalpakov Daulet
#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
#include <vector>
#include <cmath>
#include <map>
#include "dist.h"
using namespace std;

const int dx[] = {1, -1, 0, 0}, dy[] = {0, 0, 1, -1};

int x, y;

int main()
{
	start();

    x = y = 0;
    double r = dist(0,0);

	while (dist(x, y) != 0.0) {
		int tx, ty;
		double tr = r;
		for (int i = 0; i < 4; ++i) {
			int xx = x + r*dx[i], yy = y + r*dy[i];
			double t = dist(xx, yy);

			if (t <= tr) {
				tx = xx, ty = yy, tr = t;
			}
		}

//		cerr << x << " " << y << endl;

	    x = tx;
	    y = ty;
		r = tr;
	}
	
	finish(x, y);

	return 0;
}
