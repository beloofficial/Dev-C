#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cmath>
#include <string>
#include <cstring>
#include <map>
#include <set>
#include <deque>
#include <queue>
#include <vector>

using namespace std;

#define name 	"F"
#define INF 	int(1e9)
#define EPS		1e-9
#define PB		push_back
#define	fi		first
#define	se		second
#define MP		make_pair
#define SZ(x)	int(x.size())
#define ALL(x)	x.begin(), x.end()

int n, m, x, y, UK, k, q, ans;
pair<int,int> v;
vector<pair<int,int> > adj[100001];
map<int, pair<int,int> > ukx;
map<int, pair<int,int> > uky;
char c;

bool ok;
bool use[100001];

int DFS(int u, int K) {
	if (u == y) {
	 	ok = true;
	 	return ans;
	}
 	use[u] = true;

 	for (int i = 0; i < SZ(adj[u]); ++ i) {
 	 	if (!use[adj[u][i].fi]) {
 	 		if (adj[u][i].se == K) ans ++;
 	 	 	DFS(adj[u][i].fi, K);
 	 	 	if (ok) return ans;
 	 		if (adj[u][i].se == K) ans --;
 	 	}
 	}

 	return ans;
} 

int main() {
	freopen(name".in","r",stdin);
	freopen(name".out","w",stdout);

	cin >> n >> m;

	UK = 1;
	for (int i = 0; i < m; ++ i) {
	 	cin >> x >> y;
	 	adj[x].PB(MP(y,1));
	 	adj[y].PB(MP(x,1));
	 	ukx[UK] = MP(x,SZ(adj[x])-1);
	 	uky[UK++] = MP(y,SZ(adj[y])-1);
	}

	cin >> k;

	for (int i = 0; i < k; ++ i) {
	 	cin >> c;
	 	if (c == '+') {
	 		cin >> x >> y;
	 	 	v = ukx[y];
			adj[v.fi][v.se].se = x;
	 	 	v = uky[y];
			adj[v.fi][v.se].se = x;
	 	} else {
	 	 	cin >> x >> y >> q;
	 	 	memset(use, false, sizeof(use));
	 	 	ok = false;
	 	 	ans = 0;
			DFS(x, q);
			cout << ans << endl;
	 	}
	}


	return 0;
}
