#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <string.h>
#include <math.h>
#include <numeric>
#include <time.h>
#define f first
#define s second
using namespace std;         
pair <int, pair <int, int> > p[1000]; int pl = 0;
int n;
bool iq[1000], jq[1000], di[1000], dj[1000]; int sol[500][500];
int main () {
	freopen ("B.in", "r", stdin);
	freopen ("B.out", "w", stdout);
	scanf ("%d", &n);
	memset (sol, 0, sizeof (sol));
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= n; j++) {
			++pl;
			scanf ("%d", &p[pl].f);
			p[pl].s.f = i;
			p[pl].s.s = j; 
		}
	sort (p + 1, p + pl + 1);
	for (int q = pl; q >= 1; q--) {
		int i = p[q].s.f, j = p[q].s.s, c = p[q].f;
		if (!iq[i] && !jq[j] && !dj[i + j]) {
			if (i >= j && !di[i - j] || i < j && !di[i - j + 100]) { 
			        sol[i][j] = 1;
			        iq[i] = 1; 
				jq[j] = 1;
				if (i - j < 0) di[i - j + 100] = 1;
				else di[i - j] = 1;
				dj[i + j] = 1; 
			}
		}
	}
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= n; j++)
			printf ("%d ", sol[i][j]);
		printf ("\n");
	}	
	return 0;
} 