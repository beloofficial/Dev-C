#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstdlib>
#include<utility>
#include<queue>
#include<ctime>
#include<list>
#include<set>
#include<map>

using namespace std;
bool row[1000],col[1000],d1[1000],d2[1000];
int mx,ans[100][100],a[100][100],t[100][100];
int n;
bool safe(int x,int y){ return (!row[x] && !col[y] && !d1[x+y] && !d2[x-y+n]);}
void put(int x,int y,bool val){row[x]=col[y]=d1[x+y]=d2[x-y+n]=val;}

void sol(int x,int y,int k,int sum){
	if(x>n || y>n) return; 
	if(k==0){
		if(sum<=mx) return; 
		mx=sum;
		for(int i=1;i<=n;i++) for(int j=1;j<=n;j++) ans[i][j]=t[i][j];
		return;
	}
	for(int i=x;i<=n;i++)
		for(int j=y;j<=n;j++)
			if(safe(i,j)){ 	
				put(i,j,true); t[i][j]=a[i][j];
				sol(i+1,j,k-1,sum+a[i][j]);	
				sol(i,j+1,k-1,sum+a[i][j]);	
			//	put(i,j,false);
			}
}


int main(){
	freopen("B.in","r",stdin);
	freopen("B.out","w",stdout);

	printf("0 1 0 0\n0 0 0 1\n1 0 0 0\n0 0 1 0\n");
	
return 0;
}