#include <iostream>
#include <ctime>
#include <vector>
#include <cstdlib>
#include <cstdio>
#include "dist.h"
#include <fstream>
#include <cmath>

using namespace std;


typedef long long ll;
typedef long double ld;
typedef vector<int> vi;

#define pb push_back
#define mp make_pair
#define sz size()
#define len length()
#define f first
#define s second

const double eps = 1e-6;

double Time () {
	return double(clock()) / double(CLOCKS_PER_SEC);
}
int ansx;
int ansy;
int cnt = 0;

int main () 
{
	start();
//	freopen ("G.in", "r", stdin);
//	freopen ("G.out", "w", stdout);
	
	cin >> ansx >> ansy;

	int l = 0, r = 2000000000;

        
//	cout << fixed;
//	cout.precision(5);

        int x;
	while (l+2 < r) {
		int m = l+fabs(r-l)/3;
		int m1= r-fabs(r-l)/3;
		ld d1 = dist(m-1000000000,0);
		ld d2 = dist(m1-1000000000,0);
		if (d1 < d2) r = m1;
		else if (d1 > d2) l = m;
		else break;
	}                                       
	l = l-1000000000;
	r -= 1000000000;

	int resl = l, resr = r;

	for (x = resl; x <= resr; x++) {
		l = 0, r = 2000000000;
		while (l+2 < r) {
			int m = l+fabs(r-l)/3;
			int m1= r-fabs(r-l)/3;
			ld d1 = dist(x,m-1000000000);
			ld d2 = dist(x,m1-1000000000);
			if (d1 < d2) r = m1;
			else if (d1 > d2) l = m;
			else break;
		
		}	
	
	l = l -1000000000;
	r -= 1000000000;
		for (;l <= r; l++) {
			if (cnt == 10000) {
	                        finish(x,l);
			//	cout << x << " " << l << endl << cnt;
				return 0;
			}
			if (fabs(dist(x,l)) < eps) {
				finish(x,l);
			//	cout << x << " " << l << endl << cnt;
				return 0;
			}
		}
	}

//	finish(x,l);
	finish(x,l);
  //	cout << x << " " << l << endl;
  //	cout << cnt;

	return 0;
}