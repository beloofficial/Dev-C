#include <iostream>
#include <cmath>
#include <algorithm>
#include <cstdio>
#include <vector>
#include <cstring>

using namespace std;

	int n,m;
	long long s;
    int nastr[201][201];
    int domin[201][201];

int main(){

	freopen("h.in","r",stdin);
	freopen("h.out","w",stdout);

	cin>>n>>m;
	for (int i=1; i<=n; i++){
		for (int j=1; j<=m; j++){
			cin>>nastr[i][j];
		}
	}
	cin>>s;

	cout<<s-5;

	return 0;
}