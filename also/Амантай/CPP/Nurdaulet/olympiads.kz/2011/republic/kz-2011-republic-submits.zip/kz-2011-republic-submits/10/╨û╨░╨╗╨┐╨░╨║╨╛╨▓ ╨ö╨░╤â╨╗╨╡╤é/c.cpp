// Zhalpakov Daulet
#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
#include <vector>
#include <cmath>
#include <map>
using namespace std;

#define pb push_back

struct Power {
    int st, v;

    Power () {
    	st = v = 0;
    }

    bool operator< (const Power& a) const {
    	return st > a.st;
    }
} st[2][10000];
  
bool was[2][1000], g[1000][1000];
vector <int> res[2];
int n, m;

int ver (Power& a, int v) 
{
	int ret = 0;
	for (int i = 1; i <= (v == 0 ? m : n); ++i)
		if (was[!v][i] && g[a.v][i]) return -1;
		else
			ret += g[a.v][i];
	
	return ret;
}

int main()
{
	freopen("C.in", "r", stdin);
	freopen("C.out", "w", stdout);

	scanf("%d%d", &n, &m);
	for (int i = 0, k, x; i < n; ++i) {
		scanf("%d", &k);

		for (int j = 0; j < k; ++j) {
			scanf("%d", &x);
			
			if (!g[i+1][x] || !g[x][i+1]) {
//			    cerr << i+1 << " " << x << endl;

				g[i+1][x] = g[x][i+1] = 1;
				st[0][i+1].st ++;
				st[1][x].st ++;
				st[0][i+1].v = i+1;
				st[1][x].v = x;
			}
		}	
	}

	for (int i = 0, k, x; i < m; ++i) {
		scanf("%d", &k);

		for (int j = 0; j < k; ++j) {
			scanf("%d", &x);
			
//		    cerr << i+1 << " " << x << endl;
			if (!g[i+1][x] || !g[x][i+1]) {
				g[i+1][x] = g[x][i+1] = 1;
				st[1][i+1].st ++;
				st[0][x].st ++;
				st[1][i+1].v = i + 1;
				st[0][x].v = x;
			}
		}	
	}

	sort(st[0] + 1, st[0] + n + 1);
	sort(st[1] + 1, st[1] + m + 1);		

/*	for (int i = 1; i <= n; ++i)
		cout << st[0][i].v << " " << st[0][i].st << endl;
	cout << endl;

	for (int i = 1; i <= m; ++i)
		cout << st[1][i].v << " " << st[1][i].st << endl;
	cout << endl;
//	return 0;	
*/
	for (int k = 0, uk0 = 1, uk1 = 1; k < n + m && (uk0 <= n || uk1 <= m);) {
	    while (was[0][st[0][uk0].v] && uk0 < n) uk0++;
	    while (was[1][st[1][uk1].v] && uk1 < n) uk1++;

		int cnt0 = ver(st[0][uk0], 0), cnt1 = ver(st[1][uk1], 1);

		if (cnt0 == -1) {
			uk0++;
			continue;
		}

		if (cnt1 == -1) {
			uk1++;
			continue;
		}

//		cerr << cnt0 << " " << cnt1 << endl;

		if (uk0 <= n && cnt0 >= cnt1 && cnt0 && !was[0][st[0][uk0].v]) {
			int v = st[0][uk0].v;
	        was[0][v] = 1;
			for (int i = 1; i <= m; ++i) {
			    if (was[1][i] || !g[v][i]) continue;
				res[1].pb(i);				
				was[1][i] = 1;
				k++;	
			}
			uk0++;
		} else 
		if (uk1 <= m && cnt1 >= cnt0 && cnt1 && !was[1][st[1][uk1].v]) {
		    int v = st[1][uk1].v;
			was[1][v] = 1;
			for (int i = 1; i <= n; ++i) {
			    if (was[0][i] || !g[v][i]) continue;
			    res[0].pb(i);
				was[0][i] = 1,
				k++;
			}
			uk1++;	
		} else
			uk0++, uk1++;		
	}

	
	for (int i = 1; i <= n; ++i)
 		if (!was[0][i]) {
// 		    cerr << i << " " << ver(st[0][i], 0) << endl;
			if (ver(st[0][i], 0) != -1) {
			    was[0][i] = 1;
				for (int j = 1; j <= m; ++j)
					if (g[i][j]) was[1][j] = 1;
				res[0].pb(i);
			}		
		}
//	cout << "--------------" << endl;
	for (int i = 1; i <= m; ++i)
		if (!was[1][i]) {
//			cerr << i << " " << ver(st[1][i], 1) << endl;
			if (ver(st[1][i], 1) != -1) {
				was[1][i] = 1;
				for (int j = 1; j <= n; ++j)
					if (g[i][j]) was[0][j] = 1;
				res[1].pb(i);
			}		
		}

	printf("%d %d %d\n", res[0].size() + res[1].size(), res[0].size(), res[1].size());

	if (res[0].size() == 0) cout << 0;
	for (int i = 0; i < res[0].size(); ++i)
		printf("%d ", res[0][i]);
	cout << endl;
	if (res[1].size() == 0) cout << 0;
	for (int i = 0; i < res[1].size(); ++i)
		printf("%d ", res[1][i]);
	cout << endl;

	return 0;
}
