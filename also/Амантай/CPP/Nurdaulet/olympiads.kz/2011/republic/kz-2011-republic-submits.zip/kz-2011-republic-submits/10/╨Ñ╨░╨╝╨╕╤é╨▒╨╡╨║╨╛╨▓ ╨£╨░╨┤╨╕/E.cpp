#include <iostream>
#include <ctime>
#include <vector>
#include <cstdlib>
#include <cstdio>
#include <fstream>

using namespace std;


typedef long long ll;
typedef long double ld;
typedef vector<int> vi;

#define pb push_back
#define mp make_pair
#define sz size()
#define len length()
#define f first
#define s second

double Time () {
	return double(clock()) / double(CLOCKS_PER_SEC);
}

int main () 
{
	freopen ("E.in", "r", stdin);
	freopen ("E.out", "w", stdout);
	
	ll a, b, c, l, r, p;
	cin >> a >> b >> c >> l >> r >> p;
	unsigned long long res = 0;
	a %= p, b %= p, c %= p;
	ll x, y, z;
	for (int i = l; i <= r; i++) {
		x = i-a, y = i-b, z = i-c;
		if (x < 0) x += p;
		if (x >= p) x %= p;
		if (y < 0) y += p;
		if (y >= p) y %= p;
		if (z < 0) z += p;
		if (z >= p) z %= p;
		x *= y;
		if (x >= p) x %= p;
		x *= z;
		if (x > p) x %= p;
		res += x;
		if (res >= p) res -= p;
	}
	cout << res;

	return 0;
}