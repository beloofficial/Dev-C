#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <string>
#include <vector>
#include <cstdio>
#include <set>
#include <map>


#define maxint 9999999
using namespace std;

 
int n,kol;
int a[100][100],b[100][100];    
int maxi,maxj,maxq,maxw,maxr,maxh,maxg,maxk,maximum = - maxint;                            
bool c[1000];
int main(){
        freopen("B.in","r",stdin);
	freopen("B.out","w",stdout);
	  scanf("%d",&n);

	 for (int i=1; i<=n; i++)
		for (int j=1; j<=n; j++)
		scanf("%d",&a[i][j]);
	
	for (int i=1; i<=n; i++)  
		for (int j=1; j<=n; j++)  
			for (int q=1; q<=n; q++) 
			      for (int w=1; w<=n; w++)  
				 for (int r=1; r<=n; r++)	 
					for (int h=1; h<=n; h++)  
						for (int g=1; g<=n; g++)
							for (int k=1; k<=n; k++){
			for (int p =1; p<=n; p++)
				for (int t=1; t<=n; t++)
					c[p] = false;

	if ( i != q && i != r && i != g ) {  
		if ( j != w && j != h && j != k ) {      
			if ( q != r && q != g ) { 	             
				if ( w != h && w != k ) {                          
				     if ( r != g ) {                                        
					 if ( h != k ){                                                  
					   		
			
			if ( i - q != j - w ) {
				if ( i - r != j - r )	{ 
					if ( i - g != j - k ) { 

			if ( q - r != w - h ) {
				if ( q - g != w - k )	{ 

					if ( r - g != h - k ) { 


		//f ( c[q + w - 1] == false )	{  c[q + w-1] = true; 
                      	


		if ( c[i + j - 1] == false )	{  c[i + j - 1] = true;
		    
		 
		                                      
if ( c[r + h - 1] == false )	{  {  c[r + h - 1] = true;
		    
			if ( c[g + k - 1] == false ) { c[g + k - 1] = true;
					 
		 if ( a[i][j] + a[q][w] + a[g][k] + a[r][h] > maximum ) { 
	 maximum = a[i][j] + a[q][w] + a[r][h] + a[g][k]; maxi = i;  maxj = j; maxk = k; maxg = g; maxr = r; maxh = h; maxq = q; maxw = w; } }
	   
					 		}	}	                                      }
}}}		    }}}         }}}             }}                                                                                              }} 
	b[maxi][maxj] = 1;
	b[maxq][maxw] = 1;
	b[maxr][maxh] = 1;
	b[maxg][maxk] = 1;	

	
	for (int i=1; i<=n; i++){	
		for (int j=1; j<=n; j++)	
			printf("%d ",b[i][j]);	
	printf("\n"); 
}                                
		
	fclose(stdout);
return 0;
}