// Solution by [A.S.]

#include <algorithm>
#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

vector <int > a[550], b[550];
int n, m, t1[550], t2[550], alive1, alive2;

int main()
{
	freopen ("c.in", "r", stdin);
	freopen ("c.out", "w", stdout);

	cin >> n >> m;

	int k, x;

	for (int i = 0; i < n; i++)
	{
		cin >> k;

	        t1[i] = true;

		for (int j = 0; j < k; j++)
		{
			cin >> x;
				
			a[i].push_back (x - 1);
		}
	}
	
	for (int i = 0; i < m; i++)
	{
		cin >> k;

		t2[i] = true;

		for (int j = 0; j < k; j++)
		{
			cin >> x;
				
			b[i].push_back (x - 1);
		}
	}

	alive1 = alive2 = 0;

	for (int i = 0; i < n; i++)
		for (int j = 0; j < a[i].size(); j++)
			t2[a[i][j]] = false;

	for (int i = 0; i < m; i++)
		if (t2[i])
			alive2++;	
		
	for (int i = 0; i < m; i++)
		for (int j = 0; j < b[i].size(); j++)
			t1[b[i][j]] = false;

	for (int i = 0; i < n; i++)
		if (t1[i])
			alive1++;

	if (alive1 + m > alive2 + n)
	{
		cout << alive1 + m << " " << alive1 << " " << m << "\n";

		for (int i = 0; i < n; i++)
			if (t1[i])
				cout << i + 1 << " ";
		cout << "\n";

		for (int i = 0; i < m; i++)
			cout << i + 1 << " ";

	}
	else
	{
		cout << alive2 + n << " " << n << " " << alive2 << "\n";

		for (int i = 0; i < n; i++)
			cout << i + 1 << " ";

		cout << "\n";
		
		for (int i = 0; i < m; i++)
			if (t2[i])
				cout << i + 1 << " ";
	}

	return 0;
}
