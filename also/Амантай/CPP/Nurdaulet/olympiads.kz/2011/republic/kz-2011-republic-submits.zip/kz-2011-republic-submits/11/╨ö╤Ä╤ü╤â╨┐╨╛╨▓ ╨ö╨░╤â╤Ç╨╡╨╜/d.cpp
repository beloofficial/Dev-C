// Dyussupov Dauren 11 class Atyrau
#include<cstdio>
#include<iostream>
#include<cmath>
#include<cstdlib>
#include<cstring>
#include<set>
#include<map>
#include<vector>
#include<algorithm>

using namespace std;

#define F first
#define S second
#define sf scanf
#define pf printf
#define N 101000

pair <int, int> b[N];
int a[N], was[N];

int main()
{
	freopen("D.in", "r", stdin);
	freopen("D.out", "w", stdout);

	int n, m, i, j, cur = 1, ans, l, r;

	sf("%d%d", &n, &m);

	for (i = 1; i <= n; i++) 
	{
		sf("%d", &a[i]);
		b[i].F = a[i];
		b[i].S = i;
	}
			
	sort(b + 1, b + n + 1);

	a[b[1].S] = cur;

	for (i = 2; i <= n; i++)
		if (b[i].F != b[i - 1].F)
		{
			cur++;
			a[b[i].S] = cur;
		} else a[b[i].S] = cur;
	     
	for (i = 1; i <= m; i++)
	{
		ans = 0;
		sf("%d %d", &l, &r);
		for (j = l; j <= r; j++)
			if (was[a[j]] != i)
			{
				ans++;
				was[a[j]] = i;
			}
	   pf("%d\n", ans);
	}

	return 0;
}