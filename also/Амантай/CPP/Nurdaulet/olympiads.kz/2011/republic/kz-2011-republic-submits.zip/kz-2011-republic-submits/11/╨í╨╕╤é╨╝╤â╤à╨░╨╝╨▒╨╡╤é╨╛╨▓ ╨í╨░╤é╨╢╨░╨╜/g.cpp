#include <cstdio>
//#include <ctime>
#include <cmath>
#include "dist.h"
//#include <algorithm>
//#include <cstring>
//#include <cmath>
//#include <ctime>
using namespace std;
#define inf 1000000009
//int cnt, ansx, ansy;
//void start() {
//	ansx = (rand() / 2 * 100000 + rand()) % 1000000000;
//	ansy = (rand() / 2 * 100000 + rand()) % 1000000000;
//	ansx = ansy = 0;
//} 
//double dist(int x, int y) {
//	cnt++;
//	return sqrt(1ll * (x - ansx) * (x - ansx) + 1ll * (y - ansy) * (y - ansy));
//}
//void finish(int x, int y) {
//	printf("my = %d %d\n", x, y);
//	printf("ans = %d %d", ansx, ansy);
//}
main () {
//	srand(time(NULL));
	int ok = 0, k, l, r, ll, rr, x, y; double a, b;
	//freopen("G.in", "r", stdin);
	//freopen("G.out", "w", stdout);
	start();
//	printf("%d %d", ansx, ansy);

	l = -inf; r = inf;
	y = 0;
	while (r - l > 1) {
		//printf("%d %d ", l, r);
		k = (r - l + 1) / 3;
		ll = l + k;
		rr = r - k;
		//printf(" ll = %d rr = %d ", ll, rr);
		a = dist(ll, y);
		b = dist(rr, y);
		//printf("a = %.25lf b = %.25lf\n", a, b);
		if (cnt > 10000) ok = 1;
		if (a >= b) l = ll;
		else r = rr;
	} 
	x = l;  
	y = dist(x, 0);
	l = -inf; r = inf;
	while (r - l > 1) {
		//printf("%d %d ", l, r);
		k = (r - l + 1) / 3;
		ll = l + k;
		rr = r - k;
		//printf(" ll = %d rr = %d ", ll, rr);
		a = dist(ll, y);
		b = dist(rr, y);
	//	printf("a = %.25lf b = %.25lf\n", a, b);
		if (cnt > 10000) ok = 1;
		if (a >= b) l = ll;
		else r = rr;
	} 
	x = l;                    
	finish(x, y);

}	