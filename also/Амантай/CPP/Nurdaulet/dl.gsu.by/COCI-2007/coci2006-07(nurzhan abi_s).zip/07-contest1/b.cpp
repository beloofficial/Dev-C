#include <cmath>
#include <cstdio>

const double pi = acos(-1.0);

int main() {
	int r;
	scanf("%d", &r);

	printf("%.6lf\n", pi*r*r);
	printf("%.6lf\n", 2.0*r*r);

	return 0;
}