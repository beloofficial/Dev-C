#include <set>
#include <cstdio>
using namespace std;

#define sz(a) (int)a.size()

int main() {
	set<int> s;
	for (int i = 0; i < 10; i++) {
		int x;
		scanf("%d", &x);
		s.insert(x%42);
	}

	printf("%d", sz(s));

	return 0;
}