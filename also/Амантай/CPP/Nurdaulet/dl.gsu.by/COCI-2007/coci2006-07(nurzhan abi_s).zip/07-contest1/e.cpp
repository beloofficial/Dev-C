#include <cstdio>
#include <iostream>
const int N = 20;

double dp[1<<N];

int main() {
	int n;
	scanf("%d", &n);

	int a[n][n];
	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)
			scanf("%d", &a[i][j]);

	dp[0] = 100;

	int full = 1<<n;
	for (int mask = 1; mask < full; mask++) {
		int ones = __builtin_popcount(mask)-1;
		for (int i = 0; i < n; i++) {
			if ((mask >> i) & 1) {
				dp[mask] = std::max(dp[mask], dp[mask ^ (1<<i)] / 100 * a[ones][i]);
			}
		}
	}

	printf("%.12lf", dp[full-1]);

	return 0;
}