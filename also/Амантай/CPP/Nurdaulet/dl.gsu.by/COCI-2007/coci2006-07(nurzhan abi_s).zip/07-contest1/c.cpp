#include <cstdio>

char c[5][100];
inline void put(int i, int j, char ch, char sym) {
	for (int x = 0; x < 5; x++)
	for (int y = j-2; y <= j+2; y++)
		c[x][y] = '.';
	c[i][j] = sym;
	c[i-2][j] = c[i-1][j+1] = c[i-1][j-1] = c[i][j+2] =
	c[i][j-2] = c[i+1][j+1] = c[i+1][j-1] = c[i+2][j] = ch;
}

int main() {
	char s[20];
	gets(s);
	for (int i = 0; s[i]; i++) {
		if (i % 3 == 2) continue;
		put(2, 2+i*4, '#', s[i]);
	}
	for (int i = 0; s[i]; i++)
		if (i % 3 == 2) put(2, 2+i*4, '*', s[i]);

	for (int i = 0; i < 4; i++)
		puts(c[i]);
	printf("%s", c[4]);

	return 0;
}