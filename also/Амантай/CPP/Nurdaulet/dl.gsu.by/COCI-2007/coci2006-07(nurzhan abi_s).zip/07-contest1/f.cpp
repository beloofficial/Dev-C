#include <cmath>
#include <cstdio>
#include <iostream>
using namespace std;

const int K = 8;
const int MAX = 1<<K+1;
const int N = 300;
const int prime = 1993;

typedef long long ll;

const int dx[] = {-1, 0, 1, 0};
const int dy[] = {0, 1, 0, -1};

ll deg[MAX], h[N][N][K+1][4];
int n, m, ans = -1, lg[MAX];
char a[N][N];

inline bool ok(int x, int y) {
	return 0 <= x && x < n && 0 <= y && y < m;
}

int l, s, dif;
inline pair<ll,ll> get(int x, int y, int d, int sz) {
	l = lg[sz];
	dif = sz-(1<<l);
	return make_pair(h[x][y][l][d], h[x+dx[d]*dif][y+dy[d]*dif][l][d]);
}

inline void go(int x1, int y1, int x2, int y2, int sz) {
	int dream = sz + 2*min(min(x1,y1), min(n-x2-1, m-y2-1));
	if (dream <= ans) return;
	while (ok(x1,y1) && ok(x2,y2) && get(x1,y1,2,sz) == get(x2,y2,0,sz) && get(x1,y2,3,sz) == get(x2,y1,1,sz)) {
		ans = max(ans, sz);
		x1--; y1--;
		x2++; y2++;
		sz += 2;
	}
}

int main() {
	#ifdef LOCAL
	freopen("f.in", "r", stdin);
	freopen("f.out", "w", stdout);
	#endif

	scanf("%d %d", &n, &m);

	for (int i = 0; i < n; i++)
		scanf("%s", a[i]);

	deg[0] = 1;
	for (int i = 1; i < MAX; i++)
		deg[i] = deg[i-1] * prime;

	for (int i = 1; i < MAX; i++)
		lg[i] = (int)floor(log2(i));

	for (int i = 0; i < n; i++)
		for (int j = 0; j < m; j++)
			for (int d = 0; d < 4; d++)
				h[i][j][0][d] = a[i][j];

	for (int k = 1, sz = 1; k <= 8; k++, sz <<= 1)
		for (int i = 0; i < n; i++)
			for (int j = 0; j < m; j++)
				for (int d = 0; d < 4; d++) {
					int x = i + sz * dx[d];
					int y = j + sz * dy[d];
					if (ok(x, y))
						h[i][j][k][d] = h[i][j][k-1][d] + deg[sz] * h[x][y][k-1][d];
				}

	for (int i = 0; i < n; i++)
		for (int j = 0; j < m; j++)
		 	for (int s = 1; s <= 2; s++)
		 		go(i, j, i+s, j+s, s+1);

	printf("%d", ans);

	return 0;
}