#include <cstdio>
#include <cstdlib>
#include <vector>
using namespace std;

#define pb push_back
#define sz(a) (int)a.size()

const int N = 55;

char a[N][N];
int n, m, s, f, dist[N*N];
vector<int> q;

inline void move(int from, int to) {
	if (to == f) {
		if (dist[from]) {
			printf("%d\n", dist[from]);
			exit(0);
		}
		return;
	}
	if (dist[to] == n*m) {
		dist[to] = dist[from]+(dist[from]>0);
		q.pb(to);
	}
}

inline void print() {
	for (int i = 0; i < n*m; i++) {
		printf("%d ", dist[i]);
		if (i % m == m-1) printf("\n");
	}
}

int main() {
	scanf("%d %d", &n, &m);
	for (int i = 0; i < n; i++)
		scanf("%s", a[i]);

	int k = 0;
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < m; j++) {
			switch (a[i][j]) {
				case '*':	q.pb(k); dist[k] = 0; break;
				case 'X':	dist[k] = 0; break;
				case 'S':	s = k; break;
				case 'D':	f = k; break;
				case '.':	dist[k] = n*m;
			}
			k++;
		}
	}

	q.pb(s);
	dist[s] = 1;

	for (int i = 0; i < sz(q); i++) {
		int cur = q[i];
		if ((cur+1) % m) move(cur, cur+1);
		if (cur % m) move(cur, cur-1);
		if (cur >= m) move(cur, cur-m);
		if (cur/m+1 < n) move(cur, cur+m);
	}

	puts("KAKTUS");

	return 0;
}