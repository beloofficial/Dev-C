#include <cstdio>
#include <iostream>
#include <algorithm>
using namespace std;

const int mod = 1e9+7;

int n, k, f[2][10001], sum[2][10001];

int main() {
	#ifdef LOCAL
	freopen("a.in", "r", stdin);
	freopen("a.out", "w", stdout);
	#endif
	cin >> n >> k;
	for (int i = 0; i <= n; i++) {
		int x = i % 2; int y = 1-x;
		f[x][0] = sum[x][0] = 1;
		int lim = min(k, i*(i-1)/2);
		for (int c = 1; c <= lim; c++) {
			int to = min(i-1, c);
			f[x][c] = (sum[y][c] - (to == c ? 0 : sum[y][c-to-1]) + mod) % mod;
			sum[x][c] = (sum[x][c-1] + f[x][c]) % mod;
		}
		for (int c = lim + 1; c <= k; c++)
			sum[x][c] = sum[x][lim];
	}
	cout << f[n % 2][k];
}