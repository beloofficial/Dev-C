#include <cstdio>
#include <cstdlib>
#include <cassert>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <ctime>
#include <cmath>
#include <vector>
#include <bitset>
#include <set>
#include <map>
using namespace std;

#define pb push_back
#define mp make_pair
#define sz(a) (int)a.size()
#define sqr(x) ((x)*(x))
#define ms(a, x) memset(a, x, sizeof a)
#define all(a) a.begin(), a.end()
#define forit(it, s) for (__typeof(s.begin()) it = s.begin(); it != s.end(); it++)

typedef long long ll;
typedef vector<int> vi;
typedef pair<int,int> pii;

const int inf = 1<<30;
const int N = 1<<17;

int n, a[1<<15], b[1<<15];

void out(int v, int lvl) {
	if (lvl > n) return;
	printf("%d ", a[v]);
	out(v*2, lvl+1);
	out(v*2+1, lvl+1);
}

int main() {
	scanf("%d", &n); n--;
	a[1] = 1;
	for (int k = 1; k <= n; k++) {
		b[1] = a[1];
		int i = 1;
		for (int l = 0; l < k; l++) {
			int sz = 1<<l;
			for (int r = 0; r < sz; r++)
				b[++i] = a[sz+r] * 2 + (l==k-1);
			for (int r = 0; r < sz; r++)
				b[++i] = a[sz+r] * 2 + (l!=k-1);
		}
		memcpy(a, b, sizeof(int) * (1<<(k+1)));
	}

	out(1, 0);

	return 0;
}