#include <cstdio>
#include <iostream>
#include <algorithm>
using namespace std;

int main() {
	#ifdef LOCAL
	freopen("c.in", "r", stdin);
	freopen("c.out", "w", stdout);
	#endif

	int n;
	scanf("%d", &n);

	int a[n];
	for (int i = 0; i < n; i++)
		scanf("%d", a+i);

	for (int i = 0; i < n; i++) {
		int g = __gcd(a[0], a[i]);
		if (i) printf("%d/%d\n", a[0]/g, a[i]/g);
	}
}