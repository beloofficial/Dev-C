#include <iostream>
using namespace std;

int n, x[26], y[26], z[26];

int main() {
	cin >> n;

	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			char c; cin >> c;
			if (isalpha(c)) {
				c -= 'A';
				x[c] = i;
				y[c] = j;
				z[c] = 1;
			}
		}
	}

	int ans = 0;
	for (int i = 0; i < 26; i++) if (z[i])
	for (int j = i+1; j < 26; j++) if (z[j])
	for (int k = j+1; k < 26; k++) if (z[k]) {
		int a = y[k]-y[j];
		int b = x[k]-x[j];
		int c = y[k]-y[i];
		int d = x[k]-x[i];
		ans += a*d==b*c;
	}

	cout << ans;

	return 0;
}