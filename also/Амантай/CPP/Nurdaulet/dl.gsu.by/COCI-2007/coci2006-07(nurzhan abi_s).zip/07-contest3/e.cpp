#include <cstdio>
#include <iostream>
#include <vector>
using namespace std;

#define pb push_back
#define sz(a) (int)a.size()

const int N = 10100;
const int mod = 1e9;
vector<int> e[N], r[N], top;

int c[N], dp[N];
bool ww[N], cycle[N], u[N];

void dfs2(int a) {
	cycle[a] = 1;
	for (int i = 0; i < sz(e[a]); i++) {
		int b = e[a][i];
		if (!cycle[b])
			dfs2(b);
	}
}

void dfs(int a) {
	c[a] = 1;
	for (int i = 0; i < sz(e[a]); i++) {
		int b = e[a][i];
		if (c[b] == 0) {
			dfs(b);
		} else
		if (c[b] == 1) {
			if (!cycle[b])
				dfs2(b);
		}
	}
	c[a] = 2;
	top.pb(a);
}

void dfs3(int a) {
	u[a] = 1;
	for (int i = 0; i < sz(r[a]); i++) {
		int b = r[a][i];
		if (!u[b])
			dfs3(b);
	}
}

int main() {
//	freopen("e.in", "r", stdin);
//	freopen("e.out", "w", stdout);

	int n, m;
	scanf("%d %d", &n, &m);
	while (m--) {
		int a, b;
		scanf("%d %d", &a, &b);
		e[a].pb(b);
		r[b].pb(a);//reverse
	}

	dfs(1);
	dfs3(2);

	for (int i = 1; i <= n; i++)
		if (u[i] && cycle[i]) {
			puts("inf");
			return 0;
		}

	dp[2] = 1;
	for (int i = 0; i < sz(top); i++) {
		int a = top[i];
		for (int j = 0; j < sz(e[a]); j++) {
			int b = e[a][j];
			dp[a] += dp[b];
			if (ww[b]) ww[a] = 1;
			if (dp[a] >= mod) {
				dp[a] -= mod;
				ww[a] = 1;
			}
		}
	}

	if (ww[1])
		printf("%09d", dp[1]);
	else
		printf("%d", dp[1]);

	return 0;
}