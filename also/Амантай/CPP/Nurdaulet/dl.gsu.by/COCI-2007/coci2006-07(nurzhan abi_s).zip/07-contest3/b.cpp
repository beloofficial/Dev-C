#include <cstdio>
#include <algorithm>
using namespace std;

int main() {
	int sum = 0;
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			char c; scanf("%c", &c);
			if (c == '.') continue;
			c -= 'A';
			int x = c/4; int y = c%4;
			sum += abs(x-i) + abs(y-j);
		}
		scanf("\n");
	}
	printf("%d", sum);
	return 0;
}