#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;

#define x first
#define y second
#define mp make_pair
#define pb push_back
#define sz(a) (int)a.size()

const int N = 550;

pair<int,int> a[N], b[N];
vector< pair<int,char> > moves;

int main() {
	#ifdef LOCAL
	freopen("d.in", "r", stdin);
	freopen("d.out", "w", stdout);
	#endif

	int n;
	scanf("%d", &n);
	for (int i = 0; i < n; i++) {
		int x, y;
		scanf("%d %d", &x, &y);
		x--; y--;
		a[i] = mp(x, i);
		b[i] = mp(y, i);
	}

	sort(a, a + n);
	sort(b, b + n);

	while (1) {
		bool ok = 1;
		for (int i = 0; ok && i < n; i++)
			if (a[i].x != i) ok = 0;
		if (ok) break;
		bool f = 0;
		for (int i = 0; i < n; i++)
			if (a[i].x < i && (i == n-1 || i < a[i+1].x)) {
				a[i].x++; moves.pb(mp(a[i].y, 'D'));
				f = 1;
				break;
			}
		if (f) continue;
		for (int i = 0; i < n; i++)
			if (a[i].x > i && (i == 0 || i > a[i-1].x)) {
				a[i].x--; moves.pb(mp(a[i].y, 'U'));
				break;
			}
	}

	while (1) {
		bool ok = 1;
		for (int i = 0; ok && i < n; i++)
			if (b[i].x != i) ok = 0;
		if (ok) break;
		bool f = 0;
		for (int i = 0; i < n; i++)
			if (b[i].x < i && (i == n-1 || i < b[i+1].x)) {
				b[i].x++; moves.pb(mp(b[i].y, 'R'));
				f = 1;
				break;
			}
		if (f) continue;
		for (int i = 0; i < n; i++)
			if (b[i].x > i && (i == 0 || i > b[i-1].x)) {
				b[i].x--; moves.pb(mp(b[i].y, 'L'));
				break;
			}
	}

	printf("%d\n", sz(moves));

	for (int i = 0; i < sz(moves); i++)
		printf("%d %c\n", moves[i].x+1, moves[i].y);

	return 0;
}