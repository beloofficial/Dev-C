#include <cstdio>
#include <vector>
#include <algorithm>
using namespace std;

#define pb push_back
#define mp make_pair
#define sz(a) (int)a.size()
#define all(a) a.begin(), a.end()

const int inf = 1<<30;
const int N = 1<<19;

int n, m, nx[N], pr[N], fr[N], M[N];

int main() {
	#ifdef LOCAL
	freopen("f.in", "r", stdin);
	freopen("f.out", "w", stdout);
	#endif

	scanf("%d %d\n", &n, &m);

	for (int i = 0; i <= n; i++)
		nx[i] = i+1;

	for (int i = 1; i <= n+1; i++)
		pr[i] = i-1;

	while (m--) {
		char c; int a, b;
		scanf("%c %d %d\n", &c, &a, &b);
		nx[pr[a]] = nx[a];
		pr[nx[a]] = pr[a];

		if (c == 'A') b = pr[b];
		nx[a] = nx[b];
		pr[a] = b;
		pr[nx[b]] = a;
		nx[b] = a;
	}

	for (int i = 1; i <= n; i++)
		M[i] = inf;

	int v = nx[0];
	while (v != n+1) {
		int p = upper_bound(M, M + n + 1, v) - M;
		fr[v] = M[p-1];
		M[p] = min(M[p], v);
		v = nx[v];
	}

	int cnt = lower_bound(M, M+n+1, inf) - M - 1;

	printf("%d\n", n-cnt);

	vector<int> ls;
	v = M[cnt];
	while (v) {
		ls.pb(v);
		v = fr[v];
	}

	reverse(all(ls));

	int s = sz(ls);
	for (int i = 1, j = 0; i <= n; i++) {
		if (s <= j) printf("B %d %d\n", i, i-1); else
		if (i < ls[j]) printf("A %d %d\n", i, ls[j]); else
			j++;
	}

	return 0;
}