#include <cstdio>
#include <iostream>
#include <algorithm>
using namespace std;

int a[3];
char b[3];

int main() {
	for (int i = 0; i < 3; i++)
		scanf("%d", a+i);
	scanf("%s", b);
	sort(a, a + 3);
	for (int i = 0; i < 3; i++)
		printf("%d ", a[b[i]-'A']);
}