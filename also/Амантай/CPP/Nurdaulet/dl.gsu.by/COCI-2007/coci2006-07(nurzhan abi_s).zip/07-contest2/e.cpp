#include <cstdio>
#include <iostream>
using namespace std;

int h[500];
char a[500][500];

int main() {
	int n, m;
	scanf("%d%d",&n,&m);
	for (int i = 0; i < n; i++)
		scanf("%s", a[i]);
	int ans = 0;
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < m; j++) {
			if (a[i][j] == 'X') h[j] = 0; else h[j]++;
			int minh = 1e9;
			for (int k = j; k >= 0; k--) {
				minh = min(minh, h[k]);
				if (h[k] == 0) break;
				ans = max(ans, minh + j-k+1);
			}
		}
	}
	printf("%d", ans * 2 - 1);
}