#include <cstdio>
#include <iostream>
#include <algorithm>
using namespace std;

string a, b, s;
int ch[500];

int main() {
	int n, m, t;
	cin >> n >> m >> a >> b >> t;
	reverse(a.begin(), a.end());
	s = a + b;
	for (int i = 0; i < n; i++)
		ch[a[i]] = 1;
	for (int i = 0; i < m; i++)
		ch[b[i]] = 2;
	while (t--) {
		string ss;
		for (int i = 0; i < n+m; i++) {
			if (i+1 < n+m && ch[s[i]] == 1 && ch[s[i+1]] == 2) {
				ss += s[i+1];
				ss += s[i];
				i++;
			} else {
				ss += s[i];
			}
		}
		s = ss;
	}
	cout << s;
	return 0;
}