#include <cstdio>

int main() {
	int a, b, s;
	scanf("%d %d", &a, &s);
	b = 2*s - a;
	printf("%d", b);
}