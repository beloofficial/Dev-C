#include <cstdio>
#include <cassert>
#include <iostream>
#include <algorithm>
using namespace std;

typedef long long ll;

struct pt
{
	int x, y;

	void read()
	{
		scanf("%d %d", &x, &y);
	}

	bool operator < (const pt &o) const
	{
		if (x != o.x) return x < o.x;
		return y < o.y;
	}

	void print()
	{
		printf("x=%d y=%d\n", x, y);
	}
};

struct line
{
	int A, B, C;

	line() {}

	line(pt a, pt b)
	{
		A = a.y - b.y;
		B = b.x - a.x;
		C = a.x * b.y - a.y * b.x;
		norm();
	}

	void norm()
	{
		int g = __gcd(__gcd(A,B), C);
		A /= g; B /= g; C /= g;
		if (A < 0 || (A == 0 && B < 0))
			A *= -1, B *= -1, C *= -1;
	}

	bool operator == (const line &o) const
	{
		return A == o.A && B == o.B && C == o.C;
	}

	void print()
	{
		printf("A=%d B=%d C=%d\n", A, B, C);
	}
};

struct seg
{
	bool alive;
	pt a, b;
	line l;

	seg()
	{
		alive = true;
	}

	seg(pt _a, pt _b)
	{
		alive = true;
		l = line(a = _a, b = _b);
	}

	void read()
	{
		alive = true;
		a.read();
		b.read();
		l = line(a, b);
	}

	bool parallel(seg o) {
		return 1ll * l.A * o.l.B == 1ll * l.B * o.l.A;
	}

	bool touches(seg o)
	{
		return contains(o.a) || contains(o.b) || o.contains(a) || o.contains(b);
	}

	bool overlaps(seg o)
	{
		return l == o.l && touches(o);
	}

	bool contains(pt p)
	{
		if (l.A * p.x + l.B * p.y + l.C != 0) return false;
		return min(a.x, b.x) <= p.x && p.x <= max(a.x, b.x) && min(a.y, b.y) <= p.y && p.y <= max(a.y, b.y);
	}

	void merge(seg o)
	{
		pt p[4] = {a, b, o.a, o.b};
		sort(p, p + 4);
		a = p[0]; b = p[3];
	}

	bool intersect(seg o, double &x, double &y) {
		ll up1 = 1ll * l.A * o.l.C - 1ll * o.l.A * l.C;
		ll down1 = 1ll * o.l.A * l.B - 1ll * o.l.B * l.A;
		if (down1 == 0) return false;
		y = up1 * 1.0 / down1;

		ll up2 = 1ll * l.B * o.l.C - 1ll * o.l.B * l.C;
		ll down2 = 1ll * o.l.B * l.A - 1ll * o.l.A * l.B;
		if (down2 == 0) return false;
		x = up2 * 1.0 / down2;

		ll s1, s2; // signs

		s1 = l.A * o.a.x + l.B * o.a.y + l.C;
		s2 = l.A * o.b.x + l.B * o.b.y + l.C;
		if (s1 < 0 && s2 < 0) return false;
		if (s1 > 0 && s2 > 0) return false;

		s1 = o.l.A * a.x + o.l.B * a.y + o.l.C;
		s2 = o.l.A * b.x + o.l.B * b.y + o.l.C;
		if (s1 < 0 && s2 < 0) return false;
		if (s1 > 0 && s2 > 0) return false;

		return true;
	}

	void print()
	{
		a.print();
		b.print();
		l.print();
		printf("\n");
	}
} s[20];

int main() {
//	freopen("f.in", "r", stdin);
//	freopen("f.out", "w", stdout);

	int n;
	scanf("%d", &n);
	for (int i = 0; i < n; i++)
		s[i].read();

	for (int i = 0; i < n; i++) if (s[i].alive)
		for (int j = 0; j < n; j++)
			if (i != j && s[j].alive && s[i].overlaps(s[j])) {
//				s[i].print();
//				s[j].print();
				s[i].merge(s[j]);
				s[j].alive = false;
//				printf("merged: %d %d\n", i, j);
			}

	int cnt = 0;
	for (int i = 0; i < n; i++) if (s[i].alive)
	for (int j = i+1; j < n; j++) if (s[j].alive)
	for (int k = j+1; k < n; k++) if (s[k].alive)
	{
		double x1, y1, x2, y2, x3, y3;
		if (!s[i].intersect(s[j], x1, y1)) continue;
		if (!s[i].intersect(s[k], x2, y2)) continue;
		if (!s[j].intersect(s[k], x3, y3)) continue;

		if (x1 == x2 && y1 == y2) continue;
		if (x1 == x3 && y1 == y3) continue;
		if (x2 == x3 && y2 == y3) continue;

		//printf("%d %d %d\n", i, j, k);
		cnt++;
	}

	printf("%d", cnt);

	return 0;
}