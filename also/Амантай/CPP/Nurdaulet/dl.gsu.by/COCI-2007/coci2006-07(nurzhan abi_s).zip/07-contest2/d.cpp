#include <cstdio>
int main() {
	int n;
	scanf("%d", &n);
	int ans = 0;
	for (int i = 0; i < n; i++)
		for (int j = i+1; j < n; j++)
			ans += (j-i-1) * (n-j+i-1);
	printf("%d\n", ans/2);
}